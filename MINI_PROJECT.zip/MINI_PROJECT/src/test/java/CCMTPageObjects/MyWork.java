package CCMTPageObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;
import org.testng.Assert;

import CCMTTestCases.BaseClass;

import static org.testng.AssertJUnit.assertTrue;
import static org.testng.AssertJUnit.fail;

public class MyWork extends BaseClass {

	public WebDriver lwebDriver;
	String Total_Amountunt;
	String Postalcode;
	String Customername;
	String cust_No;
	String Case_ID;
	WebElement Task_count;

	WebElement After_Task_Count;

	String line_amount =
			"3775803.00";
	String line_amount2 =
			"13080702.27";

	String line_amount3 =
			"17213.70";

	String randomText;
	String randomText2;

	public MyWork(WebDriver rdriver) {

		lwebDriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	// FindMyworkElement to verify homepage
	@FindBy(xpath = "//li[@id='Tab1']")
	@CacheLookup
	public WebElement mywork;
	// Click on sbmit button
	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//i[@class=' icons fa fa-bolt fa-15x DisputeOpen'] | //tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//i[@class=' icons fa fa-bolt fa-15x DisputeOpen']")
	@CacheLookup
	public List<WebElement> Icon_Dispute;
	@FindBy(xpath = "//button[text()='  Submit ']")
	@CacheLookup
	public WebElement Click_on_Submit;
	// click on open Dispute on BU page
	@FindBy(xpath = "(//span[text()='Open Disputes'])[1]")
	@CacheLookup
	public WebElement Click_on_OpenDispute;

	// click on close Dispute on BU page
	@FindBy(xpath = "//span[text()='Closed Disputes']")
	@CacheLookup
	public WebElement Click_on_closeDispute;
	// Select route person
	@FindBy(xpath = "//label[contains(text(),'Route To')]//following-sibling::div//child::label[contains(text(),'Person')]")
	@CacheLookup
	public WebElement Select_route;

	// BurgerMenuClick
	@FindBy(xpath = "//a[@id='appview-nav-toggle-one']")
	@CacheLookup
	WebElement ClickOnBurgerMenu;

	// Select Add item note
	@FindBy(xpath = "//div[contains(text(),'Open Debtor Items')]/following::button[contains(text(),'Add Item Note')]")
	@CacheLookup
	WebElement ClickOnAdd_item;

	@FindBy(xpath = "//a[@id='appview-nav-toggle-one']")
	@CacheLookup
	WebElement main_menu;
	@FindBy(xpath = "//a[.='Add Contact']")
	@CacheLookup
	WebElement ClickOnAddContact;
	@FindBy(xpath = "//a[contains(@name,'pyPortalHeader_pyDisplayHarness_37')]/following::span[text()='Log off']")
	@CacheLookup
	WebElement ClickOnLogoff;

	@FindBy(xpath = "//button[text()='Email with Item Copy']")
	@CacheLookup
	WebElement ClickOnEmailWithItem;


	@FindBy(xpath = "//button[text()='Email']")
	@CacheLookup
	WebElement ClickOnEmail1;

	// ClickOnCashCollectorItem
	@FindBy(xpath = "//ul[@role=\"menubar\"]//span[.='Cash collectors']/parent::a")
	@CacheLookup
	WebElement ClickOnCashCollectorItem;

	// ClickOnCustomerSearch
	@FindBy(xpath = "//a[@name='pyPortalHeader_pyDisplayHarness_7']")
	@CacheLookup
	WebElement ClickOnCustomerSearch;

	// ClickOnCustomerSearch
	@FindBy(xpath = "//a[contains(@name,'pyPortalHeader_pyDisplayHarness_31')]")
	@CacheLookup
	WebElement ClickOnSearch;

	// EnterOneInCustomerSearch ////input[@id='7fbbb3fc']
	// ////label[@for='7fbbb3fc']/following-sibling::div//span/input
	@FindBy(xpath = "//label[contains(text(),'Name, Number')]//following-sibling::div//input")
	@CacheLookup
	WebElement EnterCustomerNumberSearch;

	// ClickOnSearchButton
	@FindBy(xpath = "//button[.='Search']")
	@CacheLookup
	WebElement ClickOnSearchButton;

	// ClickOnProfile
	@FindBy(xpath = "//a[@name='pyPortalHeader_pyDisplayHarness_12']")
	@CacheLookup
	WebElement ClickOnProfile;

	@FindBy(xpath = "//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]")
	@CacheLookup
	WebElement ClickOnContactEdit;
	@FindBy(xpath = "//span[text()='My Customers']")  ////div[@id='po0']
	@CacheLookup
	WebElement Mycustomer;
	// ClickOnSwitchApp
	@FindBy(xpath = "//a[.='Switch apps']")
	// @CacheLookup
			WebElement ClickOnSwitchApp;

	// ClickOnSwitchApp
	@FindBy(xpath = "//div[contains(text(),'Open Debtor Items')]/following::i[@class='fa fa-download']")
	// @CacheLookup
			WebElement Download_items;

	// ClickOnSwitchApp
	@FindBy(xpath = "//a[.='Cash Collection Healthcare US Dev']")
	@CacheLookup
	WebElement CashCollectionHealthcareUSDevSelected;

	// ClickOnMyCustomer
	@FindBy(xpath = "//span[.='My Customers']")
	@CacheLookup
	WebElement ClickOnMyCustomer;

	// ClickOnCollectionId
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[.='CO-5343959']")
	@CacheLookup
	WebElement ClickOnCollectionId;

	// ClickOnCollectionId
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[.='CO-5323408']")
	@CacheLookup
	WebElement ClickOnCollectionIdUKRC;

	// ClickOnCollectionId // //div[@class='content-item content-field
	// item-2']/child::div//span[.='CO-610617']
	@FindBy(xpath = "//div[@class='content-item content-field item-2']/child::div//span[.='CO-1273443']")
	@CacheLookup
	WebElement ClickOnDevCollectionId;

	// ClickOnQACollectionId // //div[@class='content-item content-field
	// item-2']/child::div//span[.='CO-610617']
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[text()='CO-5346206']")
	@CacheLookup
	WebElement ClickOnQACollectionId;

	// ClickOnQACollectionId // //div[@class='content-item content-field
	// item-2']/child::div//span[.='CO-610617']
	@FindBy(xpath = "//div[@id='']/descendant::td/child::div")
	@CacheLookup
	WebElement ClickOnQACollectionIdUKRC;

	// ClickOnQACollectionIdASNRC
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[text()='CO-3836391']")
	@CacheLookup
	WebElement ClickOnQACollectionIdASNRC;

	// ClickOnQACollectionIdUSRC
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[text()='CO-5015043']")
	@CacheLookup
	WebElement ClickOnQACollectionIdUSRC;

	// ClickOnQACollectionId // //div[@class='content-item content-field
	// item-2']/child::div//span[.='CO-610617']
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[text()='CO-5346453']")
	@CacheLookup
	WebElement ClickOnQACollectionIdLeading;

	// ClickOnQACollectionId // //div[@class='content-item content-field
	// item-2']/child::div//span[.='CO-610617']
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[text()='CO-5344799']")
	@CacheLookup
	WebElement ClickOnQACollectionIdForDunning;

	// ClickOnQACollectionId // //div[@class='content-item content-field
	// item-2']/child::div//span[.='CO-610617']
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[text()='CO-5336616']")
	@CacheLookup
	WebElement ClickOnQACollectionIdWithoutSwitchApp;

	// ClickOnCollectionIdAu
	@FindBy(xpath = "(//div[@class='content-item content-field item-1     '])[1]")
	@CacheLookup
	WebElement ClickOnCollectionIdAu;


	@FindBy(xpath = "//label[contains(text(),'Application')]/following-sibling::div//a")
	@CacheLookup
	WebElement element;

	// Select Business Workbaskets
	@FindBy(xpath = "//span[contains(text(),'Business Workbaskets')]")
	@CacheLookup
	WebElement ClickOnBusiness_Workbaskets;

	// Select Business Workbaskets
	@FindBy(xpath = "//span[contains(text(),'My Customers')]")
	@CacheLookup
	WebElement ClickOnMycustomer;

	// Select Business Workbaskets
	@FindBy(xpath = "//span[contains(text(),'My Tasks')]")
	@CacheLookup
	WebElement ClickOnTask;

	// Select Business Workbaskets
	@FindBy(xpath = "//span[contains(text(),'Unassigned emails')]")
	@CacheLookup
	WebElement ClickOnunassignemail;

	@FindBy(xpath = "//span[contains(text(),'Promised to Pay')]")
	@CacheLookup
	WebElement ClickOnpromisedtoPay;

	@FindBy(xpath = "//span[contains(text(),'My Open Disputes')]")
	@CacheLookup
	WebElement My_open_Disputes;

	@FindBy(xpath = "//span[contains(text(),'Overdue Tasks')]")
	@CacheLookup
	WebElement ClickOnOverDue;

	// Select Business Workbaskets
	@FindBy(xpath = "//button[contains(text(),'New Business Basket')]")
	@CacheLookup
	WebElement ClickOnBusiness_Basket;


	@FindBy(xpath = "(//td[text()=' Dispute Customer Follow Up Call  '])[1]")
	@CacheLookup
	WebElement Dispute_Task2;
	// ClickOnCollectionId // //div[@class='content-item content-field
	// item-2']/child::div//span[.='CO-610617']
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[.='CO-1474452']")
	@CacheLookup
	WebElement ClickOnDevCollectionIdForLeadingInvoice;

//WorkQueues

	// ClickOnWorkQueues
	@FindBy(xpath = "//span[text()='Work queues']")
	@CacheLookup
	WebElement ClickOnWorkQueues;

	//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following::span[2]/child::a

	@FindBy(xpath = "//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following::span[2]/child::a")
	@CacheLookup
	WebElement Fliter_for_customer;

	// ClickOnCancelINworkQueues
	@FindBy(xpath = "//button[text()='  Cancel ']")
	@CacheLookup
	WebElement ClickOnCancelINworkQueues;

	// ClickOnCancelINworkQueues
	@FindBy(xpath = "//h2[contains(text(),'Recent attachments')]/following::i[contains(@class,'pi pi-circle-plus-solid')]")
	@CacheLookup
	WebElement Attachment_Icon;

	// ClickOnManageWorkQueues
	@FindBy(xpath = "//span[text()='Manage Work queues']")
	@CacheLookup
	WebElement ClickOnManageWorkQueues;

	// ClickOnManageWorkQueues
	@FindBy(xpath = "//span[text()='Metering Legal Validations']")
	@CacheLookup
	WebElement ClickOnWorkBasketForPersonalWorkQueue;

	// ClickOnWorkBasketForPersonalWorkQueueASNRC
	@FindBy(xpath = "//span[text()='CS Team']")
	@CacheLookup
	WebElement ClickOnWorkBasketForPersonalWorkQueueASNRC;

	// ClickOnWorkBasketForPersonalWorkQueueASNRC
	@FindBy(xpath = "//span[text()='kiran g m']")
	@CacheLookup
	WebElement ClickOnWorkBasketForPersonalWorkQueueUSRC;

	// ClickOnManageWorkQueues
	@FindBy(xpath = "//span[text()='Auto dispute testing']")
	@CacheLookup
	WebElement ClickOnWorkBasketForPersonalWorkQueueInQ;

	// ClickOnManageWorkQueues
	@FindBy(xpath = "//span[@data-test-id='20160628111645087532585']")
	@CacheLookup
	WebElement ClickOnWorkBasketForPersonalWorkQueueInQBusinessBucket;

	// ClickOnBusinessWorkBasetForPersonalWorkQueue
	@FindBy(xpath = "//span[text()='Business Workbaskets']")
	@CacheLookup
	WebElement ClickOnBusinessWorkBasetForPersonalWorkQueue;

	// ClickOnBusinessWorkBasetForPersonalWorkQueue
	@FindBy(xpath = "//button[text()='New Dispute Basket']")
	@CacheLookup
	WebElement ClickOnNewDisputeBasket;

	// CompanNameForBusinessWorkBasket
	@FindBy(xpath = "//input[@name='$PNewWB$ppyWorkBasket']")
	@CacheLookup
	WebElement CompanyNameForBusinessWorkBasket;

	// CompanyCodeNameForBusinessWorkBasket
	@FindBy(xpath = "//input[@name='$PNewWB$pCompanyCode']")
	@CacheLookup
	WebElement CompanyCodeNameForBusinessWorkBasket;

	// ClickOnSubmitForBusinessWorkBasket
	@FindBy(xpath = "//button[text()='  Submit ']")
	@CacheLookup
	WebElement ClickOnSubmitForBusinessWorkBasket;

	// ClickOnSubmitForBusinessWorkBasket
	@FindBy(xpath = "//td[8]/div/span/a")
	@CacheLookup
	WebElement ClickOnChangeAvailabilityForBusinessWorkBasket;

	@FindBy(xpath = "//tr[contains(@id,'$PD_CustomersForCustomerManagement$pp')][1]/td[@data-attribute-name='Main?']//input[2] | //tr[contains(@id,'$PD_CustomersForCustomerManagement$pp')][2]/td[@data-attribute-name='Main?']//input[2]")
	@CacheLookup
	List<WebElement> Checking_main;

	// ClickOnSubmitForBusinessWorkBasket
	@FindBy(xpath = "//i[@data-test-id='20161122052049027253737']")
	@CacheLookup
	WebElement ClickOnTrashIconForBusinessWorkBasket;

	// ClickOnAnyOneWorkbasketForBusinessWorkBasket
	@FindBy(xpath = "//span[@data-test-id='20160628111645087532585']")
	@CacheLookup
	WebElement ClickOnAnyOneWorkbasketForBusinessWorkBasket;

	// ClickOnAddItemForBusinessWorkBasket
	@FindBy(xpath = "//a[text()='Add item']")
	@CacheLookup
	WebElement ClickOnAddItemForBusinessWorkBasket;

	// AddEmailForBusinessWorkBasket
	@FindBy(xpath = "//input[@name='$PpyWorkPage$ppyHolder$pContactEmailList$l1$ppyValue']")
	@CacheLookup
	WebElement AddEmailForBusinessWorkBasket;

	// AddEmailForBusinessWorkBasket
	@FindBy(xpath = "(//h3[text()='Work queue'])[2]")
	@CacheLookup
	WebElement ClickOnWorkQueuesInMyWorkPage;

	// ClickOnAddWorkBasket
	@FindBy(xpath = "//button[text()='Add to Workbasket']")
	@CacheLookup
	WebElement ClickOnAddWorkBasket;

	// ClickOnManageWorkQueueSubmit
	@FindBy(xpath = "//button[text()='  Submit ']")
	@CacheLookup
	WebElement ClickOnManageWorkQueueSubmit;
	@FindBy(xpath = "//h2[text()='Advanced Item filters']//following::div[2]/descendant::a[text()='Add item']")
	////div[@id='po0']
	@CacheLookup
	WebElement Advanced_Item;
	// ClickOnManageWorkQueueSubmit
	@FindBy(xpath = "(//*[@id=\"$POperatorID$ppyWorkBasketList$l1\"]/td[1]/div/text())[2]")
	@CacheLookup
	WebElement VerifyAddedWorkBasket;

	// ClickOnsendEmail
	@FindBy(xpath = "//input[@class='tcright autocomplete_input ac_ ui-autocomplete-input']")
	@CacheLookup
	WebElement ClickOnSelectUserId;

	// ClickOnEmailOption
	@FindBy(xpath = "//div[text()='DH Pradeep / GBS O2C IN O2I ES1 APD-1 / BLR SA']")
	@CacheLookup
	WebElement SelectGID;

//ReAssignStrategy

	// ClickOnEmailOption
	@FindBy(xpath = "//span[text()='Strategies']")
	@CacheLookup
	WebElement ClickOnStrategyFromBurgerMenu;

	// VerifyStrategiesPageForManager
	@FindBy(xpath = "//a[text()='Create new strategy...']")
	@CacheLookup
	WebElement VerifyStrategiesPageForManager;

	// ClickOnStrategyforUpdate
	@FindBy(xpath = "//div[@class='content-inner ']//span[text()='ST-720']")
	@CacheLookup
	WebElement ClickOnStrategyforUpdate;

	// ClickOnother'swork
	@FindBy(xpath = "(//span[contains(text(),'Other User')])[1]")
	@CacheLookup
	WebElement Clickonother_work;

	// ClickOnStrategyforUpdate
	@FindBy(xpath = "//div[@class='content-inner ']//span[text()='ST-122']")
	@CacheLookup
	WebElement ClickOnStrategyforUpdateInQ;

	// ClickOnactionInStrategypage
	@FindBy(xpath = "//button[@name='pyCaseHeaderButtons_pyWorkPage_4']")
	@CacheLookup
	WebElement ClickOnactionInStrategypage;


	// ClickOnactionInStrategypage
	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span")
	@CacheLookup
	WebElement Line_item;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[14]//span/span")
	@CacheLookup
	WebElement Line_item_IN;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Assignment']//tbody//td")
	@CacheLookup
	WebElement Line_item_MX;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='No doc.']//div")
	@CacheLookup
	WebElement Line_item_SHS;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Reference']//div")
	@CacheLookup
	WebElement Line_item_US33;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Reference']//div")
	@CacheLookup
	WebElement Line_item_US2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='No doc.']//div")
	@CacheLookup
	WebElement Line_item_SHS2;


	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Reference']//span")
	@CacheLookup
	WebElement Line_item_FBA;
	String value;
	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Reference']//span")
	@CacheLookup
	WebElement Line_item_FBA2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Document No.']//span")
	@CacheLookup
	WebElement Line_item_AU1;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Document No.']//span")
	@CacheLookup
	WebElement Line_item_AU12;


	@FindBy(xpath = "//a[@name='pyPortalHeader_pyDisplayHarness_30']")
	@CacheLookup
	WebElement element_search;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Doc Number')]//span")
	@CacheLookup
	WebElement Line_item__IN;
	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Doc Number')]//span")
	@CacheLookup
	WebElement Line_item__IN2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Doc Number')]//span")
	@CacheLookup
	WebElement Line_item_AU12_IN;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Document')]//span")
	@CacheLookup
	WebElement Line_item_MY;


	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Document')]//span")
	@CacheLookup
	WebElement Line_item_MY2;
	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//following::td[contains(@data-attribute-name,'Doc. Num.')][1]/div)[1]")
	@CacheLookup
	WebElement Line_item_FR2;

	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//following::td[contains(@data-attribute-name,'Doc. Num.')][1]/div)[1]")
	@CacheLookup
	WebElement Line_item_FR;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Doc. No.']/div")
	@CacheLookup
	WebElement Line_item_PT;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='No. Doc.']/div")
	@CacheLookup
	WebElement Line_item_PT1;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Document No.']/div")
	@CacheLookup
	WebElement Line_item_AU;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Document No.']/div")
	@CacheLookup
	WebElement Line_item_AU_12;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='No. Doc.']/div")
	@CacheLookup
	WebElement Line_item_PT2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Doc.')]/div")
	@CacheLookup
	WebElement Line_item_CA_GP;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Doc.')]/div")
	@CacheLookup
	WebElement Line_item_CA_GP2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Doc. No.']/div")
	@CacheLookup
	WebElement Line_item2_PT;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Assignment']//tbody//td")
	@CacheLookup
	WebElement Line_item_MX2;


	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[14]//span/span")
	@CacheLookup
	WebElement Line_item_IN_2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[7]//span")
	@CacheLookup
	WebElement Line_item_HC;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Ref. No.']//span")
	@CacheLookup
	WebElement Line_item_IT22;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Ref. No.']//span")
	@CacheLookup
	WebElement Line_item_IT222;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Referenz']//span")
	@CacheLookup
	WebElement Line_item_CH;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Referenz']//span")
	@CacheLookup
	WebElement Line_item_CH2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[contains(@data-attribute-name,'Doc No.')][1]/descendant::span[2]")
	@CacheLookup
	WebElement Line_item_HC_MES;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//td[contains(@data-attribute-name,'Doc No.')][1]/descendant::span[2]")
	@CacheLookup
	WebElement Line2_item_HC_MES;

	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]")
	@CacheLookup
	WebElement Line_item_SI;

	@FindBy(xpath = "//a[@name='pyPortalHeader_pyDisplayHarness_30']")
	@CacheLookup
	WebElement customer_2;

	@FindBy(xpath = "//div[@id='po0']/descendant::label[text()='Search Text']/following::input")
	@CacheLookup
	WebElement Serach_inputbox;



	//div[@id='po0']/descendant::label[text()='Search Text']/following::input



	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Doc. Num.']//span")
	@CacheLookup
	WebElement Line_item_IT;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Doc. Num.']//span")
	@CacheLookup
	WebElement Line_item2_IT;

	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]")
	@CacheLookup
	WebElement Line_item_CA;


	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span)[1]")
	@CacheLookup
	WebElement Line2_item_CA;
	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[6]//span")
	@CacheLookup
	WebElement Line_item_DE;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[6]//span")
	@CacheLookup
	WebElement Line_item_DE2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span")
	@CacheLookup
	WebElement Line_item_GP;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[5]//span")
	@CacheLookup
	WebElement Line_item_GP1;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span")
	@CacheLookup
	WebElement Line_item_GP2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[7]//span")
	@CacheLookup
	WebElement Line_item_SEU;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[7]//span")
	@CacheLookup
	WebElement Line_item_SEU2;

	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[3]//span)[1]")
	@CacheLookup
	WebElement Line2_item_SI;

	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[3]//span)[1]")
	@CacheLookup
	WebElement Line2_item_SI1;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span")
	@CacheLookup
	WebElement Line2_item_GP;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[5]//span")
	@CacheLookup
	WebElement Line2_item_GP2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span")
	@CacheLookup
	WebElement Line21_item_GP2;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span")
	@CacheLookup
	WebElement Line2_item_UK;

	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[5]//span")
	@CacheLookup
	WebElement Line2_item_HC;

	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[3]//span)[2]")
	@CacheLookup
	WebElement Line_item_US;

	@FindBy(xpath = "(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[3]//span)[2]")
	@CacheLookup
	WebElement Line2_item_US;


	// ClickOnactionInStrategypage
	@FindBy(xpath = "//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span")
	@CacheLookup
	WebElement Line_item2;
	@FindBy(xpath = "//span[text()='        Edit contacts       ']/following::button[text()='  Update ']")
	@CacheLookup
	WebElement ClickOnUpdate;

	@FindBy(xpath = "(//tr[contains(@id,'$PD_CollectionsByCustomerSearch_pa')])[1]//td[1]")
	@CacheLookup
	WebElement qaCollectionElement;

	@FindBy(xpath = "//div[@class='content-item content-field item-1   dataValueRead flex flex-row ']//span[text()='My Customers']")
	@CacheLookup
	WebElement MY_customer_search;

	// ClickOnModifyStrategy
	@FindBy(xpath = "//span[text()='Modify strategy']")
	@CacheLookup
	WebElement ClickOnModifyStrategy;

	// ClickonAddItemInCalanderBasedActionStrategy
	@FindBy(xpath = "(//a[@name='pzPegaDefaultGridIcons_pyWorkPage_4'])[2]")
	@CacheLookup
	WebElement ClickonAddItemInCalanderBasedActionStrategy;

	// ClickonAddAction
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pActionList$l3$ppyLabel']")
	@CacheLookup
	WebElement ClickonAddAction;

	// ClickonAddAction
	@FindBy(xpath = "//span[text()='Balance Confirmation']")
	@CacheLookup
	WebElement ClickonSelectAction;

	// ClickonAddAction
	@FindBy(xpath = "//span[text()='Balance']")
	@CacheLookup
	WebElement ClickonSelectActionInQ;

	// ClickonAddActionLabel
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pActionList$l3$pActionLabel']")
	@CacheLookup
	WebElement ClickonAddActionLabel;

	// ClickonSelectfrequency
	@FindBy(xpath = "//select[@name='$PpyWorkPage$pActionList$l3$pActionSchedule$ppyRecFrequency']")
	@CacheLookup
	WebElement ClickonSelectfrequency;

	// ClickonAddItemInAdvanceItemFilterStrategy
	@FindBy(xpath = "(//a[text()='Add item'])[3]")
	@CacheLookup
	WebElement ClickonAddItemInAdvanceItemFilterStrategy;

	// ClickonListItempropertyStrategy
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pActionList$l3$pAdvLineItemFilters$l1$pAdvancedProperty$ppyLabel']")
	@CacheLookup
	WebElement ClickonListItempropertyStrategy;

	// SelectIspromiseToPay
	@FindBy(xpath = "//span[text()='Is Promised to Pay']")
	@CacheLookup
	WebElement SelectIspromiseToPay;

	// SubmitButtonInStrategy
	@FindBy(xpath = "//button[text()='  Submit ']")
	@CacheLookup
	WebElement SubmitButtonInStrategy;

	// SubmitButtonInStrategy
	@FindBy(xpath = "//button[text()='Submit']")
	@CacheLookup
	WebElement FinalSubmitButtonInStrategy;

	// ClickOnRecentattach
	@FindBy(xpath = "//a[@id='att_feed_desc_1639643048723']")
	@CacheLookup
	WebElement ClickOnRecentattach;

	// ClickOnRefreshrecentTask
	@FindBy(xpath = "//a[@id='att_feed_desc_1639643048723']")
	@CacheLookup
	WebElement ClickOnRefreshrecentTask;

	@FindBy(xpath = "//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")
	@CacheLookup
	WebElement Apply_button_p2p;

	@FindBy(xpath = "//label[contains(text(),'Name, Number')]//following-sibling::div//input")
	@CacheLookup
	WebElement EnterCustomerNumberSearch1;

//Campaigns

	// ClickOnCampaignsFromBurgerMenu
	@FindBy(xpath = "//span[text()='Campaigns']")
	@CacheLookup
	WebElement ClickOnCampaignsFromBurgerMenu;

	// ClickOnStrategyforUpdate
	@FindBy(xpath = "//div[@class='content-inner ']//span[text()='CAMP-116']")
	@CacheLookup
	WebElement ClickOnStrategyforUpdat;

	// ClickOnactionInStrategypage
	@FindBy(xpath = "//button[@name='pyCaseHeaderButtons_pyWorkPage_4']")
	@CacheLookup
	WebElement ClickOnActionInCamaignspage;

	// ClickOnModifyStrategy
	@FindBy(xpath = "//span[text()='Modify Campaign']")
	@CacheLookup
	WebElement ClickOnModifyCampaigns;

	// ClickonAddItemInCalanderBasedActionStrategy
	@FindBy(xpath = "//a[@name='pzPegaDefaultGridIcons_pyWorkPage_4']")
	@CacheLookup
	WebElement ClickonAddItemActionsCampaigns;

	// ClickonAddAction
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pFixedActionList$l1$ppyLabel']")
	@CacheLookup
	WebElement ClickonAddActionInCampaigns;

	// ClickonAddActionLabel
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pFixedActionList$l1$pActionLabel']")
	@CacheLookup
	WebElement ClickonAddActionLabelInCampaigns;

	// ClickonAddItemInAdvanceItemFilterStrategy
	@FindBy(xpath = "(//a[@name='pzPegaDefaultGridIcons_pyWorkPage.FixedActionList(1)_4'])[3]")
	@CacheLookup
	WebElement ClickonAddItemInAdvanceItemFilterCampaigns;

	// ClickonListItempropertyStrategy
	@FindBy(xpath = "//input[@name='$PpyWorkPage$pFixedActionList$l1$pAdvLineItemFilters$l1$pAdvancedProperty$ppyLabel']")
	@CacheLookup
	WebElement ClickonListItempropertyCampaigns;

	// SelectIspromiseToPay
	@FindBy(xpath = "//span[.='Is Promised to Pay']")
	@CacheLookup
	WebElement SelectIspromiseToPayInCampaigns;

	// SubmitButtonInStrategy
	@FindBy(xpath = "//button[text()='  Submit ']")
	@CacheLookup
	WebElement SubmitButtonInCampaigns;

	// SubmitButtonInStrategy
	@FindBy(xpath = "//button[text()='Submit']")
	@CacheLookup
	WebElement FinalSubmitButtonInCampaigns;

	// SubmitButtonInStrategy
	@FindBy(xpath = "//button[text()='Schedule Campaign']")
	@CacheLookup
	WebElement ClickOnScheduleCampaigns;

	// SubmitButtonInStrategy
	@FindBy(xpath = "//div[text()='Scheduled']")
	@CacheLookup
	WebElement VerifyScheduledCampaignsStatus;

	// SubmitButtonInStrategy
	@FindBy(xpath = "//button[text()='  Accept ']")
	@CacheLookup
	WebElement ClickOnAcceptButtonForScheduleCampaigns;

	// BackToCampaigns
	@FindBy(xpath = "(//span[text()='Campaigns'])[2]")
	@CacheLookup
	WebElement ClickOnBackToCampaigns;

	// BackToCampaigns
	@FindBy(xpath = "//i[@name='ApplicationCampaigns_pyDisplayHarness_68']")
	@CacheLookup
	WebElement ClickOnRefreshCampaigns;

	// ClickOnNewCampaigns
	@FindBy(xpath = "//a[text()='Create new campaign...']")
	@CacheLookup
	WebElement ClickOnNewCampaigns;

	// ClickOnCampaignName
	@FindBy(xpath = "//input[@name='$PpyWorkPage$ppyLabel']")
	@CacheLookup
	WebElement ClickOnCampaignName;

//DashBoard

	// ClickOnEmailOption
	@FindBy(xpath = "//span[text()='Dashboard']")
	@CacheLookup
	WebElement ClickOnDashBoardFromBurgerMenu;

	// ClickOnEmailOption
	@FindBy(xpath = "//h2[text()='Under the Hood']")
	@CacheLookup
	WebElement ClickOnUnderTheHood;

	// ClickOnEmailOption
	@FindBy(xpath = "//h2[text()='Global Under the Hood']")
	@CacheLookup
	WebElement ClickOnGlobalUnderTheHood;

	// ClickOnEmailOption
	@FindBy(xpath = "//h2[text()='Listener Management']")
	@CacheLookup
	WebElement ClickOnListnerManagement;

//SortIng&Filtering

	// ClickOnEmailOption
	@FindBy(xpath = "//div[text()='Category']")
	@CacheLookup
	WebElement ClickOnSortOptionForCategory;

	// ClickOnEmailOption
	@FindBy(xpath = "//span[@class='highlight-ele  pointerStyle ASC']")
	@CacheLookup
	WebElement ClickOnDescendingSortArrowOptionForCategory;

	// ClickOnEmailOption
	@FindBy(xpath = "//span[text()='AddContact']")
	@CacheLookup
	WebElement VerifyAscendingForCategory;

	// ClickOnEmailOption
	@FindBy(xpath = "(//span[text()='ReviewStrategy'])[1]")
	@CacheLookup
	WebElement VerifyDescendingForCategory;

//ProfileEdit

	// ClickOnEmailOption
	@FindBy(xpath = "//span[text()='Profile']")
	@CacheLookup
	WebElement ClickOnprofileInMyAccount;

	// ClickOnEmailOption
	@FindBy(xpath = "//a[text()='Edit']")
	@CacheLookup
	WebElement ClickOnEditForAboutYourProfile;

	// ClickOnEmailOption
	@FindBy(xpath = "//textarea[@name='$PSocialUserProfile$ppyDescription']")
	@CacheLookup
	WebElement AddboutMe;

	// ClickOnEmailOption
	@FindBy(xpath = "//button[text()='  Submit ']")
	@CacheLookup
	WebElement ClickOnSubmitAboutMePage;

	// ClickOnEmailOption
	@FindBy(xpath = "//a[text()='Edit signature']")
	@CacheLookup
	WebElement ClickOnEdiSignature;

	@FindBy(xpath = "//td[@data-attribute-name='Cust. No.']//span")
	@CacheLookup
	List<WebElement> collectionlist;

	// ClickOnEmailOption
	@FindBy(xpath = "//span[text()='Pradeep Software Test Specialist In Automation']")
	@CacheLookup
	WebElement VerifyAddAboutMe;

//ItemSearch

	// ClickOnItemSearch
	@FindBy(xpath = "//span[text()='Item Search']")
	@CacheLookup
	WebElement ClickOnItemSearch;

	// ClickOnItemSearch
	@FindBy(xpath = "//input[@name='$PpyDisplayHarness$pSearchString']")
	@CacheLookup
	WebElement CustomerAndItemSearch;

	// ClickOnItemSearch
	@FindBy(xpath = "//button[text()='Search']")
	@CacheLookup
	WebElement ClickOnSearchButtonInCustmerAndItemSearchPage;

	// VeriFySearchedReferenceNumber
	@FindBy(xpath = "//div[text()=' CO-1474452']")
	@CacheLookup
	WebElement VeriFySearchedReferenceNumber;

	// VeriFySearchedReferenceNumber
	@FindBy(xpath = "//div[text()=' CO-5346206']")
	@CacheLookup
	WebElement VeriFySearchedReferenceNumberInQ;

	// VeriFySearchedReferenceNumber
	@FindBy(xpath = "//div[text()=' CO-5319848']")
	@CacheLookup
	WebElement VeriFySearchedReferenceNumberInQUKRC;

	// VeriFySearchedReferenceNumber
	@FindBy(xpath = "//div[@class='content-item content-field item-2']/child::div//span[.='CO-1474452']")
	@CacheLookup
	WebElement VeriFyCustomerDisplayed;

	//
	@FindBy(xpath = "(//div[text()='Note'])[1]/following::td[1]/div//div/div")
	@CacheLookup
	WebElement History_Note;

	@FindBy(xpath = "(//div[text()='Note'])[1]/following::td[1]/div//div/div/p")
	@CacheLookup
	WebElement History_Note1;

	//
	@FindBy(xpath = "//*[text()='Bulk Selection']")
	@CacheLookup
	WebElement Bulk_Section;

	//
	@FindBy(xpath = "//a[text()='Show History']")
	@CacheLookup
	WebElement Click_showHistory;

	// VeriFySearchedReferenceNumber
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[text()='CO-5346206']")
	@CacheLookup
	WebElement VeriFyCustomerDisplayedInQ;

	// VeriFySearchedReferenceNumber
	@FindBy(xpath = "(//td[text()=' Dispute Business Follow Up Call  '])[1]")
	@CacheLookup
	WebElement Dispute_Task;

	// VeriFySearchedReferenceNumber
	@FindBy(xpath = "//div[@class='field-item dataValueRead']//span[text()='CO-5319848']")
	@CacheLookup
	WebElement VeriFyCustomerDisplayedInQUKRC;

//BulkaAssignEmails

	// ClickOnBulkAssignemails
	@FindBy(xpath = "//span[text()='Bulk Assign Emails']")
	@CacheLookup
	WebElement ClickOnBulkAssignemails;

	// EnterCustomerNoInBulkAssignEmailsPage
	@FindBy(xpath = "//div[@class='content-item content-field item-1']//child::input")
	@CacheLookup
	WebElement EnterCustomerNoInBulkAssignEmailsPage;

	// ClickOnSearchButtonInBulkAssigEmailsPage
	@FindBy(xpath = "//div[@class='content-item content-field item-1']//child::input//following::div[3]//child::i")
	@CacheLookup
	WebElement ClickOnSearchButtonInBulkAssigEmailsPage;

	// ClickOnRadioButtonInBulkAssignEmailsPage
	@FindBy(xpath = "//*[@id=\"$PD_CustomerSearchWithEmail_pa36672061582130pz$ppxResults$l1\"]/td[1]/div/input[2]")
	@CacheLookup
	WebElement ClickOnRadioButtonInBulkAssignEmailsPage;

	// ClickOnSearchButtonInBulkAssigEmailsPage
	@FindBy(xpath = "//button[text()='Assign']")
	@CacheLookup
	WebElement ClickOnassignInBulkAssigEmailsPage;

//MyWorkTales

	// ClickOnOverDuetask
	@FindBy(xpath = "//span[text()='Overdue Tasks']")
	@CacheLookup
	WebElement ClickOnOverDuetask;

	// AllOverDuetask
	@FindBy(xpath = "//i[@data-test-id='2017050216484304894957']")
	@CacheLookup
	List<WebElement> AllTask;

	// AllOverDuetask
	@FindBy(xpath = "//tbody//tr[@class='oddRow cellCont']")
	@CacheLookup
	List<WebElement> AllTask1;

	// VerifyOverDueTask
	@FindBy(xpath = "//span[@data-test-id='20160606052543041811468']")
	@CacheLookup
	List<WebElement> VerifyOverDueTask;

	// VerifyOverDueTask
	@FindBy(xpath = "//span[@data-test-id='20160606052543041811468']")
	@CacheLookup
	WebElement VerifyOverDueTaskText;

	// VerifyMyTask
	@FindBy(xpath = "//span[@data-test-id='2016060711510609498166']")
	@CacheLookup
	WebElement VerifyMyTask;

	// collect name
	@FindBy(xpath = "(//div[text()='Note'])[1]/following::td[2]//span")
	@CacheLookup
	WebElement Verifycollector;

	// VerifyMyTask
	@FindBy(xpath = "//span[@data-test-id='2016060711510609498166']")
	@CacheLookup
	List<WebElement> VerifyMyTaskAll;

	@FindBy(xpath = "//h2[contains(text(),'Collection')]/following::tr[contains(@id,'$PD_CustomersForCustomerManagement$ppxResults$l1')]/td[@data-attribute-name='ARE']//span")
	@CacheLookup
	WebElement CC;

	// VerifyMyTask
	@FindBy(xpath = "//span[@data-test-id='20160606052539092622692']")
	@CacheLookup
	WebElement VerifyMyCustomer;


	@FindBy(xpath = "(//*[contains(text(),'Add category')])[1]")
	@CacheLookup
	WebElement Click_addcategory;

	@FindBy(xpath = "(//*[contains(text(),'Add report')])[1]")
	@CacheLookup
	WebElement Click_addreport;
	@FindBy(xpath = "//button[contains(text(),'Resolve')]")
	@CacheLookup
	WebElement Click_on_Reslove;
	// VerifyMyTask
	@FindBy(xpath = "//span[@data-test-id='20160606052539092622692']")
	@CacheLookup
	List<WebElement> VerifyMyCustomerAll;

	// VerifyUnAssignedEmail
	@FindBy(xpath = "(//span[@data-test-id='20160606052539092622692'])[2]")
	@CacheLookup
	WebElement VerifyUnAssignedEmail;

	// VerifyUnAssignedEmail
	@FindBy(xpath = "(//span[@data-test-id='20160606052539092622692'])[2]")
	@CacheLookup
	List<WebElement> VerifyUnAssignedEmailAll;

	// VerifyMyOpenDisputes
	@FindBy(xpath = "//span[@data-test-id='20160606052542010422459']")
	@CacheLookup
	WebElement VerifyMyOpenDisputes;


	// VerifyMyOpenDisputes
	@FindBy(xpath = "//div[contains(text(),'Name')]/following::button[contains(text(),'Attach')]")
	@CacheLookup
	WebElement Click_Attach;

	// VerifyMyOpenDisputes
	@FindBy(xpath = "//span[@data-test-id='20160606052542010422459']")
	@CacheLookup
	List<WebElement> VerifyMyOpenDisputesAll;

	// VerifyPromiseToPayInMyTaskpage
	@FindBy(xpath = "(//span[@data-test-id='20160606052539092622692'])[3]")
	@CacheLookup
	WebElement VerifyPromiseToPayInMyTaskpage;

	// VerifyPromiseToPayInMyTaskpage
	@FindBy(xpath = "(//span[@data-test-id='20160606052539092622692'])[3]")
	@CacheLookup
	List<WebElement> VerifyPromiseToPayInMyTaskpageAll;

	// ClickonMyTask
	@FindBy(xpath = "//span[text()='My Tasks']")
	@CacheLookup
	WebElement ClickonMyTask;

	// ClickonMyTask
	@FindBy(xpath = "//span[text()='My Tasks']")
	@CacheLookup
	WebElement AllMyTask;

	// ClickOnLegalAssignment
	@FindBy(xpath = "//span[text()='Legal Assignments']")
	@CacheLookup
	WebElement ClickOnLegalAssignment;

	// ClickOnpendingLegal
	@FindBy(xpath = "//span[text()='Pending Legal']")
	@CacheLookup
	WebElement ClickOnPendingLegal;

	// ClickOnPromisedToPayInMyWorkPage
	@FindBy(xpath = "//span[text()='Promised to Pay']")
	@CacheLookup
	WebElement ClickOnPromisedToPayInMyWorkPage;

	// ClickOnPromisedToPayInMyWorkPage
	@FindBy(xpath = "//span[text()='My Open Disputes']")
	@CacheLookup
	WebElement ClickOnMyOPenDisputesInMyWorkPage;

	// ClickOnPromisedToPayInMyWorkPage
	@FindBy(xpath = "//div[@data-test-id='20141121165713062143523']")
	@CacheLookup
	WebElement ClickOnNext;

	@FindBy(xpath = "//td[@data-attribute-name='Cust. No.']//span")
	@CacheLookup
	List<WebElement> elements;

	// ClickOnPromisedToPayInMyWorkPage
	@FindBy(xpath = "//input[contains(@name,'$PpyAttachmentPage$ppxAttachName')]")
	@CacheLookup
	WebElement Select_File_button;

//Customer-Sync

	// ClickOnCustomerMasterSyncFromBurgerMenu
	@FindBy(xpath = "//span[text()='Customer Master Sync']")
	@CacheLookup
	WebElement ClickOnCustomerMasterSyncFromBurgerMenu;

	// EnterCompanyCodeInCustomerMasterSync
	@FindBy(xpath = "//input[@name='$PpyDisplayHarness$pTempValueList$l1']")
	@CacheLookup
	WebElement EnterCompanyCodeInCustomerMasterSync;

	// EnterCustomerNumberInCustomerMasterSync
	@FindBy(xpath = "//input[@name='$PpyDisplayHarness$pTempValueList$l2']")
	@CacheLookup
	WebElement EnterCustomerNumberInCustomerMasterSync;

	// EnterSystemInCustomerMasterSync
	@FindBy(xpath = "//input[@name='$PpyDisplayHarness$pTempValueList$l3']")
	@CacheLookup
	WebElement EnterSystemInCustomerMasterSync;

	// EnterSystemInCustomerMasterSync
	@FindBy(xpath = "//button[text()='Import']")
	@CacheLookup
	WebElement ClickOnImportInCustomerMasterSync;

	// VerifyImportInCustomerMasterSync
	@FindBy(xpath = "//span[@data-test-id='20181127151949096615367']")
	@CacheLookup
	WebElement VerifyImportInCustomerMasterSync;

	@FindBy(xpath = "//button[contains(text(),'Actions')]")
	@CacheLookup
	WebElement Click_on_Actions;


	@FindBy(xpath = "//span[contains(text(),'Bulk actions')]")
	@CacheLookup
	WebElement Select_Bulkactions;


	@FindBy(xpath = "//span[contains(text(),'Availability')]")
	@CacheLookup
	WebElement Select_Availability;

//Customer Assign

	// ClickOnCashCollectorFromBurgerMenu
	@FindBy(xpath = "//span[text()='Cash collectors']")
	@CacheLookup
	WebElement ClickOnCashCollectorFromBurgerMenu;

	// ClickOnAssignForCashCollector
	@FindBy(xpath = "//a[text()='Assign']")
	@CacheLookup
	WebElement ClickOnAssignForCashCollector;

	// ClickOnSearchCashCollector
	@FindBy(xpath = "//input[@data-test-id='201605090845340057313456']")
	@CacheLookup
	WebElement ClickOnSearchCashCollector;

	// ClickOnSearchCashCollector
	@FindBy(xpath = "  //button[text()='  Submit '] ")
	@CacheLookup
	WebElement ClickOnSubmitButtonInCashCollector;

	// verify the Bu name in Dispute page
	@FindBy(xpath = "//span[contains(text(),'Business User')]//following-sibling::div/span")
	@CacheLookup
	WebElement Select_BUname;

	// ClickOnSearchCashCollector
	@FindBy(xpath = "//td//div//input[@type='radio']")
	@CacheLookup
	WebElement ClickOnRadioButtonInCashCollectorAssignPage;

//Reports

	// ClickOnReportsFromBurgerMenu
	@FindBy(xpath = "//span[text()='Reports']")
	@CacheLookup
	WebElement ClickOnReportsFromBurgerMenu;

	// ClickOnReportAddReport
	@FindBy(xpath = "//div[text()='Add report']")
	@CacheLookup
	WebElement ClickOnAddReport;

	// ClickOnCaseTypeForReport
	@FindBy(xpath = "//select[@name='$PTempNewReportPage$ppyClassName']")
	@CacheLookup
	WebElement ClickOnCaseTypeForReport;

	// ClickOnReportType
	@FindBy(xpath = "//select[@name='$PTempNewReportPage$ppyVersion']")
	@CacheLookup
	WebElement ClickOnReportType;

	// ClickOnSubmitForReport
	@FindBy(xpath = "//button[text()='Submit']")
	@CacheLookup
	WebElement ClickOnSubmitForReport;

	// ClickOnDoneEditingForReport
	@FindBy(xpath = "//button[text()='Done editing']")
	@CacheLookup
	WebElement ClickOnDoneEditingForReport;

	// ClickOnUpdateInLas7tDays
	@FindBy(xpath = "//a[text()=' Updated In Last 7 Days ']")
	@CacheLookup
	WebElement ClickOnUpdateInLas7tDays;

	// ClickOnSelectvalues
	@FindBy(xpath = "//button[text()='Select values']")
	@CacheLookup
	WebElement ClickOnSelectvalues;

	// ClickOnSelectvalues
	@FindBy(xpath = "//select[@name='$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBody$ppyUIFilters$ppyFilter$l1$ppyLabel']")
	@CacheLookup
	WebElement ClickOnSelectValuesForSelect;

	// ClickOnSelectvalues
	@FindBy(xpath = "//option[text()='Last 30 Days']")
	@CacheLookup
	WebElement SelectSelectedvalues;

	// TitleForReport
	@FindBy(xpath = "(//input[@name='$PpyReportContentPage$ppyReportDefinition$ppyReportTitle'])[1]")
	@CacheLookup
	WebElement TitleForReport;

	// TitleForReport
	@FindBy(xpath = "//textarea[@name='$PpyReportContentPage$ppyReportDefinition$ppyDescription']")
	@CacheLookup
	WebElement DescriptionForReport;

	// ClickOnSubmitInSaveReportPage
	@FindBy(xpath = "//button[text()='  Submit ']")
	@CacheLookup
	WebElement ClickOnSubmitInSaveReportPage;

	// ClickOnSubmitInSaveReportPage
	@FindBy(xpath = "(//span[text()='Reports'])[2]")
	@CacheLookup
	WebElement ClickOnBackReport;

	// ClickOnSubmitInSaveReportPage
	@FindBy(xpath = "//span[contains(text(),'Customer Master Sync')]")
	@CacheLookup
	WebElement Customer_sync;

	// ClickOnSubmitInSaveReportPage
	@FindBy(xpath = "//i//img[@name='pyReportEditorHeader_pyReportContentPage_19']")
	@CacheLookup
	WebElement ClickOnCloseEditReportPage;

	@FindBy(xpath = "//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppySearchForProperty')]")
	@CacheLookup
	WebElement Search_box;

	// ClickOnSubmitInSaveReportPage
	@FindBy(xpath = "//h1[contains(text(),'Collection')]//following::i[7]")
	@CacheLookup
	WebElement Click_on_Infromation;

	@FindBy(xpath = "//h1[contains(text(),'Collection')]//following::i[7]")
	@CacheLookup
	WebElement Click_on_Infromation1;

	// ClickOnTakeOnActionOnReport
	@FindBy(xpath = "//a[@data-test-id='20141006144255036955948']")
	@CacheLookup
	WebElement ClickOnTakeOnActionOnReport;

	// ClickOnMoveReport
	@FindBy(xpath = "//span[text()='Move']")
	@CacheLookup
	WebElement ClickOnMoveReport;

	// ClickOnMoveReport
	@FindBy(xpath = "//span[text()='Copy']")
	@CacheLookup
	WebElement ClickOnCopyReport;

	// ClickOnMoveReport
	@FindBy(xpath = "//span[text()='Delete']")
	@CacheLookup
	WebElement ClickOnDeleteReport;

	@FindBy(xpath = "//label[contains(text(),'Company Code')]/following-sibling::div//input")
	@CacheLookup
	WebElement Enter_customercode;


	@FindBy(xpath = "//label[contains(text(),'Customer Number')]/following-sibling::div//input")
	@CacheLookup
	WebElement Enter_customernumber;


	@FindBy(xpath = "//label[contains(text(),'System')]/following-sibling::div//input")
	@CacheLookup
	WebElement Enter_System;

	// ClickOnScheduleReport
	@FindBy(xpath = "//span[text()='Schedule']")
	@CacheLookup
	WebElement ClickOnScheduleReport;

	@FindBy(xpath = "(//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyReportTitle')])[1]")
	@CacheLookup
	WebElement Tittle;

	// ClickOnScheduleReport
	@FindBy(xpath = "//select[@name='$PpyWorkPage$ppyTaskScheduling$ppyTimeOfDay']")
	@CacheLookup
	WebElement ClickOnTimeofDayforScheduleReport;

	// ClickOnScheduleReport
	@FindBy(xpath = "//button[@class='iconInsert']")
	@CacheLookup
	WebElement ClickOnAddUser;

	@FindBy(xpath = "//span[contains(text(),'Reports')]")
	@CacheLookup
	WebElement Click_on_Reports;


	// ClickOnScheduleReport
	@FindBy(xpath = "//button[@class='iconInsert']")
	@CacheLookup
	WebElement EnterAddUsername;


	@FindBy(xpath = "//tr[contains(@id,'$PD_AllCustomersForCustomerManagement_pa')][1]/td[7]//a")
	@CacheLookup
	WebElement Click_on_Add;
	// ClickOnSelectUserInScheduleReport
	@FindBy(xpath = "//span[text()='Saleem Pasha']")
	@CacheLookup
	WebElement ClickOnSelectUserInScheduleReport;

	// ClickOnSelectUserInScheduleReport
	@FindBy(xpath = "//div[text()='Submit']")
	@CacheLookup
	WebElement ClickOnSubmitButtonrInScheduleReport;

	//QA
	// ClickOnItemInQA
	@FindBy(xpath = "//span[text()='0952354932']")
	@CacheLookup
	WebElement ClickOnItemInQA;

	String ItemFrame = "PegaGadget1Ifr";

	String InsideItem = "PegaGadget2Ifr";

	String UpdateFrame = "PegaGadget3Ifr";
	String Frane4 = "PegaGadget4Ifr";

	String CustomerFrameId = "PegaGadget0Ifr";

	public void IsHomePageDisplayed() throws InterruptedException {
		Thread.sleep(5000);
		Assert.assertTrue(mywork.isDisplayed(), "Home page is not displayed");
	}

	public void ClickOnBurgerMenu() {
		BaseClass.SwitchToDefaultFrame();
		try {
			JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
			je.executeScript("arguments[0].click();", ClickOnBurgerMenu);
			// ClickOnBurgerMenu.click();
		} catch (StaleElementReferenceException e) {

		}
	}

	public void GoToMyWork() {
		BaseClass.WaitforElementToBeClickable(mywork);
		mywork.click();
	}

	public void ClickOnCashCollectorItem() {
		// ClickOnCashCollectorIter.click();

	}

	public void ClickOnProfileButton() throws InterruptedException {

		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(45));
			WebElement Click_Profile = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(@name,'pyPortalHeader_pyDisplayHarness_37')]")));

			Click_Profile.click();
//			JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
//			je.executeScript("arguments[0].click();", Click_Profile);
			Thread.sleep(3000);
		} catch (StaleElementReferenceException e) {

		}

		// ClickOnProfile.click();
		// Thread.sleep(3000);

	}

	public void ClickOnProfileButton_NEW() throws InterruptedException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
			wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
			WaitforVisiblityofElement(element);
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);
			WebDriverWait additionalWait = new WebDriverWait(driver, Duration.ofSeconds(20));
		} catch (StaleElementReferenceException e) {
			System.out.println("StaleElementReferenceException occurred. Retrying or refreshing the page...");
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Clicked on the profile button to switch applications.");

	}

	public void ClickOnProfileButton1() throws InterruptedException {
		SwitchToDefaultFrame();

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		try {
			Task_count = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'My Tasks')]/following::div[1]/span")));
			System.out.println(Task_count.getText());
		} catch (TimeoutException e) {
			System.out.println("TimeoutException occurred. Element not clickable within the specified time.");
		}
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
		String profileButtonXpath = "//a[contains(@name,'pyPortalHeader_pyDisplayHarness_37')]";

		try {
			WebElement profile = waitForElementToBeClickable(By.xpath(profileButtonXpath), 60);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", profile);
		} catch (TimeoutException e) {
			System.out.println("TimeoutException occurred. Element not clickable within the specified time.");
		} catch (StaleElementReferenceException e) {
			System.out.println("Stale Element Exception occurred. Retrying...");
			WebElement profile = waitForElementToBeClickable(By.xpath(profileButtonXpath), 40);
			((JavascriptExecutor) driver).executeScript("arguments[0].click();", profile);
		}
	}


	private WebElement waitForElementToBeClickable(By locator, int timeoutSeconds) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
		return wait.until(driver -> {
			WebElement element = driver.findElement(locator);
			return (element.isDisplayed() && element.isEnabled()) ? element : null;
		});
	}


	public void logoff() throws InterruptedException {
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(3000);
		WebElement profile = lwebDriver.findElement(By.xpath("//a[contains(@name,'pyPortalHeader_pyDisplayHarness_37')]"));
		try {
			profile.click();
		} catch (StaleElementReferenceException e) {
			profile = lwebDriver.findElement(By.xpath("//a[contains(@name,'pyPortalHeader_pyDisplayHarness_37')]"));
			profile.click();
		}

		ClickOnLogoff.click();
		Thread.sleep(3000);
	}

	public void ClickOnProfileButton_for_BUportal() throws InterruptedException {
		BaseClass.SwitchToDefaultFrame();
//		  try
//		  {
//		  BaseClass.WaitforElementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_79']"));
//		  JavascriptExecutor je=(JavascriptExecutor)lwebDriver;
//		  je.executeScript("arguments[0].click();", ClickOnProfile);
//		  je.executeScript("arguments[0].click();", ClickOnProfile);
//
//		  Thread.sleep(8000);
//		  }
//		  catch(StaleElementReferenceException e)
//		  {
//
//		  }

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Profile = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_37']")));


		try {
			Profile.click();
		} catch (StaleElementReferenceException e) {
			Profile = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_37']"));
			Profile.click();
		}
		// ClickOnProfile.click();
		// Thread.sleep(3000);

	}

	public void fliter_cust_no(String customernumber) throws Exception {
		lwebDriver.findElement(By.xpath(
						"//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following	::div[2]//child::a"))
				.click();
		Thread.sleep(3000);

		lwebDriver
				.findElement(By.xpath("//div[@id='po0']/descendant::label[contains(text(),'Search')]/following::input"))
				.sendKeys(customernumber);
		logger.info("Entered postal code in text box");
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath(
						"//div[@id='po0']/descendant::label[contains(text(),'Search')]/following::button[text()='Apply']"))
				.click();
		logger.info("click on apply");
		Thread.sleep(3000);
	}

	public void ClickOnLogoff() throws InterruptedException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Click_logoff = wait.until(ExpectedConditions.elementToBeClickable(ClickOnLogoff));
			Click_logoff.click();
		} catch (StaleElementReferenceException e) {

		}

		// ClickOnProfile.click();
		// Thread.sleep(3000);

	}

	public void ClickOnSwitchAppButton() {
		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOf(ClickOnSwitchApp)).click();
		;
		// ClickOnSwitchApp.click();
	}

	public void ClickOnApplicationInSwitchAppsUsingApplicationName(String applicationName) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[.='" + applicationName + "']/parent::a")));
		WebElement findapp = lwebDriver.findElement(By.xpath("//span[.='" + applicationName + "']/parent::a"));
		JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
		je.executeScript("arguments[0].click();", findapp);
		System.out.println(lwebDriver.getTitle());
		Thread.sleep(3000);
	}

	public void ClickOnApplicationInSwitchAppsUsingApplicationName_New(String applicationName) throws InterruptedException {


		//// a[.='"+applicationName+"']
		Thread.sleep(5000);

		WebElement findapp = lwebDriver.findElement(By.xpath("//span[.='" + applicationName + "']/parent::a"));
		// BaseClass.WaitforVisiblityofElement(findapp);
		// BaseClass.WaitforElementToBeClickable(By.xpath("//span[.='Cash Collection
		// Healthcare US (Cash Collector Manager for CC HC US app)']/parent::a"));
		JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
		je.executeScript("arguments[0].click();", findapp);
		System.out.println(lwebDriver.getTitle());
		Thread.sleep(3000);
	}

	public void ClickOnApplicationInSwitchAppsUsingApplicationName_New_ZA(String applicationName) throws InterruptedException {


		//// a[.='"+applicationName+"']
		Thread.sleep(5000);

		Actions action = new Actions(driver);
		WebElement link = null;

// Use WebDriverWait to wait for the element to be present
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15)); // Adjust the timeout as needed

		try {
			// Wait for the element to be present
			link = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Switch portal']")));
		} catch (TimeoutException e) {
			// Handle timeout exception if the element is not found within the specified time
			System.out.println("Element 'Switch portal' not found within 10 seconds.");
		}

// If the element is found, perform the action
		if (link != null) {
			action.moveToElement(link).build().perform();
		}

		WebElement managerElement = new WebDriverWait(driver, Duration.ofSeconds(10))
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Manager']")));

// Use JavaScript to click on the element
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", managerElement);

	}

	public void ClickOnApplicationInSwitchAppsUsingApplicationName12() throws InterruptedException {


		//// a[.='"+applicationName+"']
		Thread.sleep(5000);

		lwebDriver.findElement(By.xpath("//span[contains(text(),'Cash Collection MY RC (Cash Collector Manager MY RC)')]")).click();
	}

	public void VerifyIfApplicationIsSelected(String applicationName) throws InterruptedException {
		WebElement findapp = lwebDriver.findElement(By.xpath("//a[text()='Cash Collection Healthcare US']"));
		Assert.assertTrue(findapp.isDisplayed());
		Thread.sleep(2000);

	}

	public void VerifyIfApplicationIsSelectedUSRC(String applicationName) throws InterruptedException {
		WebElement findapp = lwebDriver.findElement(By.xpath("//a[text()='Cash Collection Healthcare US RC']"));
		Assert.assertTrue(findapp.isDisplayed());
		Thread.sleep(2000);

	}

	public void VerifyIfApplicationIsSelectedUKRC(String applicationName) throws InterruptedException {
		WebElement findapp = lwebDriver.findElement(By.xpath("//a[text()='Cash Collection UK RC']"));
		Assert.assertTrue(findapp.isDisplayed());
		Thread.sleep(2000);

	}

	public void VerifyIfApplicationIsSelectedASNRC(String applicationName) throws InterruptedException {
		WebElement findapp = lwebDriver.findElement(By.xpath("//a[text()='Cash Collection Healthcare ASN RC']"));
		Assert.assertTrue(findapp.isDisplayed());
		Thread.sleep(2000);

	}

	public void VerifyIfApplicationIsSelectedCashCollectionUSRC(String applicationName) throws InterruptedException {
		WebElement findapp = lwebDriver.findElement(By.xpath("//a[text()='Cash Collection US RC']"));
		Assert.assertTrue(findapp.isDisplayed());
		Thread.sleep(2000);

	}

	public void ClickOnCustomerSearchOption() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		try {
			BaseClass.WaitforVisiblityofElement(MY_customer_search);
			MY_customer_search.click();
		} catch (StaleElementReferenceException e) {
			// Re-locate the element and try again
			MY_customer_search = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='content-item content-field item-1   dataValueRead flex flex-row ']//span[text()='My Customers']")));
			MY_customer_search.click();
		}
		logger.info("Click on customer list");
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		wait.until(webDriver -> jsExecutor.executeScript("return document.readyState").equals("complete"));
		Random rand = new Random();
		int randomIndex = rand.nextInt(elements.size());
		WebElement randomElement = wait.until(ExpectedConditions.elementToBeClickable(elements.get(randomIndex)));
		randomText = randomElement.getText();
		System.out.println("Randomly selected text: " + randomText);
		BaseClass.SwitchToDefaultFrame();
		logger.info("Click on mycustomer list");
		BaseClass.WaitforVisiblityofElement(element_search);
		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			element_search.click();
			logger.info("Click on element_search");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		} catch (StaleElementReferenceException e) {
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(60));
			WebElement element1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
			element1 = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element1.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}
		logger.info("Click on Customer search button");

	}

	public void ClickOnCustomerSearchOption_TL() throws InterruptedException {
		Thread.sleep(4000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		try {
			wait.until(ExpectedConditions.and(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='content-item content-field item-1   dataValueRead flex flex-row ']//span[text()='My Customers']")),

					ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//td[@data-attribute-name='Cust. No.']//span"))
			));
		} catch (Exception e) {

		}
		logger.info("Click on mycustomer list");
		WebElement mycustomer_list = driver.findElement(By.xpath("//div[@class='content-item content-field item-1   dataValueRead flex flex-row ']//span[text()='My Customers']"));
		mycustomer_list.click();
		Thread.sleep(6000);
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		wait.until(webDriver -> jsExecutor.executeScript("return document.readyState").equals("complete"));
		ExpectedConditions.presenceOfElementLocated(By.xpath("//td[@data-attribute-name='Cust. No.']//span"));
		List<WebElement> elements = driver.findElements(By.xpath("//td[@data-attribute-name='Cust. No.']//span"));
		Random rand = new Random();
		int randomIndex = rand.nextInt(elements.size());
		WebElement randomElement = wait.until(ExpectedConditions.elementToBeClickable(elements.get(randomIndex)));
		randomText = randomElement.getText();
		System.out.println("Randomly selected text: " + randomText);

		BaseClass.SwitchToDefaultFrame();

		// Handle timeout exception

		// Handle stale element reference exception

		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']")));


		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			element.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		} catch (StaleElementReferenceException e) {
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(60));
			WebElement element1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
			element1 = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element1.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}

	}

	public void ClickOnCustomerSearchOption_Dunning() throws InterruptedException {
		Thread.sleep(4000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		try {
			wait.until(ExpectedConditions.and(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='content-item content-field item-1   dataValueRead flex flex-row ']//span[text()='My Customers']")),

					ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//td[@data-attribute-name='Cust. No.']//span"))
			));
		} catch (Exception e) {

		}
		logger.info("Click on mycustomer list");
		WebElement mycustomer_list = driver.findElement(By.xpath("//div[@class='content-item content-field item-1   dataValueRead flex flex-row ']//span[text()='My Customers']"));
		mycustomer_list.click();
		Thread.sleep(6000);
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		wait.until(webDriver -> jsExecutor.executeScript("return document.readyState").equals("complete"));
		ExpectedConditions.presenceOfElementLocated(By.xpath("//td[@data-attribute-name='Cust. No.']//span"));
		List<WebElement> elements = driver.findElements(By.xpath("//td[@data-attribute-name='Cust. No.']//span"));
		Random rand = new Random();
		int randomIndex = rand.nextInt(elements.size());
		WebElement randomElement = wait.until(ExpectedConditions.elementToBeClickable(elements.get(randomIndex)));
		randomText2 = randomElement.getText();
		System.out.println("Randomly selected text: " + randomText2);

		BaseClass.SwitchToDefaultFrame();

		// Handle timeout exception

		// Handle stale element reference exception

		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']")));


		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			element.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		} catch (StaleElementReferenceException e) {
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(60));
			WebElement element1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
			element1 = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element1.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}

	}

	public void ClickOnCustomerSearchOption_2() throws InterruptedException {
		Thread.sleep(8000);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
//		try {
//			wait.until(ExpectedConditions.and(
//					ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='My Customers']")),
//					ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//td[@data-attribute-name='Cust. No.']//span"))
//			));
//
//			WebElement mycustomer_list = driver.findElement(By.xpath("//span[text()='My Customers']"));
//			logger.info("Click on mycustomer list");
//			mycustomer_list.click();
//			Thread.sleep(6000);
//			JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
//			wait.until(webDriver -> jsExecutor.executeScript("return document.readyState").equals("complete"));
//			ExpectedConditions.presenceOfElementLocated(By.xpath("//td[@data-attribute-name='Cust. No.']//span"));
//			List<WebElement> elements = driver.findElements(By.xpath("//td[@data-attribute-name='Cust. No.']//span"));
//			Random rand = new Random();
//			int randomIndex = rand.nextInt(elements.size());
//			WebElement randomElement = wait.until(ExpectedConditions.elementToBeClickable(elements.get(randomIndex)));
//			randomText = randomElement.getText();
//			System.out.println("Randomly selected text: " + randomText);
//
//			BaseClass.SwitchToDefaultFrame();
//		} catch (TimeoutException e1) {
//			// Handle timeout exception
//		} catch (StaleElementReferenceException e) {
//			// Handle stale element reference exception
//		}
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']")));


		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			element.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		} catch (StaleElementReferenceException e) {
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(60));
			WebElement element1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
			element1 = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element1.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}
	}

	public void ClickOnCustomerSearchOptiondsa() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

		try {
			WebElement myCustomerElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='My Customers']")));
			logger.info("Click on My Customers list");
			myCustomerElement.click();
			Thread.sleep(6000);
			// Wait for page to load
			wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));

			List<WebElement> elements = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//td[@data-attribute-name='Cust. No.']//span")));
			Random rand = new Random();
			int randomIndex = rand.nextInt(elements.size());
			WebElement randomElement = wait.until(ExpectedConditions.elementToBeClickable(elements.get(randomIndex)));
			randomText = randomElement.getText();
			System.out.println("Randomly selected text: " + randomText);

			BaseClass.SwitchToDefaultFrame();
		} catch (TimeoutException | StaleElementReferenceException e) {
			// Log or print information about the exception for debugging purposes
		}

		try {
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']")));
			element.click();
		} catch (StaleElementReferenceException e) {
			try {
				WebElement element1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
				element1.click();
			} catch (TimeoutException | StaleElementReferenceException ex) {
				// Log or print information about the exception for debugging purposes
			}
		}
	}

	public void ClickOnCustomerSearchOption_ES() throws InterruptedException {
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']")));


		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		} catch (StaleElementReferenceException e) {
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement element1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
			element1 = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element1.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}
	}

	public void ClickOnSearch() throws InterruptedException {

		try {
			Mycustomer.click();
			Thread.sleep(5000);

		} catch (Exception e) {
			WebElement my = lwebDriver.findElement(By.xpath("//span[text()='My Customers']"));
			my.click();
		}
		String xpathExpression = "//td[@data-attribute-name='Cust. No.']";

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

		// Wait for at least one matching element to be present
		List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpathExpression)));

		// Check if there are any matching elements
		if (!elements.isEmpty()) {
			// Get a random index
			int randomIndex = new Random().nextInt(elements.size());

			// Get the randomly selected element
			WebElement randomElement = elements.get(randomIndex);
			cust_No = randomElement.getText();

			// Print the text of the randomly selected element
			System.out.println("Randomly selected element text: " + randomElement.getText());
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));



			//Customer Name

			String xpathExpression1 = "//td[@data-attribute-name='Customer']//div";


			// Wait for at least one matching element to be present
			List<WebElement> elementss = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpathExpression1)));

			// Check if there are any matching elements
			if (!elementss.isEmpty()) {
				// Get a random index
				int randomIndex1 = new Random().nextInt(elementss.size());

				// Get the randomly selected element
				WebElement randomElement1 = elementss.get(randomIndex);
				Customername = randomElement1.getText();

				// Print the text of the randomly selected element
				System.out.println("Randomly selected element text: " + randomElement1.getText());
				Thread.sleep(5000);

				//postalcode


				String xpathExpression3 = "//td[@data-attribute-name='Postal Code']//div";


				// Wait for at least one matching element to be present
				List<WebElement> elements3 = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpathExpression3)));

				// Check if there are any matching elements
				if (!elements3.isEmpty()) {
					// Get a random index
					int randomIndex3 = new Random().nextInt(elements3.size());

					// Get the randomly selected element
					WebElement randomElement3 = elements3.get(randomIndex3);
					Postalcode = randomElement3.getText();

					// Print the text of the randomly selected element
					System.out.println("Randomly selected element text: " + randomElement3.getText());


					//customerNumber

					//CaseID

					String xpathExpression4 = "//span[contains(text(),'Case ID')]/following::span[1]";


					// Wait for at least one matching element to be present
					List<WebElement> elements4 = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpathExpression4)));

					// Check if there are any matching elements
					if (!elements4.isEmpty()) {
						// Get a random index
						int randomIndex4 = new Random().nextInt(elements4.size());

						// Get the randomly selected element
						WebElement randomElement4 = elements4.get(randomIndex4);
						Case_ID = randomElement4.getText();

						// Print the text of the randomly selected element
						System.out.println("Randomly selected element text: " + randomElement4.getText());

						//amount

						//postalcode


						String xpathExpression5 = "//td[@data-attribute-name='Total Amount']//div";


						// Wait for at least one matching element to be present
						List<WebElement> elements5 = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpathExpression5)));

						// Check if there are any matching elements
						if (!elements5.isEmpty()) {
							// Get a random index
							int randomIndex5 = new Random().nextInt(elements5.size());

							// Get the randomly selected element
							WebElement randomElement5 = elements5.get(randomIndex5);
							Total_Amountunt = randomElement5.getText();

							// Print the text of the randomly selected element
							System.out.println("Randomly selected element text: " + randomElement5.getText());

							try {

								ClickOnSearch.click();
							} catch (StaleElementReferenceException e) {

								ClickOnSearch = lwebDriver.findElement(By.xpath("//a[contains(@name,'pyPortalHeader_pyDisplayHarness_31')]"));
								ClickOnSearch.click();
							}
						}
					}
				}
			}
		}
	}

	public void Verify_with_customernumber(String Searchitem) throws InterruptedException {

		Thread.sleep(2000);
		BaseClass.SwitchToDefaultFrame();
		try {
			BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
		} catch (Exception exception) {

		}


		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement customer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']")));
		customer.sendKeys(cust_No);
		logger.info("Entered customer number into search box");
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Click_on_search = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']/following::div[1]//img")));
		Click_on_search.click();

		logger.info("Click on serach Icon button");

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement customernumber = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@data-attribute-name='Customer No']//span")));

		customernumber.getText();
		System.out.println(customernumber.getText());
		if (customernumber.getText().equals(cust_No)) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by the search customer number");
		} else {
			logger.info("Did not match the customer numbers");
			Assert.assertTrue(false);
		}

	}


	public void Verify_with_customername(String searchwithname) throws InterruptedException {
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement customer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']")));
		customer.clear();
		Thread.sleep(3000);
		customer.sendKeys(Customername);
		logger.info("Entered customer name into search box");
		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement search = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']/following::div[1]//img")));
		search.click();
		logger.info("Click on serach Icon button");
		Thread.sleep(5000);
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement customername = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@node_name='CustomerName']//span")));
		System.out.println(customername.getText());
		if (customername.getText().equals(Customername)) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by the search customer name");
		} else {
			logger.info("Did not match the customer name");
			Assert.assertTrue(false);
		}

	}

	public void Verify_with_Postal_code(String Postal) throws InterruptedException {
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.clear();
		Thread.sleep(5000);
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.sendKeys(Postalcode);
		logger.info("Entered customer name into search box");
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']/following::div[1]//img"))
				.click();
		logger.info("Click on serach Icon button");
		Thread.sleep(5000);
		List<WebElement> rows = driver.findElements(By.xpath("//tr[contains(@id,'$PD_CollectionListByCustomerSearch_pa')]"));
		System.out.println(rows.size());
		if (rows.size() == 0) {
			Assert.assertTrue(false);
		} else {
			Assert.assertTrue(true);
		}
	}

	public void Verify_with_Postal_code_SI(String Postal) throws InterruptedException {
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.clear();
		Thread.sleep(5000);
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.sendKeys(Postal);
		logger.info("Entered customer name into search box");

		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']/following::div[1]//img"))
				.click();
		logger.info("Click on serach Icon button");
		Thread.sleep(3000);
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			WebElement Postalcode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//td[@data-attribute-name='Postal Code']/span)[1]")));


			System.out.println(Postalcode);
			if (Postalcode.getText().equals(Postal) || Postalcode.equals("19355-1427")) {
				Assert.assertTrue(true);
				logger.info("The line items are correctly visible by postalcode ");
			} else {
				logger.info("Did not match the postal code");
				Assert.assertTrue(false);
			}
		} catch (TimeoutException e) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Postalcode = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_CollectionListByCustomerSearch_pa')][1]")));


			System.out.println(Postalcode);
			if (Postalcode.getText().contains(Postal)) {
				Assert.assertTrue(true);
				logger.info("The line items are correctly visible by postalcode ");
			} else {
				logger.info("Did not match the postal code");
				Assert.assertTrue(false);
			}
		}
	}

	public void Verify_with_Postal_code_NL(String Postal) throws InterruptedException {
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.clear();
		Thread.sleep(5000);
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.sendKeys(Postal);
		logger.info("Entered customer name into search box");

		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']/following::div[1]//img"))
				.click();
		logger.info("Click on serach Icon button");
		Thread.sleep(5000);
		String Postalcode = lwebDriver
				.findElement(
						By.xpath("//div[@id='']/descendant::td[10]//span | //div[@id='']/descendant::tr[3]/td[10]//span"))
				.getText();
		System.out.println(Postalcode);
		if (Postalcode.equals(Postal) || Postalcode.equals("19355-1427")) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by postalcode ");
		} else {
			logger.info("Did not match the postal code");
			Assert.assertTrue(true);
		}
	}

	public void Verify_with_Postal_code_ASN(String Postal) throws InterruptedException {
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.clear();
		Thread.sleep(5000);
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.sendKeys(Postal);
		logger.info("Entered customer name into search box");

		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']/following::div[1]//img"))
				.click();
		logger.info("Click on serach Icon button");
		Thread.sleep(5000);
		String Postalcode = lwebDriver
				.findElement(
						By.xpath("//tr[contains(@id,'$PD_CollectionListByCustomerSearch_pa')][1]/td[8]//span"))
				.getText();
		System.out.println(Postalcode);
		if (Postalcode.equals(Postal)) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by postalcode ");
		} else {
			logger.info("Did not match the postal code");
			Assert.assertTrue(false);
		}
	}

	public void Verify_search_with_Collection_ID(String Collection_ID) throws InterruptedException {
		Thread.sleep(2000);
		lwebDriver
				.findElement(By.xpath(
						"//div[text()='Customer']//following::input[@name='$PpyDisplayHarness$pCustomerSearchText']"))
				.clear();
		Thread.sleep(2000);
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::input[1]"))
				.sendKeys(Collection_ID);
		logger.info("Entered Collection ID into search box");

		Thread.sleep(2000);
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::img")).click();
		logger.info("Click on serach Icon button");
		Thread.sleep(3000);
		String CollectionId = lwebDriver
				.findElement(By.xpath(
						"//div[@id='']/descendant::td[2]//div[@class='content-inner ']/span/following::div[1]/span"))
				.getText();
		System.out.println(CollectionId);
		if (CollectionId.equals(Collection_ID)) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by CollectionID ");
		} else {
			logger.info("Did not match the CollectionID");
			Assert.assertTrue(false);
		}
	}

	public void Verify_search_with_Collection_ID_HC(String Collection_ID) throws InterruptedException {
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement customer = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Collection & Contact']//following::input[@name='$PpyDisplayHarness$pCollectionSearchText']")));
		customer.clear();
		Thread.sleep(3000);
		customer.sendKeys(Case_ID);
		logger.info("Entered Collection ID into search box");
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::img[1]")).click();
		logger.info("Click on serach Icon button");
		Thread.sleep(3000);
		try {
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
			WebElement CollectionId = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Case ID')]/following::span[1]")));
			System.out.println(CollectionId);
			if (CollectionId.getText().equals(Case_ID)) {
				Assert.assertTrue(true);
				logger.info("The line items are correctly visible by CollectionID ");
			} else {
				logger.info("Did not match the CollectionID");
				Assert.assertTrue(false);
			}
		} catch (TimeoutException e) {
			WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10));
			WebElement CollectionId = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Case ID')]/following::span[1]")));
			System.out.println(Case_ID);
			if (CollectionId.getText().equals(Collection_ID)) {
				Assert.assertTrue(true);
				logger.info("The line items are correctly visible by CollectionID ");
			} else {
				logger.info("Did not match the CollectionID");
				Assert.assertTrue(false);
			}

		}
	}

	public void Verify_search_with_Cash_Collector_Name(String Cname) throws InterruptedException {
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::input[1]")).clear();
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::input[1]")).sendKeys(Cname);
		logger.info("Entered Collector Name into search box");

		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::img")).click();
		logger.info("Click on serach Icon button");
		//Thread.sleep(5000);
//		WebElement Name = lwebDriver.findElement(
//				By.xpath("//div[@id='']/descendant::tr/td[11]//span | //div[@id='']/descendant::td[25]/span"));
//		System.out.println(Name);
//
//
//			if (Name.getText().contains(Cname)) {
//				Assert.assertTrue(true);
//				logger.info("The line items are correctly visible by collector name ");
//			}
//
//			else {
//				logger.info("Did not match the collector name");
//				Assert.assertTrue(false);
//			}
	}

	public void Verify_search_with_Cash_Collector_Name_HC(String Cname) throws InterruptedException {
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::input[1]")).clear();
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::input[1]")).sendKeys(Cname);
		logger.info("Entered Collector Name into search box");

		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Collection & Contact']//following::img")).click();
		logger.info("Click on serach Icon button");
		//Thread.sleep(5000);
//		WebElement Name = lwebDriver.findElement(
//				By.xpath("//div[@id='']/descendant::tr/td[11]//span | //div[@id='']/descendant::td[25]/span"));
//		System.out.println(Name);
//
//
//			if (Name.getText().contains(Cname)) {
//				Assert.assertTrue(true);
//				logger.info("The line items are correctly visible by collector name ");
//			}
//
//			else {
//				logger.info("Did not match the collector name");
//				Assert.assertTrue(false);
//			}
	}


	public void Search_for_Items_by_Reference_number(String Referencenumber) throws InterruptedException {
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).clear();
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).sendKeys(Referencenumber);
		logger.info("Entered Reference number into search box");

		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::img")).click();
		logger.info("Click on serach Icon button");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement cloumn = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//td[contains(@data-attribute-name,'Status')]/div/span")));

		System.out.println(cloumn);
		if (!cloumn.getText().equals("Open")) {
			Assert.assertTrue(true);
			logger.info("****lineitem status is showing 'Open'*******");
		} else {
			logger.info("lineitem status is showing 'closed'");
			Assert.assertTrue(false);
		}

	}

	public void Search_for_Items_by_Reference_number_HC(String Referencenumber) throws InterruptedException {
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).clear();
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).sendKeys(Referencenumber);
		logger.info("Entered Reference number into search box");

		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::img")).click();
		logger.info("Click on serach Icon button");
		Thread.sleep(5000);
		List<WebElement> cloumn = lwebDriver.findElements(By.xpath(
				"//table[@id='gridLayoutTable']//descendant::*[text()='Cust. Name']//following::tr[1]/td[6]//span"));
		System.out.println(cloumn);
		if (!cloumn.isEmpty()) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by Reference number ");
		} else {
			logger.info("Did not match the Reference number");
			Assert.assertTrue(false);
		}

	}


	public void Search_for_Items_by_Reference_number_SI(String referenceNumber) throws InterruptedException {
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).clear();
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).sendKeys(referenceNumber);
		logger.info("Entered Reference number into the search box");

		Thread.sleep(2000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::img")).click();
		logger.info("Clicked on the search icon button");
		Thread.sleep(2000);
		try {
			WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(40));
			List<WebElement> column = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//table[@id='gridLayoutTable']//descendant::*[text()='Cust. Name']//following::tr[1]/td[7]//span")));

			System.out.println(column);
			if (!column.isEmpty()) {
				logger.info("The line items are correctly visible by Reference number");
				Assert.assertTrue(true);
			} else {
				logger.info("No match found for the Reference number");
				Assert.assertTrue(false);
			}
		} catch (TimeoutException e) {
			WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(40));
			WebElement column = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='gridLayoutTable']//descendant::*[text()='Cust. Name']//following::tr[1]/td[6]//span")));

			System.out.println(column);
			if (!column.getText().isEmpty() || column.getText().contains(referenceNumber)) {
				logger.info("The line items are correctly visible by Reference number");
				Assert.assertTrue(true);
			} else {
				logger.info("No match found for the Reference number");
				Assert.assertTrue(false);
			}
		}
	}


	public void Search_for_Amount(String Amount) throws InterruptedException {
//		Thread.sleep(3000);
//	//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
//		String xpathExpression = "//td[@data-attribute-name='Amount']//span | // tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')]//td[11]//span/span";
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//		List<WebElement> matchingElements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpathExpression)));
//		WebElement randomElement = getRandomElement(matchingElements);
//	line_amount =randomElement.getText();
//		try {
//			BaseClass.SwitchToDefaultFrame();
//			Thread.sleep(3000);
//			WebElement Icon =	 wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@id='TABANCHOR']//span[@class='textIn']")));
//
//			JavascriptExecutor j = (JavascriptExecutor) driver;
//			j.executeScript("arguments[0].click();", Icon);
////	Icon.click();
//
//			lwebDriver.findElement(By.xpath("//td[text()='Close All']")).click();
//			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
//		} catch (StaleElementReferenceException e) {
//			// ignore
//		}
//		SwitchToDefaultFrame();
//		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
//		try {
//			Mycustomer.click();
//			Thread.sleep(5000);
//
//		} catch (Exception e) {
//			WebElement my = lwebDriver.findElement(By.xpath("//span[text()='My Customers']"));
//			my.click();
//		}
		WebElement amountbox = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Search for Amount')]/parent::span/input[2]"));
		amountbox.click();
		if (amountbox.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Checkbox was selected");
		} else {
			logger.info("Did not select check box");
			Assert.assertTrue(true);
		}

		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).clear();
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).sendKeys("1000");
		logger.info("Entered Amount number into search box");

		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::img")).click();
		logger.info("Click on serach Icon button");
		Thread.sleep(5000);
		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10));
		List<WebElement> CollectionId = wait2.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//td[@data-attribute-name='Amount']//span")));

		System.out.println("92,800.00");

		if (CollectionId.size() != 0) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by CollectionID ");
		} else {
			logger.info("Did not match the CollectionID");
			Assert.assertTrue(false);
		}
		SwitchToDefaultFrame();
	}

	private static WebElement getRandomElement(List<WebElement> elements) {
		Random rand = new Random();
		return elements.get(rand.nextInt(elements.size()));
	}

	public void Search_for_Amount_HC(String Amount) throws InterruptedException {
		Thread.sleep(3000);
		WebElement amountbox = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Search for Amount')]/parent::span/input[2]"));
		amountbox.click();
		if (amountbox.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Checkbox was selected");
		} else {
			logger.info("Did not select check box");
			Assert.assertTrue(true);
		}
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).clear();
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).sendKeys(Amount);
		logger.info("Entered Amount number into search box");

		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::img")).click();
		logger.info("Click on serach Icon button");
		Thread.sleep(5000);
		List<WebElement> amount = lwebDriver.findElements(By.xpath(
				"//table[@id='gridLayoutTable']//descendant::*[text()='Cust. Name']//following::tr[1]/td[6]//span"));
		if (!amount.isEmpty()) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by Amount ");
		} else {
			logger.info("Did not visible correct amount with lineitems");
			Assert.assertTrue(false);
		}

	}

	public void Search_for_Amount_SI(String Amount) throws InterruptedException {
		Thread.sleep(3000);
		WebElement amountbox = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Search for Amount')]/parent::span/input[2]"));
		amountbox.click();
		if (amountbox.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Checkbox was selected");
		} else {
			logger.info("Did not select check box");
			Assert.assertTrue(true);
		}
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).clear();
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::input[1]")).sendKeys(Amount);
		logger.info("Entered Amount number into search box");

		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[text()='Item']//following::img")).click();
		logger.info("Click on serach Icon button");
		Thread.sleep(5000);
		List<WebElement> amount = lwebDriver.findElements(By.xpath(
				"//table[@id='gridLayoutTable']//descendant::*[text()='Cust. Name']//following::tr[1]/td[5]//span"));
		if (!amount.isEmpty()) {
			Assert.assertTrue(true);
			logger.info("The line items are correctly visible by Amount ");
		} else {
			logger.info("Did not visible correct amount with lineitems");
			Assert.assertTrue(false);
		}

	}

	public void ClickOnCustomerSearchOption2() throws InterruptedException {
		BaseClass.SwitchToDefaultFrame();

		WaitforElementToBeClickable(customer_2);

		try {

			customer_2.click();
		} catch (StaleElementReferenceException e) {

		WebElement	customer = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			customer.click();

		}

	}

	public void ClickOnCustomerSearchOption3() throws InterruptedException {
		BaseClass.SwitchToDefaultFrame();

		System.out.println(lwebDriver.getTitle());
		Set<String> s = lwebDriver.getWindowHandles();
		for (String i : s) {
			String t = lwebDriver.switchTo().window(i).getTitle();

		}

		WebElement customer = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));

		try {

			customer.click();
			Thread.sleep(3000);
		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("pyPortalHeader_pyDisplayHarness_30"));
			customer.click();

		}

	}

	public void verify_openDispute_In_BU() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
		Thread.sleep(5000);

		List<WebElement> openDispute = lwebDriver.findElements(
				By.xpath("//table[@id='gridLayoutTable']//descendant::*[text()='Dispute ID']//following::tr[1]"));

		{
			if (!openDispute.isEmpty()) {
				Assert.assertTrue(true);
				logger.info("On the BU portal, I can see and enable my open dispute items");
			} else {
				logger.info("Disabled or empty items are listed in Open Disputes.");
				Assert.assertTrue(false);
			}

			if (lwebDriver.getPageSource().contains("No Items")) {
				logger.info("There are no open Dispute items in BU portal");

			}
		}
		BaseClass.SwitchToDefaultFrame();
	}

	public void verify_ClosedDispute_In_BU() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
		Thread.sleep(5000);

		List<WebElement> closedDispute = lwebDriver.findElements(
				By.xpath("//table[@id='gridLayoutTable']//descendant::*[text()='Dispute ID']//following::tr"));

		if (!closedDispute.isEmpty()) {
			Assert.assertTrue(true);
			logger.info("On the BU portal, I can see and enable my closed dispute items");
		} else {
			logger.info("Disabled or empty items are listed in closed Disputes.");
			Assert.assertTrue(false);
		}

		if (lwebDriver.getPageSource().contains("No Items")) {
			logger.info("There are no closed Dispute items in BU portal");
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void ClickOnCustomerSearchOption1() throws InterruptedException {
		BaseClass.SwitchToDefaultFrame();

		WebElement Searchbutton = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
		try {
			Searchbutton.click();
		} catch (StaleElementReferenceException e) {
			Thread.sleep(3000);
			Searchbutton = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			Searchbutton.click();
			Thread.sleep(5000);
		}
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton(String customer) throws InterruptedException
	// Giri
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));

		try {
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.tagName("iframe")));

		} catch (NoSuchElementException e) {
		}


		// BaseClass.WaitforElementToBeClickable(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		BaseClass.WaitforElementToBeClickable(EnterCustomerNumberSearch1);

		try {

			EnterCustomerNumberSearch1.sendKeys(randomText);
		} catch (StaleElementReferenceException e) {

			EnterCustomerNumberSearch1 = lwebDriver
					.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
			EnterCustomerNumberSearch1.sendKeys(randomText);
		}

		BaseClass.WaitforVisiblityofElement(ClickOnSearchButton);
		ClickOnSearchButton.click();
		logger.info("Enter customer number");
		BaseClass.SwitchToDefaultFrame();

	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(String CustomerNo) throws InterruptedException
	// Giri
	{
		try {
			lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			// BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		} catch (NoSuchFrameException e) {
			System.out.println("frame");
		}

		// BaseClass.WaitforElementToBeClickable(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input")));
		WebElement EnterCustomerNumberSearch1 = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
		try {

			EnterCustomerNumberSearch1.sendKeys(CustomerNo);
		} catch (StaleElementReferenceException e) {

			EnterCustomerNumberSearch1 = lwebDriver
					.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
			EnterCustomerNumberSearch1.sendKeys(CustomerNo);
		}

		BaseClass.WaitforVisiblityofElement(ClickOnSearchButton);
		ClickOnSearchButton.click();
		BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton_Dunning2(String CustomerNo) throws InterruptedException
	// Giri
	{
		try {
			lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			// BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		} catch (NoSuchFrameException e) {
			System.out.println("frame");
		}

		// BaseClass.WaitforElementToBeClickable(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input")));
		WebElement EnterCustomerNumberSearch1 = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
		try {

			EnterCustomerNumberSearch1.sendKeys(randomText2);
		} catch (StaleElementReferenceException e) {

			EnterCustomerNumberSearch1 = lwebDriver
					.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
			EnterCustomerNumberSearch1.sendKeys(randomText2);
			System.out.println("Randomly selected text: " + randomText2);
		}

		BaseClass.WaitforVisiblityofElement(ClickOnSearchButton);
		ClickOnSearchButton.click();
		BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton_puase(String CustomerNo) throws InterruptedException
	// Giri
	{
		try {
			lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			// BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		} catch (NoSuchFrameException e) {
			System.out.println("frame");
		}


		// BaseClass.WaitforElementToBeClickable(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input")));
		WebElement EnterCustomerNumberSearch1 = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
		try {

			EnterCustomerNumberSearch1.sendKeys(randomText);
		} catch (StaleElementReferenceException e) {

			EnterCustomerNumberSearch1 = lwebDriver
					.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
			EnterCustomerNumberSearch1.sendKeys(randomText);
		}

		BaseClass.WaitforVisiblityofElement(ClickOnSearchButton);
		ClickOnSearchButton.click();
		BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton_HC(String CustomerNo) throws InterruptedException
	// Giri
	{
		try {

			BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
		} catch (NoSuchFrameException e) {
			System.out.println("frame");
		}


		// BaseClass.WaitforElementToBeClickable(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input")));
		WebElement EnterCustomerNumberSearch1 = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
		try {

			EnterCustomerNumberSearch1.sendKeys(CustomerNo);
		} catch (StaleElementReferenceException e) {

			EnterCustomerNumberSearch1 = lwebDriver
					.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
			EnterCustomerNumberSearch1.sendKeys(CustomerNo);
		}

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement ClickOnSearchButton = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[.='Search']")));
		try {
			ClickOnSearchButton.click();
		} catch (StaleElementReferenceException e) {
			ClickOnSearchButton = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[.='Search']")));
			ClickOnSearchButton.click();
		}
		BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton01(String CustomerNo) throws InterruptedException
	// Giri
	{

		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));

		WebElement EnterCustomerNumberSearch1 = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
		try {

			Thread.sleep(2000);
			EnterCustomerNumberSearch1.sendKeys(randomText);
			Thread.sleep(3000);
			ClickOnSearchButton.click();
			BaseClass.SwitchToDefaultFrame();
		} catch (NoSuchElementException e) {

			BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget1Ifr");
			EnterCustomerNumberSearch1 = lwebDriver
					.findElement(By.xpath("//label[contains(text(),'Name, Number')]//following-sibling::div//input"));
			EnterCustomerNumberSearch1.sendKeys(randomText);
			Thread.sleep(3000);
			ClickOnSearchButton.click();
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton1(String CustomerNo) throws InterruptedException
	// Giri
	{
		BaseClass.SwitchToDefaultFrame();

		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input")));

		WebElement customer = lwebDriver
				.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		try {

			customer.sendKeys(randomText);

		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
			customer.sendKeys(randomText);
		}

		WebElement sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
		try {
			Thread.sleep(5000);
			sumbit.click();

		} catch (StaleElementReferenceException e) {

			sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
			sumbit.click();
		}


		//BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton11(String CustomerNo) throws InterruptedException
	// Giri
	{
		BaseClass.SwitchToDefaultFrame();

		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input")));

		WebElement customer = lwebDriver
				.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		try {

			customer.sendKeys(CustomerNo);

		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
			customer.sendKeys(CustomerNo);
		}

		WebElement sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
		try {
			Thread.sleep(5000);
			sumbit.click();

		} catch (StaleElementReferenceException e) {

			sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
			sumbit.click();
		}


		//BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton12(String CustomerNo) throws InterruptedException
	// Giri
	{
		BaseClass.SwitchToDefaultFrame();
		try {
			lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
		} catch (NoSuchElementException exception) {

		}

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input")));

		WebElement customer = lwebDriver
				.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		try {

			customer.sendKeys(CustomerNo);

		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
			customer.sendKeys(CustomerNo);
		}

		WebElement sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
		try {
			Thread.sleep(5000);
			sumbit.click();

		} catch (StaleElementReferenceException e) {

			sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
			sumbit.click();
		}


		//BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton1_pause(String CustomerNo) throws InterruptedException
	// Giri
	{
		BaseClass.SwitchToDefaultFrame();

		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input")));

		WebElement customer = lwebDriver
				.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		try {

			customer.sendKeys(randomText);

		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
			customer.sendKeys(randomText);
		}

		WebElement sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
		try {
			Thread.sleep(5000);
			sumbit.click();

		} catch (StaleElementReferenceException e) {

			sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
			sumbit.click();
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton1_HC(String CustomerNo) throws InterruptedException
	// Giri
	{
		BaseClass.SwitchToDefaultFrame();

		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input")));

		WebElement customer = lwebDriver
				.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		try {

			customer.sendKeys(CustomerNo);

		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
			customer.sendKeys(CustomerNo);
		}

		// ClickOnSearchButton.click();
		WebElement sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
		try {
			Thread.sleep(5000);
			sumbit.click();

		} catch (StaleElementReferenceException e) {

			sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
			sumbit.click();
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void Fliter_Action2(String Invoice) throws InterruptedException {

		WebElement fliter = lwebDriver.findElement(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following	::span[2]/child::a"));
		if (fliter.isDisplayed() && fliter.isEnabled()) {
			Assert.assertTrue(true);
			fliter.click();
			Thread.sleep(3000);
			logger.info("clicked on cust Fliter in table");

		} else {
			logger.info("Unable to find  cust Fliter in table");
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")).sendKeys(randomText);
		logger.info("Entered customer number in text box");
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")).click();
		logger.info("Click on Apply");

		Thread.sleep(6000);


	}

	public void Click_on_Dispute_up_up(String couNo) throws InterruptedException, IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement refreshButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[contains(text(),'Refresh')])[1]")));
			refreshButton = wait.until(ExpectedConditions.elementToBeClickable(refreshButton));
			refreshButton.click();

			Thread.sleep(3000);
		} catch (StaleElementReferenceException e) {

		}
		Thread.sleep(3000);
		logger.info("Click on Refresh");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOf(Dispute_Task));
		wait.until(ExpectedConditions.elementToBeClickable(Dispute_Task));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Dispute_Task);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", Dispute_Task);


		logger.info("Click on Dispute tasks");
		Thread.sleep(3000);
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Filter = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following	::span[2]/child::a")));
		Filter.click();
		Thread.sleep(3000);
		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement textbox = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")));
		System.out.println("Customer number" + randomText);
		textbox.sendKeys(randomText);
		logger.info("Entered customer number in text box");
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")).click();
		logger.info("Click on Apply");

	}

	public void Fliter_Action23(String Invoice) throws InterruptedException {

		WebElement fliter = lwebDriver.findElement(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following::span[2]/child::a"));
		if (fliter.isDisplayed() && fliter.isEnabled()) {
			Assert.assertTrue(true);
			fliter.click();
			Thread.sleep(3000);
			logger.info("clicked on cust Fliter in table");

		} else {
			logger.info("Unable to find  cust Fliter in table");
			Assert.assertTrue(false);
		}
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")).sendKeys(randomText);
		logger.info("Entered customer number in text box");
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")).click();
		logger.info("Click on Apply");

		Thread.sleep(6000);


	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButton2(String CustomerNo) throws InterruptedException {

		lwebDriver.switchTo().frame("PegaGadget0Ifr");


		// wait.until(ExpectedConditions.visibilityOf(EnterCustomerNumberSearch));
		// BaseClass.WaitforElementToBeClickable(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		Thread.sleep(10000);
		WebElement customer = lwebDriver
				.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		try {
			customer.sendKeys(CustomerNo);
		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		}
		customer.sendKeys(CustomerNo);

		Thread.sleep(4000);
	}

	public void Click_on_sunmit() throws InterruptedException {
		WebElement ClickOnSearchButton2 = lwebDriver.findElement(By.xpath("//button[.='Search']"));
		try {
			ClickOnSearchButton2.click();
		} catch (StaleElementReferenceException e) {
			ClickOnSearchButton2 = lwebDriver.findElement(By.xpath("//button[.='Search']"));
			ClickOnSearchButton2.click();
			Thread.sleep(3000);
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void EnterCustomerNumberInSearchAndClickOnSearchButtonForCampaigns(String CustomerNo) {
		try {

			BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		} catch (NoSuchFrameException e) {
			System.out.println("frame");
		}
		BaseClass.WaitforVisiblityofElement(EnterCustomerNumberSearch);

		EnterCustomerNumberSearch.sendKeys(CustomerNo);
		ClickOnSearchButton.click();
		BaseClass.SwitchToDefaultFrame();
	}

	public void ClickOnCollection() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);
		ClickOnCollectionId.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);
	}

	public void ClickOnCollectionUKRC() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforVisiblityofElement(ClickOnCollectionIdUKRC);
		ClickOnCollectionIdUKRC.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);
	}

	public void ClickOnCollectionInDev() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);
		ClickOnDevCollectionId.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(10000);
	}

	public void ClickOnCollectionInQ() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		// BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);

		ClickOnQACollectionId.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);
	}

	public void ClickOnCollectionInQUKRC() throws InterruptedException {
		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));

		// Wait for the element to be both visible and clickable
		BaseClass.WaitforElementToBeClickable(qaCollectionElement);

		// Click on the element
		qaCollectionElement.click();
		logger.info("Click on collection ");
		// Switch back to the default frame
		SwitchToDefaultFrame();
	}


	public void ClickOnCollectionInQUKRC1() throws InterruptedException
	// Giri
	{
		//lwebDriver.switchTo().frame("PegaGadget0Ifr");


		WebElement Id = lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_CollectionsByCustomerSearch_pa')])[1]//td[1]"));

		try {

			Id.click();

		} catch (StaleElementReferenceException e) {
			Id = lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_CollectionsByCustomerSearch_pa')])[1]//td[1]"));
			Id.click();

		}
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(3000);
	}

	public void ClickOnCollectionInQUKRC_HC() throws InterruptedException
	// Giri
	{
		lwebDriver.switchTo().frame("PegaGadget0Ifr");

		Thread.sleep(3000);

		WebElement Id = lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_CollectionsByCustomerSearch_pa')])[1]//td[1]"));

		try {

			Id.click();

		} catch (StaleElementReferenceException e) {
			Id = lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_CollectionsByCustomerSearch_pa')])[1]//td[1]"));
			Id.click();

		}
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(3000);
	}

	public String Customername() {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Customername = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//h2[contains(@id,'headerlabel')]/div)[1]")));
		String Customername1 = Customername.getText();
		System.out.println(Customername1);

		BaseClass.SwitchToDefaultFrame();
		return Customername1;

	}

	public String Customername1() {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Customername = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//h2[contains(@id,'headerlabel')]/div)[1]")));
		String Customername1 = Customername.getText();
		System.out.println(Customername1);

		BaseClass.SwitchToDefaultFrame();
		return Customername1;

	}

	public String Customername_HC() {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
		String Customername = lwebDriver.findElement(By.xpath("(//h2[contains(@id,'headerlabel')]/div)[1]")).getText();
		System.out.println(Customername);

		BaseClass.SwitchToDefaultFrame();
		return Customername;

	}

	public void Select_routeto() throws InterruptedException {

		Thread.sleep(5000);

		if (Select_route.isEnabled()) {
			Assert.assertTrue(true);
			Select_route.click();
			Thread.sleep(3000);
			logger.info("Selected person for route");
		} else {
			logger.info("Did not select route to");
			Assert.assertTrue(true);

		}
	}

	public void Select_Email_click_on_Addreceipt(String Email) throws InterruptedException {

		lwebDriver.findElement(By.xpath("//label[contains(text(),'Person')]/following::div[2]//child::input[1]"))
				.sendKeys(Email);
		logger.info("Entered the person Email id");
		Thread.sleep(10000);

		lwebDriver.findElement(By.xpath("//label[contains(text(),'Person')]/following::div[2]//child::input[1]"))
				.sendKeys(Keys.ARROW_DOWN);

		Thread.sleep(10000);

		lwebDriver.findElement(By.xpath("//label[contains(text(),'Person')]/following::div[2]//child::input[1]"))
				.sendKeys(Keys.ENTER);
		// WebElement addreceipt = lwebDriver.findElement(By.xpath("//button[text()='Add
		// recipient']"));

	}

	public void Escalate_this_dispute() throws InterruptedException {
		WebElement Escalate = lwebDriver.findElement(
				By.xpath("//label[contains(text(),'Escalate this dispute')]//parent::span/child::input[2]"));
		if (Escalate.isSelected()) {
			Escalate.click();
			logger.info("Escalate option was unchecked");
			Thread.sleep(10000);

		}
	}

	public void ClickOnCollectionInASNRC() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		// BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);
		ClickOnQACollectionIdASNRC.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);
	}

	public void ClickOnCollectionInUSRC() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		// BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);

		ClickOnQACollectionIdUSRC.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);
	}

	public void ClickOnCollectionInQLeading() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		// BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);

		ClickOnQACollectionIdLeading.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);
	}

	public void ClickOnCollectionInQForDunning() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		// BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);

		ClickOnQACollectionIdForDunning.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);
	}

	public void ClickOnCollectionInQWithoutSwitchApp() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		// BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);

		ClickOnQACollectionIdWithoutSwitchApp.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);
	}

	public void SelectDevCollectionIdForLeadingInvoice() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforVisiblityofElement(ClickOnDevCollectionIdForLeadingInvoice);

		JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
		je.executeScript("arguments[0].click();", ClickOnDevCollectionIdForLeadingInvoice);
		// ClickOnDevCollectionIdForLeadingInvoice.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(1000);
	}

	public void SelectDevCollectionIdForCustomerManagement() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforVisiblityofElement(ClickOnDevCollectionIdForLeadingInvoice);

		JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
		je.executeScript("arguments[0].click();", ClickOnDevCollectionIdForLeadingInvoice);
		// ClickOnDevCollectionIdForLeadingInvoice.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(1000);
	}

	public void ClickOnDevCollection() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforVisiblityofElement(ClickOnCollectionId);
		ClickOnCollectionId.click();
		// BaseClass.SwitchToDefaultFrame();
		Thread.sleep(10000);
	}

	public void ClickOnCollectionIdAu() throws InterruptedException {

		JavascriptExecutor js1 = (JavascriptExecutor) lwebDriver;
		js1.executeScript("window.scrollBy(0,500)");
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforVisiblityofElement(ClickOnCollectionIdAu);
		ClickOnCollectionIdAu.click();
		// BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);
	}

	public void SwitchTonewWindow() throws InterruptedException { // Giri
		Set<String> Handles = lwebDriver.getWindowHandles();
		// System.out.println("Windows "+Handles);
		for (String windows : Handles) {

			if (!Handles.equals("3F1B6FA063B197FB801A9C15F9E40465")) {
				logger.info("switch To Window");
				lwebDriver.switchTo().window(windows);
				System.out.println("page tittle= " + lwebDriver.getTitle());
				logger.info(" Balance print was avalible with separate window ");
				Assert.assertTrue(true);
			} else {
				logger.info(" Not able to find any Balance print page for collection ");
				Assert.assertTrue(false);
			}
		}
		BaseClass.SwitchToDefaultFrame();

	}

	public void SwitchTonewWindowInQ() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		String mainwindow = lwebDriver.getWindowHandle();
		Set<String> s1 = lwebDriver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
				lwebDriver.switchTo().window(ChildWindow);
			}
		}
		try {
			for (int i = 0; i < 5; i++)
				lwebDriver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL, Keys.SUBTRACT);
		} catch (Exception e) {

		}
		logger.info("Cleared the all previous tabs");
		BaseClass.SwitchToDefaultFrame();
	}

	public static void Zoomchrome() throws Exception {
		Robot robot = new Robot();
		for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}

	}

	public void SwitchTonewWindowInQ_HC() throws InterruptedException {
		// ArrayList<String> newTab = new
		// ArrayList<String>(lwebDriver.getWindowHandles());
		// change focus to new tab
		// lwebDriver.switchTo().window(newTab.get(0));

		// lwebDriver.switchTo().defaultContent();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		String mainwindow = lwebDriver.getWindowHandle();
		Set<String> s1 = lwebDriver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();

		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
				lwebDriver.switchTo().window(ChildWindow);
				Thread.sleep(5000);
				Set<String> s = lwebDriver.getWindowHandles();
				for (String i : s) {
					String t = lwebDriver.switchTo().window(i).getTitle();
					System.out.println(t);
				}
				BaseClass.SwitchToDefaultFrame();
			}

			// WebElement text = lwebDriver.findElement(By.id("sampleHeading"));
			// System.out.println("Heading of child window is " + text.getText());
			// lwebDriver.close();
			// System.out.println("Child window closed");
		}
	}

	// Switch back to the main window which is the parent window.
	// lwebDriver.switchTo().window(mainwindow);


	public void SwitchTonewWindowForQ() throws InterruptedException {
		// ArrayList<String> newTab = new
		// ArrayList<String>(lwebDriver.getWindowHandles());
		// change focus to new tab
		// lwebDriver.switchTo().window(newTab.get(0));

		// lwebDriver.switchTo().defaultContent();

		String mainwindow = lwebDriver.getWindowHandle();
		Set<String> s1 = lwebDriver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();

		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
				lwebDriver.switchTo().window(ChildWindow);
				Thread.sleep(4000);

				// WebElement text = lwebDriver.findElement(By.id("sampleHeading"));
				// System.out.println("Heading of child window is " + text.getText());
				// lwebDriver.close();
				// System.out.println("Child window closed");
			}
		}

		// Switch back to the main window which is the parent window.
		// lwebDriver.switchTo().window(mainwindow);
		// BaseClass.SwitchToDefaultFrame();
	}

	public void SwitchTonewWindow1() throws InterruptedException {
		// ArrayList<String> newTab = new
		// ArrayList<String>(lwebDriver.getWindowHandles());
		// change focus to new tab
		// lwebDriver.switchTo().window(newTab.get(0));

		// lwebDriver.switchTo().defaultContent();

		String mainwindow = lwebDriver.getWindowHandle();
		Set<String> s1 = lwebDriver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();

		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
				lwebDriver.switchTo().window(ChildWindow);
				Thread.sleep(5000);

				// WebElement text = lwebDriver.findElement(By.id("sampleHeading"));
				// System.out.println("Heading of child window is " + text.getText());
				lwebDriver.close();
				System.out.println("Child window closed");
			}
		}

		// Switch back to the main window which is the parent window.
		lwebDriver.switchTo().window(mainwindow);

	}
	// lwebDriver.quit();

	public void SwitchTonewWindowForScheduleReport() throws InterruptedException {
		// ArrayList<String> newTab = new
		// ArrayList<String>(lwebDriver.getWindowHandles());
		// change focus to new tab
		// lwebDriver.switchTo().window(newTab.get(0));

		// lwebDriver.switchTo().defaultContent();

		String mainwindow = lwebDriver.getWindowHandle();
		Set<String> s1 = lwebDriver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();

		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!mainwindow.equalsIgnoreCase(ChildWindow)) {
				lwebDriver.switchTo().window(ChildWindow);
				Thread.sleep(5000);

				ClickOnTimeofDayforScheduleReport.click();
				Select sc = new Select(ClickOnTimeofDayforScheduleReport);
				sc.selectByVisibleText("6 PM");


				ClickOnAddUser.click();


				EnterAddUsername.sendKeys("Saleem Pasha");
				ClickOnSelectUserInScheduleReport.click();
				ClickOnSubmitButtonrInScheduleReport.click();
				Thread.sleep(1000);

				// WebElement text = lwebDriver.findElement(By.id("sampleHeading"));
				// System.out.println("Heading of child window is " + text.getText());
				// lwebDriver.close();
				// System.out.println("Child window closed");
			}
		}

		// Switch back to the main window which is the parent window.
		lwebDriver.switchTo().window(mainwindow);
		BaseClass.SwitchToDefaultFrame();
	}

	public void ClickOnMyCustomerTab() throws InterruptedException {
		JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
		je.executeScript("arguments[0].click();", ClickOnMyCustomer);
		// ClickOnMyCustomer.click();

	}

//WorkQueues

	public void SelectWorkQueuesFromPersonalmenu() {
		try {


			ClickOnWorkQueues.click();
		} catch (StaleElementReferenceException e) {

		}
	}

	public void CancelworkQueuesPage() {

		ClickOnCancelINworkQueues.click();
	}

	public void BurgerMenu() throws InterruptedException {
		Thread.sleep(5000);
		BaseClass.WaitforVisiblityofElement(main_menu);

		// Wait for the overlay to disappear
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("pega_ui_mask")));

		// Click the main menu
		main_menu.click();

		logger.info("Click on Burger bar");
	}


	public void SelectManageWorkQueues() {
		ClickOnManageWorkQueues.click();
	}

	public void SelectWorkBasketForPersonalWorkQueue() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnWorkBasketForPersonalWorkQueue.click();
	}

	public void SelectWorkBasketForPersonalWorkQueueASNRC() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnWorkBasketForPersonalWorkQueueASNRC.click();
	}

	public void SelectWorkBasketForPersonalWorkQueueUSRC() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnWorkBasketForPersonalWorkQueueUSRC.click();
	}

	public void SelectWorkBasketForPersonalWorkQueueInQ() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnWorkBasketForPersonalWorkQueueInQ.click();
	}

	public void SelectWorkBasketForPersonalWorkQueueInQForBusiness() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnWorkBasketForPersonalWorkQueueInQBusinessBucket.click();
	}

	public void SelectBusinessWorkBasketForPersonalWorkQueue() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnBusinessWorkBasetForPersonalWorkQueue.click();
	}

	public void AddWorkBasket() {
		ClickOnAddWorkBasket.click();
	}

	public void ManageWorkQueueSubmit() throws InterruptedException {
		ClickOnManageWorkQueueSubmit.click();
		Thread.sleep(3999);
		BaseClass.SwitchToDefaultFrame();
	}


	public void SelectUserIdForManageWorkQueues() throws InterruptedException {


		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickOnSelectUserId);
		ClickOnSelectUserId.sendKeys("Z004E28U");
		ClickOnSelectUserId.clear();
		ClickOnSelectUserId.sendKeys("Z004E28");
		ClickOnSelectUserId.sendKeys("U");


		// Actions ac=new Actions(lwebDriver);
		// ac.moveToElement(SelectGID).click().build().perform();

		executor.executeScript("arguments[0].click();", SelectGID);
		// BaseClass.SwitchToDefaultFrame();

	}

	public void SelectBusinessWorkBasket() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);

		ClickOnBusinessWorkBasetForPersonalWorkQueue.click();
	}

	public void NewDisputeBasket() {

		ClickOnNewDisputeBasket.click();
	}

	public void EnterCompanyNameForBusinessWorkBasket() {

		CompanyNameForBusinessWorkBasket.sendKeys("Bind Dispute");
	}

	public void EnterCompanyCodeNameForBusinessWorkBasketForValidation() throws InterruptedException {
		CompanyCodeNameForBusinessWorkBasket.sendKeys("TestTest");

	}

	public void EnterCompanyCodeNameForBusinessWorkBasket() throws InterruptedException {
		try {

			CompanyCodeNameForBusinessWorkBasket.sendKeys("2052");
			Thread.sleep(2000);
		} catch (StaleElementReferenceException e) {

		}

	}

	public void EnterCompanyCodeNameForBusinessWorkBasketInQ() throws InterruptedException {
		try {

			CompanyCodeNameForBusinessWorkBasket.sendKeys("0200");
			Thread.sleep(2000);
		} catch (StaleElementReferenceException e) {

		}

	}

	public void EnterCompanyCodeNameForBusinessWorkBasketInQUSRC() throws InterruptedException {
		try {

			CompanyCodeNameForBusinessWorkBasket.sendKeys("5620");
			Thread.sleep(2000);
		} catch (StaleElementReferenceException e) {

		}

	}

	public void SubmitForBusinessWorkBasket() throws InterruptedException {
		try {
			JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
			je.executeScript("arguments[0].click();", ClickOnSubmitForBusinessWorkBasket);
			// ClickOnSubmitForBusinessWorkBasket.click();
			Thread.sleep(2000);
		} catch (StaleElementReferenceException e) {

		}
	}

	public void SubmitForBusinessWorkBasketControlback() {
		ClickOnSubmitForBusinessWorkBasket.click();
		BaseClass.SwitchToDefaultFrame();
	}

	public void ChangeAvailabilityForBusinessWorkBasket() throws InterruptedException {
		JavascriptExecutor je = (JavascriptExecutor) lwebDriver;
		je.executeScript("arguments[0].click();", ClickOnChangeAvailabilityForBusinessWorkBasket);
		// ClickOnChangeAvailabilityForBusinessWorkBasket.click();
		Thread.sleep(2000);
	}

	public void TrashIconForBusinessWorkBasket() {
		ClickOnTrashIconForBusinessWorkBasket.click();
	}

	public void WorkQueuesInMyWorkPage() {
		ClickOnWorkQueuesInMyWorkPage.click();
	}

	public void SelectOneWorkbasketForBusinessWorkBasket() {
		ClickOnAnyOneWorkbasketForBusinessWorkBasket.click();
	}

	public void AddItemForBusinessWorkBasket() {
		ClickOnAddItemForBusinessWorkBasket.click();

		AddEmailForBusinessWorkBasket.sendKeys("Pradeep.dh@siemens.com");

	}

//Filtering&Sorting

	public void SelectSortOptionForCategory() throws InterruptedException {
		try {
			Thread.sleep(3000);
			JavascriptExecutor js1 = (JavascriptExecutor) lwebDriver;
			js1.executeScript("window.scrollBy(0,4000)");
			ClickOnSortOptionForCategory.click();
			Thread.sleep(3000);
		} catch (StaleElementReferenceException e) {

		}

	}

	public void SelectDescendingSortOptionForCategory() throws InterruptedException {
		try {
			ClickOnDescendingSortArrowOptionForCategory.click();
			Thread.sleep(3000);
		} catch (StaleElementReferenceException e) {

		}

	}


	public void VerifyDescendingSortForCategory() {
		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//span[text()='ReviewStrategy'])[1]")));
		Assert.assertTrue(VerifyDescendingForCategory.isDisplayed(), "Verify Descending Sort For Category");

	}

//EditProfile

	public void SelectprofileFromMyAccount() throws InterruptedException {
		try {
			JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
			executor.executeScript("arguments[0].click();", ClickOnprofileInMyAccount);
			// ClickOnprofileInMyAccount.click();
			Thread.sleep(5000);
		} catch (NoSuchFrameException e) {

		}

	}

	public void EditAboutYourProfile() {
		try {
			BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
			ClickOnEditForAboutYourProfile.click();
		} catch (NoSuchFrameException e) {

		}
	}

	public void AddAboutYourProfile() {
		AddboutMe.click();
		AddboutMe.clear();
		AddboutMe.sendKeys("Pradeep Software Test Specialist In Automation");

	}


	public void VerifyAddAboutYourProfile() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//span[text()='Pradeep Software Test Specialist In Automation']")));
		Assert.assertTrue(VerifyAddAboutMe.isDisplayed(), "Verified About Your Profile");
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();

	}

//ItemSearch

	public void SelectitemSearchFromburgerMenu() {
		ClickOnItemSearch.click();

	}

	public void SearchItem() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		CustomerAndItemSearch.sendKeys("0114216860");
	}

	public void SearchItemInQ() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		CustomerAndItemSearch.sendKeys("0952354932");
	}

	public void SearchItemInQUKRC() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		CustomerAndItemSearch.sendKeys("21I200526599");
	}

	public void SearchItemInQASNRC() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		CustomerAndItemSearch.sendKeys("21I200526599");
	}

	public void SearchItemInQUSRC() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		CustomerAndItemSearch.sendKeys("1401663991");
	}

	public void ClickOnSearchButtonInItemSearchPage() {
		ClickOnSearchButtonInCustmerAndItemSearchPage.click();

	}

	public void IsCustomerDisplayed() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		Thread.sleep(3000);
		Assert.assertTrue(VeriFyCustomerDisplayed.isDisplayed(), "Customer Displayed");
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsCustomerDisplayedInQ() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);

		Assert.assertTrue(VeriFyCustomerDisplayedInQ.isDisplayed(), "Customer Displayed");
		String s = VeriFyCustomerDisplayedInQ.getText();
		System.out.println(s);
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsCustomerDisplayedInQUKRC() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);

		Assert.assertTrue(VeriFyCustomerDisplayedInQUKRC.isDisplayed(), "Customer Displayed");
		String s = VeriFyCustomerDisplayedInQUKRC.getText();
		System.out.println(s);
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsCustomerDisplayedInQASNRC() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);

		Assert.assertTrue(ClickOnQACollectionIdASNRC.isDisplayed(), "Customer Displayed");
		String s = ClickOnQACollectionIdASNRC.getText();
		System.out.println(s);
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsCustomerDisplayedInQUSRC() {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);

		Assert.assertTrue(ClickOnQACollectionIdUSRC.isDisplayed(), "Customer Displayed");
		String s = ClickOnQACollectionIdUSRC.getText();
		System.out.println(s);
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsReferenceNumberDisplayed() {

		Assert.assertTrue(VeriFySearchedReferenceNumber.isDisplayed(), "Referece Number Displayed");
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsReferenceNumberDisplayedInQ() {

		Assert.assertTrue(VeriFySearchedReferenceNumberInQ.isDisplayed(), "Referece Number Displayed");
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsReferenceNumberDisplayedInQUKRC() {

		Assert.assertTrue(VeriFySearchedReferenceNumberInQUKRC.isDisplayed(), "Referece Number Displayed");
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsReferenceNumberDisplayedInQASNRC() {

		Assert.assertTrue(VeriFySearchedReferenceNumberInQUKRC.isDisplayed(), "Referece Number Displayed");
		BaseClass.SwitchToDefaultFrame();

	}

	public void IsReferenceNumberDisplayedInQUSRC() {

		Assert.assertTrue(VeriFySearchedReferenceNumberInQUKRC.isDisplayed(), "Referece Number Displayed");
		BaseClass.SwitchToDefaultFrame();

	}

//BulkaAssignEmails

	public void SelectBulkAssignFromburgerMenu() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", ClickOnBulkAssignemails);
		ClickOnBulkAssignemails.click();

		Thread.sleep(5000);

	}

	public void SearchCustomerNoInBulkAssignEmailsPage(String Customernumber) throws InterruptedException {
		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
		// BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		Thread.sleep(3000);

		EnterCustomerNoInBulkAssignEmailsPage.sendKeys(Customernumber);
		Thread.sleep(5000);
	}

	public void ClickSearchButtonInBulkAssigEmailsPage() throws InterruptedException {

		ClickOnSearchButtonInBulkAssigEmailsPage.click();
		Thread.sleep(6000);



		Thread.sleep(3000);

		lwebDriver.findElement(By.xpath(
						"//input[contains(@name,'$PD_CollectionListByCustomerSearch_pa') and @type='radio']"))
				.click();
		Thread.sleep(4000);
	}

	public void ClickSearchButtonInBulkAssigEmailsPage_HC_US() throws InterruptedException {

		ClickOnSearchButtonInBulkAssigEmailsPage.click();
		Thread.sleep(6000);



		Thread.sleep(3000);

		lwebDriver.findElement(By.xpath(
						"//input[contains(@name,'$PD_CustomerSearchWithEmail_pa') and @type='radio']"))
				.click();
		Thread.sleep(4000);
	}

	public void SlectRadioButtonInBulkAssignEmailsPage() throws InterruptedException {


		WebElement radiobutton = lwebDriver.findElement(By.xpath(
				"//*[@class='oddRow cellCont'][1]//child::td[1]//child::input[contains(@name,'$PD_CustomerSearchWithEmail_pa')][2]"));
		radiobutton.click();
		Thread.sleep(4000);
		if (radiobutton.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Radio button have selected");
		} else {
			logger.info("Did not select Radio button in Bulk Assign email page");
			Assert.assertTrue(false);
		}
		Thread.sleep(4000);

	}

	public void ClickAssignInBulkAssigEmailsPage() throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement assignemaildata_1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[contains(text(),'Select')]//following::div[2]/child::table")));
		logger.info("Loading email data from the table");
		String assignemaildata = assignemaildata_1.getText();
		// System.out.println("Before assign email to customer="+assignemaildata);
		WebElement Checkbox = lwebDriver.findElement(By.xpath(
				"//table//child::input[contains(@name,'$PD_UnassignedIncomingEmailsList$ppxResults$l1$ppySelected')][2]"));
		Checkbox.click();
		Thread.sleep(2000);
		if (Checkbox.isSelected()) {
			Assert.assertTrue(true);
			logger.info("check box have selected");
		} else {
			logger.info("Did not select check box in Bulk Assign email page");
			Assert.assertTrue(false);
		}
		logger.info("Click on Assin button");
		WebElement Assignbutton = lwebDriver.findElement(By.xpath("//button[contains(text(),'Assign')]"));
		Assignbutton.click();
		Thread.sleep(15000);
		String assignemaildata1 = lwebDriver
				.findElement(By.xpath("//a[contains(text(),'Select')]//following::div[2]/child::table")).getText();
//		  BaseClass.WaitforElementToBeClickable(By.xpath("//div[text()='Search']"));
//		  ClickOnassignInBulkAssigEmailsPage.click();
		if (assignemaildata.equals(assignemaildata1)) {
			Assert.assertTrue(false);
			logger.info("Did not assign an email to the customer.");
		} else {
			Assert.assertTrue(true);
			logger.info(
					"The email assigned to the customer has been removed from the assigned email table on the page");
		}

		BaseClass.SwitchToDefaultFrame();
	}


	public void Select_Advanced_Item_filters1(String Line_Property, String Value) throws Exception {
		logger.info("Click on additeam option under Advanced Item filters ");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Advanced_Itema = wait.until(ExpectedConditions.elementToBeClickable(Advanced_Item));
			Advanced_Itema.click();
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[1]")));
			WebElement textbox = lwebDriver.findElement(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[1]"));
			textbox.sendKeys(Line_Property);
			logger.info("Selected for Line Item Property ");
			Thread.sleep(3000);
			textbox.sendKeys(Keys.ARROW_DOWN);

			textbox.sendKeys(Keys.ENTER);
			Thread.sleep(3000);
			WebElement
					Values = lwebDriver.findElement(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[4]"));
			Values.sendKeys(randomText);
			logger.info("Select value for customer number ");
			lwebDriver.findElement(By.xpath("//button[text()='  Submit ']")).click();
			Thread.sleep(4000);
			logger.info("Click on sumit button");
			//BaseClass.SwitchToDefaultFrame();


		} catch (TimeoutException e) {
			BaseClass.SwitchToDefaultFrame();
			BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Advanced_Itema = wait.until(ExpectedConditions.elementToBeClickable(Advanced_Item));
			Advanced_Itema.click();
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[1]")));
			WebElement textbox = lwebDriver.findElement(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[1]"));
			textbox.sendKeys(Line_Property);
			logger.info("Selected for Line Item Property ");
			Thread.sleep(3000);
			textbox.sendKeys(Keys.ARROW_DOWN);

			textbox.sendKeys(Keys.ENTER);
			Thread.sleep(3000);
			WebElement
					Values = lwebDriver.findElement(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[4]"));
			Values.sendKeys(Value);
			logger.info("Select value for customer number ");
			lwebDriver.findElement(By.xpath("//button[text()='  Submit ']")).click();
			Thread.sleep(4000);
			logger.info("Click on sumit button");
			//BaseClass.SwitchToDefaultFrame();

		}
	}

	public void ClickAssignInBulkAssigEmailsPage_IN() throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement assignemaildata_1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_UnassignedIncomingEmailsList$ppxR')]")));
		logger.info("Loading email data from the table");
		String assignemaildata = assignemaildata_1.getText();
		System.out.println("Before assign email to customer=" + assignemaildata);
		WebElement Checkbox = lwebDriver.findElement(By.xpath(
				"(//input[@type='checkbox' and @data-test-id='20190902143459099182190'])[1]"));
		Checkbox.click();
		Thread.sleep(2000);
		if (Checkbox.isSelected()) {
			Assert.assertTrue(true);
			logger.info("check box have selected");
		} else {
			logger.info("Did not select check box in Bulk Assign email page");
			Assert.assertTrue(false);
		}
		logger.info("Click on Assin button");
		WebElement Assignbutton = lwebDriver.findElement(By.xpath("//button[contains(text(),'Assign')]"));
		Assignbutton.click();
		Thread.sleep(15000);
		String assignemaildata1 = lwebDriver
				.findElement(By.xpath("//tr[contains(@id,'$PD_UnassignedIncomingEmailsList$ppxR')]")).getText();
//		  BaseClass.WaitforElementToBeClickable(By.xpath("//div[text()='Search']"));
//		  ClickOnassignInBulkAssigEmailsPage.click();
		if (assignemaildata.equals(assignemaildata1)) {
			Assert.assertTrue(false);
			logger.info("Did not assign an email to the customer.");
		} else {
			Assert.assertTrue(true);
			logger.info(
					"The email assigned to the customer has been removed from the assigned email table on the page");
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void ClickAssignInBulkAssigEmailsPage1() throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Select')]//following::div[14]/child::table")));


		logger.info("Loading email data from the table");
		String assignemaildata = table.getText();


		// System.out.println("Before assign email to customer="+assignemaildata);

		WebElement Checkbox = lwebDriver.findElement(By.xpath(
				"//a[contains(text(),'Select')]//following::div[14]/child::table//child::input[contains(@name,'$PD_UnassignedIncomingEmailsList$ppxResults$l1$ppySelected')][2]"));

		Checkbox.click();
		Thread.sleep(2000);

		if (Checkbox.isSelected()) {
			Assert.assertTrue(true);
			logger.info("check box have sClickAssignInBulkAssigEmailsPage_MESAelected");
		} else {
			logger.info("Did not select check box in Bulk Assign email page");
			Assert.assertTrue(false);
		}
		logger.info("Click on Assin button");
		WebElement Assignbutton = lwebDriver.findElement(By.xpath("//button[contains(text(),'Assign')]"));
		Assignbutton.click();
		Thread.sleep(15000);

		String assignemaildata1 = lwebDriver
				.findElement(By.xpath("//a[contains(text(),'Select')]//following::div[14]/child::table")).getText();

//		  BaseClass.WaitforElementToBeClickable(By.xpath("//div[text()='Search']"));
//		  ClickOnassignInBulkAssigEmailsPage.click();

		if (assignemaildata.equals(assignemaildata1)) {
			Assert.assertTrue(false);
			logger.info("Did not assign an email to the customer.");
		} else {
			Assert.assertTrue(true);
			logger.info(
					"The email assigned to the customer has been removed from the assigned email table on the page");
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void Fliter_Action1(String Invoice) throws InterruptedException {


		WebElement fliter = lwebDriver.findElement(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following::span[2]/child::a"));
		if (fliter.isDisplayed() && fliter.isEnabled()) {
			Assert.assertTrue(true);
			fliter.click();
			Thread.sleep(3000);
			logger.info("clicked on cust Fliter in table");

		} else {
			logger.info("Unable to find  cust Fliter in table");
			Assert.assertTrue(false);
		}

		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")).sendKeys(randomText);
		logger.info("Entered customer number in text box");
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")).click();
		logger.info("Click on Apply");
//		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
//		WebElement Task_Due = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='gridLayoutTable']//descendant::th[@id='a5']/descendant::*[text()='Task Due Date']")));
//
//
//		try {
//
//
//			logger.info("sorting for Task Due Date");
//			Thread.sleep(3000);
//			Task_Due.click();
//
//
//		} catch (StaleElementReferenceException e) {
//
//
//			e.getMessage();
//
//		}finally{
//			WebElement Task_Due1 = lwebDriver.findElement(By.xpath("//table[@id='gridLayoutTable']//descendant::th[@id='a5']/descendant::*[text()='Task Due Date']"));
//
//
//			Thread.sleep(3000);
//			logger.info("sorting for Task Due Date");
//			Task_Due1.click();
//			Thread.sleep(5000);
//
//			WebElement Task_Due2 = lwebDriver.findElement(By.xpath("//table[@id='gridLayoutTable']//descendant::th[@id='a5']/descendant::*[text()='Task Due Date']"));
//			Task_Due2.click();
		Thread.sleep(5000);
//		}


	}

	public void ClickAssignInBulkAssigEmailsPage_MESA() throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement table = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(text(),'Select')]//following::div[2]/child::table")));


		logger.info("Loading email data from the table");
		String assignemaildata = table.getText();


		// System.out.println("Before assign email to customer="+assignemaildata);

		WebElement Checkbox = lwebDriver.findElement(By.xpath(
				"//a[contains(text(),'Select')]//following::div[2]/child::table//child::input[contains(@name,'$PD_UnassignedIncomingEmailsList$ppxResults$l1$ppySelected')][2]"));

		Checkbox.click();
		Thread.sleep(2000);

		if (Checkbox.isSelected()) {
			Assert.assertTrue(true);
			logger.info("check box have selected");
		} else {
			logger.info("Did not select check box in Bulk Assign email page");
			Assert.assertTrue(false);
		}
		logger.info("Click on Assin button");
		WebElement Assignbutton = lwebDriver.findElement(By.xpath("//button[contains(text(),'Assign')]"));
		Assignbutton.click();
		Thread.sleep(15000);

		String assignemaildata1 = lwebDriver
				.findElement(By.xpath("//a[contains(text(),'Select')]//following::div[2]/child::table")).getText();

//		  BaseClass.WaitforElementToBeClickable(By.xpath("//div[text()='Search']"));
//		  ClickOnassignInBulkAssigEmailsPage.click();

		if (assignemaildata.equals(assignemaildata1)) {
			Assert.assertTrue(false);
			logger.info("Did not assign an email to the customer.");
		} else {
			Assert.assertTrue(true);
			logger.info(
					"The email assigned to the customer has been removed from the assigned email table on the page");
		}

		BaseClass.SwitchToDefaultFrame();
	}

//MyWorkTalies

	public void SelectOverdueTask() throws InterruptedException {

		ClickOnOverDuetask.click();
		String s = VerifyOverDueTaskText.getText();

		System.out.println("Tile Count is:" + s);

		Thread.sleep(5000);

	}

	public void GetCountAndprintForAllTask() throws InterruptedException {
		try {
			JavascriptExecutor js1 = (JavascriptExecutor) lwebDriver;
			js1.executeScript("window.scrollBy(0,20000)");

			// BaseClass.WaitforElementToBeClickable(By.xpath("//span[text()='Overdue
			// Tasks']"));
			// List<WebElement> TotalTaskCount=AllOverDuetask;
			int size = AllTask1.size();
			System.out.println(size);
			// BaseClass.WaitforElementToBeClickable(By.xpath("//div[@data-test-id='20141121165713062143523']"));
			// ClickOnNext.click();
			Thread.sleep(3000);

			// js1.executeScript("window.scrollBy(0,20000)");
			// int size2= AllTask.size();
			// System.out.println(size2);
			// BaseClass.WaitforElementToBeClickable(By.xpath("//div[@data-test-id='20141121165713062143523']"));
			// js1.executeScript("arguments[0].click();", ClickOnNext);
			// Thread.sleep(3000);
			// ClickOnNext.click();
			// js1.executeScript("window.scrollBy(0,20000)");
			// int size3= AllTask.size();
			// System.out.println(size3);
		} catch (StaleElementReferenceException e) {

		}
//		 for(int i=0;i<size;i++) {

//			 System.out.println(AllTask.get(i) .getText());
//			 Thread.sleep(5000);

//		 }

	}

	public void IsOverduetaskCorrect() {

		// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='
		// CO-5015043']")));
		// Assert.assertTrue( VerifyAllTask.isDisplayed(),"Referece Number Displayed");
		int size = AllTask1.size();
		// int size2=VerifyOverDueTask.size();
		String s = VerifyOverDueTaskText.getText();
		String s1 = String.valueOf(size);
		System.out.println("Tile count:" + s);
		System.out.println("Tile count:" + s1);
		// int
		// OverDue=lwebDriver.findElement(By.xpath("//span[@data-test-id='20160606052543041811468']"));

		if (s == s1) {
			System.out.println("Overdue Task count is correct");
		}
		// BaseClass.SwitchToDefaultFrame();

	}

	public void IsMytaskCorrect() {

		// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='
		// CO-5015043']")));
		// Assert.assertTrue( VerifyAllTask.isDisplayed(),"Referece Number Displayed");
		int size = AllTask1.size();
		String s = VerifyMyTask.getText();
		String s1 = String.valueOf(size);
		System.out.println("Tile count:" + s);
		System.out.println("Tile count:" + s1);

		if (s == s1) {
			System.out.println("Overdue Task count is correct");
		}

	}

	public void IsMyCustomerCorrect() {

		// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='
		// CO-5015043']")));
		// Assert.assertTrue( VerifyAllTask.isDisplayed(),"Referece Number Displayed");

		int size = AllTask1.size();
		String s = VerifyMyCustomer.getText();
		String s1 = String.valueOf(size);
		System.out.println("Tile count:" + s);
		System.out.println("Tile count:" + s1);

		// if(size==size2)

		if (s == s1) {
			System.out.println("Overdue Task count is correct");
		}

	}

	public void IsUnAssignedEmailsCorrect() {

		// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='
		// CO-5015043']")));
		// Assert.assertTrue( VerifyAllTask.isDisplayed(),"Referece Number Displayed");
		if (VerifyUnAssignedEmail == AllTask) {
			System.out.println("Overdue Task count is correct");
		}

	}

	public void IsPromiseToPayCorrect() {


	}

	public void IsMyOpenDisputesCorrect() {

		// wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='
		// CO-5015043']")));
		// Assert.assertTrue( VerifyAllTask.isDisplayed(),"Referece Number Displayed");
		if (VerifyMyOpenDisputes == AllTask) {
			System.out.println("Overdue Task count is correct");
		}

	}

	public void SelectMyTask() throws InterruptedException {
		ClickonMyTask.click();
		String s = VerifyMyTask.getText();
		System.out.println(s);

		Thread.sleep(5000);

	}

	public void SelectMycustomer() throws InterruptedException {
		ClickOnMyCustomer.click();
		String s = VerifyMyCustomer.getText();
		System.out.println(s);
		Thread.sleep(5000);

	}

	public void SelectLegalAssignment() throws InterruptedException {
		ClickOnLegalAssignment.click();
		Thread.sleep(5000);

	}

	public void SelectPendingLegal() throws InterruptedException {
		ClickOnPendingLegal.click();
		Thread.sleep(5000);

	}

	public void getReminderSize(String Invoice) throws InterruptedException {
		String Before_count;
		WebElement element;
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement reminder = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='My Tasks']/following::div[1]/span")));
		Before_count = reminder.getText();
		System.out.println(Before_count);
		WebElement fliter = lwebDriver.findElement(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following::span[2]/child::a"));
		if (fliter.isDisplayed() && fliter.isEnabled()) {
			Assert.assertTrue(true);
			fliter.click();
			Thread.sleep(3000);
			logger.info("clicked on cust Fliter in table");

		} else {
			logger.info("Unable to find  cust Fliter in table");
			Assert.assertTrue(false);
		}

		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")).sendKeys(randomText);
		logger.info("Entered customer number in text box");
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")).click();
		logger.info("Click on Apply");
		Thread.sleep(5000);


		try {
			WebElement click_on_Lineitem = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_MyWorkListByType_pa')][1]//td[2]")));
			((JavascriptExecutor) lwebDriver).executeScript("arguments[0].scrollIntoView(true);", click_on_Lineitem);
			click_on_Lineitem.click();
			logger.info("Click on MakeCall on Mywork");
		} catch (StaleElementReferenceException e) {
			// Retry the operation
			WebElement click_on_Lineitem = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='gridLayoutTable']//descendant::*[text()='Case ID']//following::tr[1]/child::td[2]/child::div")));
			click_on_Lineitem.click();
			logger.info("Click on MakeCall on Mywork (Retry)");
		}
		BaseClass.SwitchToDefaultFrame();

        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.tagName("iframe")));
		WebElement Click_on_Resloved = wait.until(ExpectedConditions.elementToBeClickable(Click_on_Reslove));

		Thread.sleep(5000);
		if (Click_on_Resloved.isEnabled()) {
			Assert.assertTrue(true);
			Click_on_Resloved.click();
			Thread.sleep(5000);
			logger.info("Click on Reslove");
		} else {
			logger.info("Did not click on Reslove button");
			Assert.assertTrue(false);
		}

		BaseClass.SwitchToDefaultFrame();

		try {
			// Wait for the element to be visible and clickable
			WebElement refreshButton = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[contains(text(),'Refresh')])[1]")));
			refreshButton = wait.until(ExpectedConditions.elementToBeClickable(refreshButton));

			// Scroll into view
			((JavascriptExecutor) lwebDriver).executeScript("arguments[0].scrollIntoView(true);", refreshButton);

			try {
				// Attempt to click using JavaScript
				((JavascriptExecutor) lwebDriver).executeScript("arguments[0].click();", refreshButton);
			} catch (ElementClickInterceptedException e) {
				// If click is intercepted, log the issue and attempt a workaround if possible
				System.out.println("ElementClickInterceptedException caught: " + e.getMessage());

				// Wait for the interfering element to be invisible
				wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("pega_ui_mask")));

				// Attempt to click again using JavaScript
				((JavascriptExecutor) lwebDriver).executeScript("arguments[0].click();", refreshButton);
			}
		} catch (TimeoutException e) {
			// Handle case where the element is not found within the timeout
			System.out.println("TimeoutException caught: " + e.getMessage());
		} catch (NoSuchElementException e) {
			// Handle case where the element is not present in the DOM
			System.out.println("NoSuchElementException caught: " + e.getMessage());
		} catch (Exception e) {
			// Handle any other unexpected exceptions
			System.out.println("Exception caught: " + e.getMessage());
		}
         logger.info("click on Refresh");

		Thread.sleep(3000);
		try {
			// Wait for the overlay to disappear
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("pega_ui_mask")));

			// Wait for the element to be clickable
			WebElement promiseToPay = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(@id,'PEGA_GRID')]//child::td[text()=' Reminder  '])[1]")));

			// Scroll into view
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", promiseToPay);

			try {
				// Attempt to click using JavaScript
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", promiseToPay);
			} catch (ElementClickInterceptedException e) {
				// If click is intercepted, log the issue
				System.out.println("ElementClickInterceptedException caught: " + e.getMessage());

				// Retry clicking using JavaScript after a short wait to ensure the element is ready
				Thread.sleep(500); // Add a short delay to ensure the element is ready
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", promiseToPay);
			}
		} catch (TimeoutException e) {
			// Handle case where the element or overlay is not found within the timeout
			System.out.println("TimeoutException caught: " + e.getMessage());
		} catch (NoSuchElementException e) {
			// Handle case where the element is not present in the DOM
			System.out.println("NoSuchElementException caught: " + e.getMessage());
		} catch (Exception e) {
			// Handle any other unexpected exceptions
			System.out.println("Exception caught: " + e.getMessage());
		}

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(40));

		WebElement refresh_Button = wait3.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),'Refresh')])[1]")));
		refresh_Button.click();

		try {
			// Wait for the page to refresh and the count to update
			Thread.sleep(4000);
		} catch (StaleElementReferenceException e) {
			// Retry the operation if a StaleElementReferenceException occurs
			refresh_Button = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),'Refresh')])[1]")));
			refresh_Button.click();

			// Wait for the page to refresh and the count to update after retrying
			Thread.sleep(4000);
		}

		//WebElement count1 = null;
		WebElement count1 = driver.findElement(By.xpath("//span[text()='My Tasks']/following::div[1]/span"));
		boolean staleElement = true;

		while (staleElement) {
			try {
				count1 = driver.findElement(By.xpath("//span[text()='My Tasks']/following::div[1]/span"));
				staleElement = false;
			} catch (StaleElementReferenceException e) {
				// Retry finding the element
			}

			System.out.println(count1.getText());
			Thread.sleep(5000);

			try {

				String count1Text = count1.getText();
				String remindersCount = Before_count;

				if (remindersCount.equals(count1Text)) {
					//	logger.info("Reminder was resloved successfully and removed from list");
					logger.info("Reminder was not  resloved successfully or  still resloved reminder was  visibled in list");
					Assert.assertTrue(false);
				} else {
					Assert.assertTrue(true);
					logger.info("Reminder was resloved successfully and removed from list");
				}
			} catch (StaleElementReferenceException e) {
				// Retry the operation
				count1 = driver.findElement(By.xpath("//span[text()='My Tasks']/following::div[1]/span"));


				String count1Text = count1.getText();
				String remindersCount = Before_count;

				if (!count1Text.equals(remindersCount)) {
					Assert.assertTrue(true);
					logger.info("Reminder was resloved successfully and removed from list");
				} else {
					logger.info("Reminder was not  resloved successfully or  still resloved reminder was  visibled in list");
					Assert.assertTrue(false);
				}
			}
		}
	}

	public void SelectPromisedToPayInMyWorkPage() throws InterruptedException {
		ClickOnPromisedToPayInMyWorkPage.click();
		Thread.sleep(5000);

	}

	public void SelectOPenDisputesInMyWorkPage() throws InterruptedException {
		ClickOnMyOPenDisputesInMyWorkPage.click();
		Thread.sleep(5000);

	}

	public void SelectStrategiesFromburgerMenu() throws InterruptedException {
		ClickOnStrategyFromBurgerMenu.click();
		Thread.sleep(3000);

	}

	public void IsStrategiesPageDisplayedForManager() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);

		Assert.assertTrue(VerifyStrategiesPageForManager.isDisplayed(), "Strategies page is Displayed");
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(3000);

	}

//Strategies

	public void selectStrategyforUpdate() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnStrategyforUpdate.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);

	}

	public void selectStrategyforUpdateInQ() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnStrategyforUpdateInQ.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);

	}

	public void selectActionStrategyforUpdate() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickOnactionInStrategypage);
		// ClickOnactionInStrategypage.click();
		// //button[@name='pyCaseHeaderButtons_pyWorkPage_4']
		Thread.sleep(2000);

	}

	public void selectModifyStrategyFromActionforStrategyforUpdate() throws InterruptedException {

		ClickOnModifyStrategy.click();
		Thread.sleep(2000);

	}

	public void AddItemInCalanderBasedActionStrategy() throws InterruptedException {
		ClickonAddItemInCalanderBasedActionStrategy.click();
		Thread.sleep(2000);


	}

	public void AddActionForStrategy() throws InterruptedException {


		ClickonAddAction.sendKeys("Balance Confirmation");

//		  Actions action =new Actions(lwebDriver);
//		  action.moveToElement(ClickonSelectAction).click().build().perform();

		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickonSelectAction);
		// ClickonSelectAction.click();
		Thread.sleep(2000);

	}

	public void AddActionForStrategyInQ() throws InterruptedException {


		ClickonAddAction.sendKeys("Balance");

//		  Actions action =new Actions(lwebDriver);
//		  action.moveToElement(ClickonSelectAction).click().build().perform();

		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickonSelectActionInQ);
		// ClickonSelectAction.click();
		Thread.sleep(2000);

	}

	public void AddActionLabel() throws InterruptedException {
		ClickonAddActionLabel.sendKeys("Test5");
		Thread.sleep(2000);
	}

	public void Selectfrequency() throws InterruptedException {


		ClickonSelectfrequency.click();
		Select sc = new Select(ClickonSelectfrequency);
		sc.selectByVisibleText("Daily");
		Thread.sleep(2000);
	}

	public void ClickListItempropertyStrategy() throws InterruptedException {


		ClickonListItempropertyStrategy.sendKeys("Is Promised to Pay");

		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", SelectIspromiseToPay);

		// ClickonListItempropertyStrategy.click();
		// SelectIspromiseToPay.sendKeys("Is Promised to Pay");

		Thread.sleep(2000);
	}

	public void SubmitButtonInUpdateStrategy() throws InterruptedException {
		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", SubmitButtonInStrategy);
//		  SubmitButtonInStrategy.click();
		Thread.sleep(5000);
		executor.executeScript("window.scrollBy(0,3000)");
		FinalSubmitButtonInStrategy.click();
		Thread.sleep(2000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void AddItemInAdvanceItemFilterStrategy() throws InterruptedException {
		ClickonAddItemInAdvanceItemFilterStrategy.click();
		Thread.sleep(2000);
	}

	public void RecentAttachmentEmail() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(UpdateFrame);
		ClickOnRecentattach.click();
		Thread.sleep(2000);
		BaseClass.SwitchToDefaultFrame();
	}

//Campaigns

	public void SelectCampaignFromBurgerMenu() throws InterruptedException {
		ClickOnCampaignsFromBurgerMenu.click();
		Thread.sleep(2000);
	}

	public void CreateCampaigns() throws InterruptedException {

		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickOnNewCampaigns);

		// ClickOnNewCampaigns.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);

	}

	public void EnterNameForCampaigns() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		ClickOnCampaignName.clear();
		Thread.sleep(2000);
		ClickOnCampaignName.sendKeys("Automation Campaign");
		Thread.sleep(2000);

	}

	public void SelectCampaignsforUpdate() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnStrategyforUpdate.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);

	}

	public void SelectActionforCampaignsUpdate() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickOnActionInCamaignspage);
		// ClickOnactionInStrategypage.click();
		// //button[@name='pyCaseHeaderButtons_pyWorkPage_4']
		Thread.sleep(2000);

	}

	public void SelectModifyCampaignsFromActionforStrategyforUpdate() throws InterruptedException {

		ClickOnModifyCampaigns.click();
		Thread.sleep(2000);

	}

	public void AddItemActionForCampaigns() throws InterruptedException {

		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickonAddItemActionsCampaigns);
		// ClickonAddItemActionsCampaigns.click();
		Thread.sleep(2000);

	}

	public void AddActionForCampaigns() throws InterruptedException {

		ClickonAddActionInCampaigns.sendKeys("Balance Confirmation");

//			  Actions action =new Actions(lwebDriver);
//			  action.moveToElement(ClickonSelectAction).click().build().perform();

		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickonSelectAction);
		// ClickonSelectAction.click();
		Thread.sleep(2000);

		// BaseClass.WaitforElementToBeClickable(By.xpath("//input[@name='$PpyWorkPage$pFixedActionList$l1$ppyLabel']"));
		// ClickonAddActionInCampaigns.sendKeys("Item Copy");
		// BaseClass.WaitforElementToBeClickable(By.xpath("//span[text()='Email']"));
		// ClickonSelectAction.click();
		// Thread.sleep(2000);

	}

	public void AddActionForCampaignsInQ() throws InterruptedException {

		ClickonAddActionInCampaigns.sendKeys("Balance");

//			  Actions action =new Actions(lwebDriver);
//			  action.moveToElement(ClickonSelectAction).click().build().perform();

		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickonSelectActionInQ);
		// ClickonSelectAction.click();
		Thread.sleep(2000);

		// BaseClass.WaitforElementToBeClickable(By.xpath("//input[@name='$PpyWorkPage$pFixedActionList$l1$ppyLabel']"));
		// ClickonAddActionInCampaigns.sendKeys("Item Copy");
		// BaseClass.WaitforElementToBeClickable(By.xpath("//span[text()='Email']"));
		// ClickonSelectAction.click();
		// Thread.sleep(2000);

	}

	public void AddActionLabelForCampaigns() throws InterruptedException {

		ClickonAddActionLabelInCampaigns.sendKeys("Test1");
		Thread.sleep(2000);
	}

	public void ClickListItempropertyCampaigns() throws InterruptedException {


		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", SelectIspromiseToPayInCampaigns);

		// ClickonListItempropertyStrategy.click();
		// SelectIspromiseToPay.sendKeys("Is Promised to Pay");

		Thread.sleep(2000);
	}

	public void SubmitButtonInUpdateCampaigns() throws InterruptedException {

		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", SubmitButtonInCampaigns);
//			  SubmitButtonInStrategy.click();
		Thread.sleep(5000);
		executor.executeScript("window.scrollBy(0,3000)");
		FinalSubmitButtonInCampaigns.click();
		Thread.sleep(2000);
		// BaseClass.SwitchToDefaultFrame();
	}

	public void AddItemInAdvanceItemFilterCompaigns() throws InterruptedException {

		ClickonAddItemInAdvanceItemFilterCampaigns.click();
		Thread.sleep(2000);
	}

	public void SchedulerCompaigns() throws InterruptedException {

		ClickOnScheduleCampaigns.click();
		ClickOnAcceptButtonForScheduleCampaigns.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);
	}


//CustomerMasterSync

	public void SelectCustomerMasterSyncFromBurgerMenu() throws InterruptedException {
		BaseClass.WaitforElementToBeClickable(ClickOnCustomerMasterSyncFromBurgerMenu);
		ClickOnCustomerMasterSyncFromBurgerMenu.click();
		Thread.sleep(2000);
	}

	public void EnterCompanyCodeForCustomerMasterSync() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforElementToBeClickable(EnterCompanyCodeInCustomerMasterSync);
		EnterCompanyCodeInCustomerMasterSync.sendKeys("598F");
		Thread.sleep(2000);
	}

	public void EnterCompanyCodeForCustomerMasterSyncForUSRC() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		BaseClass.WaitforElementToBeClickable(EnterCompanyCodeInCustomerMasterSync);
		EnterCompanyCodeInCustomerMasterSync.sendKeys("0200");
		Thread.sleep(2000);
	}

	public void EnterCompanyCodeForCustomerMasterSyncInQUKRC() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		EnterCompanyCodeInCustomerMasterSync.sendKeys("598F");
		Thread.sleep(2000);
	}

	public void EnterCompanyCodeForCustomerMasterSyncInQASNRC() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		EnterCompanyCodeInCustomerMasterSync.sendKeys("421S");
		Thread.sleep(2000);
	}

	public void EnterCompanyCodeForCustomerMasterSyncInQUSRC() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		EnterCompanyCodeInCustomerMasterSync.sendKeys("5620");
		Thread.sleep(2000);
	}

	public void EnterCustomerNumberForCustomerMasterSync() throws InterruptedException {
		EnterCustomerNumberInCustomerMasterSync.sendKeys("0008420668");
		Thread.sleep(2000);
	}

	public void EnterCustomerNumberForCustomerMasterSyncForUSRC() throws InterruptedException {
		EnterCustomerNumberInCustomerMasterSync.sendKeys("0000272866");
		Thread.sleep(2000);
	}

	public void EnterCustomerNumberForCustomerMasterSyncInQUKRC() throws InterruptedException {
		EnterCustomerNumberInCustomerMasterSync.sendKeys("0008377877");
		Thread.sleep(2000);
	}

	public void EnterCustomerNumberForCustomerMasterSyncInQASNRC() throws InterruptedException {
		EnterCustomerNumberInCustomerMasterSync.sendKeys("0040193286");
		Thread.sleep(2000);
	}

	public void EnterCustomerNumberForCustomerMasterSyncInQUSRC() throws InterruptedException {
		EnterCustomerNumberInCustomerMasterSync.sendKeys("0030654041");
		Thread.sleep(2000);
	}

	public void EnterSystemForCustomerMasterSync() throws InterruptedException {
		EnterSystemInCustomerMasterSync.sendKeys("SPP01");
		Thread.sleep(2000);
	}

	public void EnterSystemForCustomerMasterSyncForUSRC() throws InterruptedException {
		EnterSystemInCustomerMasterSync.sendKeys("P4001");
		Thread.sleep(2000);
	}

	public void EnterSystemForCustomerMasterSyncInQUKRC() throws InterruptedException {
		EnterSystemInCustomerMasterSync.sendKeys("SPP01");
		Thread.sleep(2000);
	}

	public void EnterSystemForCustomerMasterSyncInQASNRC() throws InterruptedException {
		EnterSystemInCustomerMasterSync.sendKeys("AP001");
		Thread.sleep(2000);
	}

	public void EnterSystemForCustomerMasterSyncInQUSRC() throws InterruptedException {
		EnterSystemInCustomerMasterSync.sendKeys("E1P01");
		Thread.sleep(2000);
	}

	public void ImportInCustomerMasterSync() throws InterruptedException {
		ClickOnImportInCustomerMasterSync.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);
	}

	public void IsMasterSyncImported() throws InterruptedException {


		Assert.assertTrue(VerifyImportInCustomerMasterSync.isDisplayed(), "Validation");
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(3000);

	}

//Customer Assign

	public void SelectCashCollectorFromBurgerMenu() throws InterruptedException {
		ClickOnCashCollectorFromBurgerMenu.click();
		Thread.sleep(2000);
	}

	public void SelectUnAssignedcollectionForCashCollector() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickOnAssignForCashCollector);
		// ClickOnAssignForCashCollector.click();
		Thread.sleep(2000);
	}

	public void EnterCashCollectorNameInAssignCollectionPage() throws InterruptedException {
		ClickOnSearchCashCollector.click();
		ClickOnSearchCashCollector.sendKeys("Pradeep");
		Thread.sleep(2000);
	}

	public void SelectRadioButtonInCashCollectorAssignPage() throws InterruptedException {
		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickOnRadioButtonInCashCollectorAssignPage);
		// ClickOnRadioButtonInCashCollectorAssignPage.click();
		Thread.sleep(2000);
	}

	public void SubmitButtonInCashCollector() throws InterruptedException {
		ClickOnSubmitButtonInCashCollector.click();
		Thread.sleep(2000);
	}

	public void SubmitButtonInCashCollector1() throws InterruptedException {
		ClickOnSubmitButtonInCashCollector.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(2000);
	}

//Reports

	public void SelectReportsFromBurgerMenu() throws InterruptedException {
		ClickOnReportsFromBurgerMenu.click();
		Thread.sleep(1000);
	}

	public void AddReport() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnAddReport.click();
		Thread.sleep(1000);
	}

	public void SelectCaseTypeForReport() throws InterruptedException {
		ClickOnCaseTypeForReport.click();
		Select sc = new Select(ClickOnCaseTypeForReport);
		sc.selectByVisibleText("Dunning Letter 1");
		Thread.sleep(1000);
	}

	public void SelectReportType() throws InterruptedException {
		ClickOnReportType.click();
		Thread.sleep(1000);
	}

	public void SubmitForReport() throws InterruptedException {
		ClickOnSubmitForReport.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(1000);
	}

	public void SelectfilterForSelectValues() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		ClickOnUpdateInLas7tDays.click();

		// JavascriptExecutor executor = (JavascriptExecutor)lwebDriver;
		// executor.executeScript("arguments[0].click();", ClickOnSelectvalues);
		Actions ac = new Actions(lwebDriver);
		ac.moveToElement(ClickOnSelectvalues).click().build().perform();
		// ClickOnSelectvalues.click();
		// Select sc=new Select(ClickOnSelectValuesForSelect);
		// sc.selectByVisibleText("Last 30 Days");

		SelectSelectedvalues.click();
		ClickOnSubmitInSaveReportPage.click();
		Thread.sleep(1000);
	}

	public void DoneEditingForReport() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		ClickOnDoneEditingForReport.click();
		Thread.sleep(1000);
	}

	public void EnterTitleForReport() throws InterruptedException {

		TitleForReport.clear();

		TitleForReport.sendKeys("AAA");
		Thread.sleep(1000);
	}

	public void EnterDescriptionForReport() throws InterruptedException {

		DescriptionForReport.sendKeys("Automation Report");
		Thread.sleep(1000);
	}

	public void SubmitInSaveReportPage() throws InterruptedException {
		ClickOnSubmitInSaveReportPage.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(1000);
	}

	public void BackToReport() throws InterruptedException {
		ClickOnBackReport.click();
		Thread.sleep(1000);
	}

	public void CloseEditReportPage() throws InterruptedException {

		JavascriptExecutor executor = (JavascriptExecutor) lwebDriver;
		executor.executeScript("arguments[0].click();", ClickOnCloseEditReportPage);
		// ClickOnCloseEditReportPage.click();
		Thread.sleep(1000);
	}

	public void TakeOnActionOnReport() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		ClickOnTakeOnActionOnReport.click();
		Thread.sleep(5000);
	}

	public void SelectScheduleReport() throws InterruptedException {
		ClickOnScheduleReport.click();
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(1000);
	}

	public void DeleteReport() throws InterruptedException {
		ClickOnDeleteReport.click();
		ClickOnSubmitInSaveReportPage.click();

		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(1000);
	}

	public void AddUserForScheduleReport() throws InterruptedException {

		ClickOnAddUser.click();

	}

	public void SelectUserInScheduleReport() throws InterruptedException {

		EnterAddUsername.sendKeys("Saleem Pasha");

		ClickOnSelectUserInScheduleReport.click();
		Thread.sleep(1000);
	}

	public void SubmitButtonrInScheduleReport() throws InterruptedException {
		ClickOnSubmitButtonrInScheduleReport.click();
		Thread.sleep(1000);
	}

	public void Click_PendingDisputes() throws InterruptedException {
		System.out.println(lwebDriver.getTitle());
		Set<String> s = lwebDriver.getWindowHandles();
		for (String i : s) {
			String t = lwebDriver.switchTo().window(i).getTitle();

		}


		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Pending_Dispute = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Pending Disputes')]")));

		Thread.sleep(4000);
		Pending_Dispute.click();

	}

	public void Fliter_CustomerNumber(String Customernumber) throws InterruptedException {

		WebElement fliter = lwebDriver.findElement(By.xpath(
				"//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Customer Number']//following::span[2]/child::a"));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Customer Number']//following::span[2]/child::a")));
		fliter.click();
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")));
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input"))
				.sendKeys(randomText);
		logger.info("Entered customer number in text box");
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']"))
				.click();
		Thread.sleep(3000);
	}

	public void Click_on_Other_work() throws InterruptedException {
		Thread.sleep(3000);

		if (Clickonother_work.isEnabled()) {
			Assert.assertTrue(true);
			Clickonother_work.click();
			logger.info("Click on other's work button");
		} else {
			logger.info("Did not Click on other's work button ");
			Assert.assertTrue(false);
		}
	}

	public void Click_on_Add_itemNote() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(2000);
		WebElement addnotebutton = lwebDriver.findElement(By.xpath("//div[contains(text(),'Open Debtor Items')]/following::button[contains(text(),'Add Item Note')]"));
		try {
			if (addnotebutton.isEnabled()) {
				Assert.assertTrue(true);
				addnotebutton.click();
				Thread.sleep(5000);
				logger.info("Click on Add item note in open Debtor items");
			} else {
				logger.info("Did not click on Add item note on collection page");
				Assert.assertTrue(false);
			}
		} catch (StaleElementReferenceException e) {
			addnotebutton = lwebDriver.findElement(By.xpath("//div[contains(text(),'Open Debtor Items')]/following::button[contains(text(),'Add Item Note')]"));

			if (addnotebutton.isEnabled()) {
				Assert.assertTrue(true);
				addnotebutton.click();
				Thread.sleep(5000);
				logger.info("Click on Add item note in open Debtor items");
			} else {
				logger.info("Did not click on Add item note on collection page");
				Assert.assertTrue(false);

			}
		}

	}


	public void Click_on_Add_itemNote1() {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds

		try {
			WebElement addbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
					"//div[contains(text(),'Open Debtor Items')]/following::button[contains(text(),'Add Item Note')]")));
			addbutton.click();
		} catch (StaleElementReferenceException e) {
			WebElement addbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(
					"//div[contains(text(),'Open Debtor Items')]/following::button[contains(text(),'Add Item Note')]")));
			addbutton.click();
		}
	}


	public void Click_on_Add_itemNote12() throws InterruptedException {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		WebElement addbutton = lwebDriver.findElement(By.xpath(
				"//div[contains(text(),'Open Debtor Items')]/following::button[contains(text(),'Add Item Note')]"));

		try {


//						WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
//						WebElement checkbox =	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Open Debtor Items')]/following::tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[1]//input)[2]")));
//						checkbox.click();
			Thread.sleep(3000);
			addbutton = lwebDriver.findElement(By.xpath(
					"//div[contains(text(),'Open Debtor Items')]/following::button[contains(text(),'Add Item Note')]"));
			addbutton.click();


		} catch (StaleElementReferenceException e) {


//						WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
//						WebElement checkbox =	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div[contains(text(),'Open Debtor Items')]/following::tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[1]//input)[2]")));
//						checkbox.click();
			Thread.sleep(3000);
			addbutton = lwebDriver.findElement(By.xpath(
					"//div[contains(text(),'Open Debtor Items')]/following::button[contains(text(),'Add Item Note')]"));
			addbutton.click();

		}

	}


	public void Add_Note_To_Selected_Debtor_Items(String Itemnote) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement text = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@name='$PpyWorkPage$pBulkNote']")));
		text.clear();
		Thread.sleep(5);
		text.sendKeys(Itemnote);
		logger.info("Added note into textarea");
		Thread.sleep(5000);

	}

	public void Add_Note_To_Selected_Debtor_Items11(String Itemnote) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//textarea[@name='$PpyWorkPage$pBulkNote']")));
		lwebDriver.findElement(By.xpath("//textarea[@name='$PpyWorkPage$pBulkNote']")).sendKeys(Itemnote);
		logger.info("Added note into textarea");
		Thread.sleep(5000);
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement R_button = wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(text(),'Notify Accounting')]/following-sibling::div//label[contains(text(),'Yes')]")));

		R_button.click();
		Thread.sleep(3000);
		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Calendar = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[contains(@name,'CalendarImg-24b5e012')]")));

		int day = 28;
		try {
			Calendar.click();
			Thread.sleep(3000);
			lwebDriver.findElement(By.xpath("//table[@id='Pega_Cal_Cont']//td[not(contains(@class, 'oom'))]/a[text()=" + day + "]")).click();

		} catch (NoSuchElementException e) {
			lwebDriver.findElement(By.xpath("//img[contains(@name,'CalendarImg-24b5e012')]")).click();

			lwebDriver.findElement(By.xpath("//table[@id='Pega_Cal_Cont']//td[not(contains(@class, 'oom'))]/a[text()=" + day + "]")).click();
			Thread.sleep(2000);

		}
		Thread.sleep(3000);

	}

	public void Add_Note_To_Selected_Debtor_Items1(String Itemnote1) throws InterruptedException {

		WebElement sendkeys = lwebDriver.findElement(By.xpath("//textarea[@name='$PpyWorkPage$pBulkNote']"));
		logger.info("Added note into textarea");
		Thread.sleep(5000);

		try {
			sendkeys.clear();
			sendkeys.sendKeys(Itemnote1);
			logger.info("Added note into textarea");
			Thread.sleep(5000);
		} catch (StaleElementReferenceException e) {

			sendkeys = lwebDriver.findElement(By.xpath("//textarea[@name='$PpyWorkPage$pBulkNote']"));
			sendkeys.clear();
			sendkeys.sendKeys(Itemnote1);
		}
		Thread.sleep(5000);
	}


	public void Click_on_submit() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		try {
			if (Click_on_Submit.isEnabled()) {
				Assert.assertTrue(true);
				Click_on_Submit.click();
				Thread.sleep(10000);
				logger.info("Click on submit button");
			} else {
				logger.info("Did not Click on submit button");
				Assert.assertTrue(false);
			}
		} catch (ElementClickInterceptedException e) {
			lwebDriver.findElement(By.xpath("//button[text()='  Submit ']")).click();
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void Click_on_submit1() throws InterruptedException {
		WebElement submit = lwebDriver.findElement(By.xpath("//button[text()='  Submit ']"));
		try {
			if (submit.isEnabled()) {
				Assert.assertTrue(true);
				submit.click();
				Thread.sleep(3000);
				logger.info("Click on submit button");
			} else {
				logger.info("Did not Click on submit button");
				Assert.assertTrue(false);
			}
		} catch (StaleElementReferenceException e) {
			submit = lwebDriver.findElement(By.xpath("//button[text()='  Submit ']"));

			if (submit.isEnabled()) {
				Assert.assertTrue(true);
				submit.click();
				Thread.sleep(3000);
				logger.info("Click on submit button");
			} else {
				logger.info("Did not Click on submit button");
				Assert.assertTrue(false);
			}
		}

	}

	public void verify_previous_Note() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[19]//td"))
					.getText();
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_GP_PT() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[20]//td"))
					.getText();
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}
	public void verify_previous_Note_HC_BR_() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[20]//td"))
					.getText();
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}
	public void verify_previous_Note_ES() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//*[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[19]/div/table/tbody/tr/td"))
					.getText();
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_IN_RD() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[@data-attribute-name='Text']//span"))
					.getText();
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_MY() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"(//td[contains(@data-attribute-name,'Text')]//tbody//td[1])[1]"))
					.getText();
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_SHS() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement text = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div")));
		String previous = text.getText();

		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[@data-attribute-name='Texto']//tbody//td"))
					.getText();
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_FBA() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[@data-attribute-name='Note']//span"))
					.getText();
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_FR() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement enter_UN = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]//td[@data-attribute-name='Note']//span")));

			Lineitemnote = enter_UN.getText();
			System.out.println(Lineitemnote);
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_CH() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement enter_UN = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]//td[@data-attribute-name='Note']//td")));

			Lineitemnote = enter_UN.getText();
			System.out.println(Lineitemnote);
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_FR2() throws InterruptedException, IOException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String Lineitemnote;
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement enter_UN = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]//td[15]//tbody//td")));

			Lineitemnote = enter_UN.getText();
			System.out.println(Lineitemnote);
		} catch (NoSuchElementException exception) {
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		Thread.sleep(5000);
		System.out.println(previous);
		System.out.println(Lineitemnote);
		logger.info("Validating the Line item  note");
		if (previous.contains(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_RC_IT() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//td[@data-attribute-name='Note']//tbody[1]//td[1])[1]"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_HC() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[21]//span")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.equals(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[@data-attribute-name='Note']//span")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_GP_UK() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[20]//td")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.equals(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[20]//td")));

			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_SEU() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[12]//span")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.equals(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[@data-attribute-name='Note']//span")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}
	public void verify_previous_Note_GP_US() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[14]//td")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.equals(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[@data-attribute-name='Note']//span")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}
	public void verify_previous_Note_HC_BR() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::table/descendant::td")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.equals(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::table[@title='Tets']/descendant::td")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}


	public void verify_previous_Note_HC2() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[28]//span/span")));
		String	lineItemNoteText =  Lineitemnote.getText();
			System.out.println(lineItemNoteText);
			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (lineItemNoteText.equals(previous)) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[28]//span")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_HC_US_Note() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[28]//span/span")));
			String	lineItemNoteText =  Lineitemnote.getText();
			System.out.println(lineItemNoteText);
			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (lineItemNoteText.equals(previous)) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[15]")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_HC22() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[12]//td")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[@data-attribute-name='Note']//td")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_HC1() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[@data-attribute-name='Note']//td")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.equals(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[16]//span[2]")));


			System.out.println(previous);
			logger.info("Validating the Line item  note");
			if (previous.contains(Lineitemnote.getText())) {
				Assert.assertTrue(true);
				logger.info("The  note was correctly displayed in the line item");
			} else {
				logger.info("The line item does not contain a Note");
				Assert.assertTrue(false);
			}

		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void verify_previous_Note_NL() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");


		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[16]//span[2]")));


		System.out.println(Lineitemnote.getText());
		String a = Lineitemnote.getText();
		String amount = a.replaceAll("[^0-9.-]", "");
		String b = a.replaceAll("[^A-Z a-z]", "");
		System.out.println(b);
		logger.info("Validating the Line item  note");
		if (b.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void verify_previous_Note_CA() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");


		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[12]")));


		System.out.println(Lineitemnote.getText());
		String a = Lineitemnote.getText();
		String amount = a.replaceAll("[^0-9.-]", "");
		String b = a.replaceAll("[^A-Z a-z]", "");
		System.out.println(b);
		logger.info("Validating the Line item  note");
		if (b.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void verify_previous_Note_GP_NL() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");


		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[1]/descendant::td[@data-attribute-name='Note']//span[2]")));


		System.out.println(Lineitemnote.getText());
		String a = Lineitemnote.getText();
		String amount = a.replaceAll("[^0-9.-]", "");
		String b = a.replaceAll("[^A-Z a-z]", "");
		System.out.println(b);
		logger.info("Validating the Line item  note");
		if (b.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}


	public void verify_previous_Note_GP_IT() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");


		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[1]/descendant::td[@data-attribute-name='Note']//td")));


		System.out.println(Lineitemnote.getText());
		String a = Lineitemnote.getText();
		String amount = a.replaceAll("[^0-9.-]", "");
		String b = a.replaceAll("[^A-Z a-z]", "");
		System.out.println(b);
		logger.info("Validating the Line item  note");
		if (b.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void verify_previous_Note_PT() throws InterruptedException {
		//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");


		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Lineitemnote = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[1]/descendant::td[@data-attribute-name='Note']//tbody//td")));


		System.out.println(Lineitemnote.getText());
		String a = Lineitemnote.getText();
		String amount = a.replaceAll("[^0-9.-]", "");
		String b = a.replaceAll("[^A-Z a-z]", "");
		System.out.println(b);
		logger.info("Validating the Line item  note");
		if (b.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}
	//BaseClass.SwitchToDefaultFrame();


	public void verify_previous_Note_US() throws InterruptedException {
		//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		String previous = lwebDriver
				.findElement(
						By.xpath("//div[text()='Last Note']/following::td[2]//div[contains(@id,'rte-default')]/div"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the previous note history");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Click on Cancel button");
		Thread.sleep(5000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[1]//td[13]//td"))
				.getText();
		System.out.println(previous);
		logger.info("Validating the Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  note was correctly displayed in the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		BaseClass.SwitchToDefaultFrame();
	}

	public void Click_Graph() throws InterruptedException {
		Thread.sleep(4000);
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Graph')]")).click();
		Thread.sleep(4000);

	}

	public void Click_Graph1() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget1Ifr");
		Thread.sleep(4000);
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Graph')]")).click();
		Thread.sleep(4000);

	}

	public void Select_Aging_table() throws Exception {
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Refresh Portfolio')]")).click();
		logger.info("Click on Refresh portfolio");
		Thread.sleep(6000);

		WebElement Ageingtabledata = lwebDriver.findElement(By.xpath(
				"//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][1]/child::td[1]"));

		Thread.sleep(5000);
		if (Ageingtabledata.isEnabled()) {
			Assert.assertTrue(true);
			try {
				Ageingtabledata.click();
				logger.info("Click on the first row in the table");
			} catch (StaleElementReferenceException e) {
				Ageingtabledata = lwebDriver.findElement(By.xpath(
						"//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][1]/child::td[1]"));
				Ageingtabledata.click();
			}
		} else {
			logger.info(" It was disabled in the first row");
			Assert.assertTrue(false);
		}

		int count = 0;
		int customercount1 = 0; // Declare the variable outside the loop
		do {
			logger.info("next button");
			String customercount = lwebDriver.findElement(By.xpath("(//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][1]/child::td[1]/following::td[@data-attribute-name='N. of invoices']//span)[1]")).getText();
			customercount1 = Integer.parseInt(customercount); // Assign value inside the loop
			logger.info("getting text for invoice count");

			WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10)); // Adjust the timeout as needed
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]")));

			List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]"));
			System.out.println(text.size());
			logger.info("getting count for below invoice line items");
			count += text.size();
			System.out.println("Total collection list count: " + count);

			List<WebElement> next;
			try {
				next = lwebDriver.findElements(By.xpath("(//a[@title='Next Page'])[1]"));
				if (!next.isEmpty()) {
					Thread.sleep(3000);
					lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
					logger.info("clicking on next button for counting");
					Thread.sleep(3000);
				} else {
					// If Next button is not found, break out of the loop
					break;
				}
			} catch (StaleElementReferenceException e) {
				// Handle stale element exception by re-locating the element
				logger.info("Stale element encountered. Retrying...");
				next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
				// Then proceed with interacting with the element as usual
			}

		} while (true);

		Thread.sleep(3000);
		System.out.println("Final total count: " + count);

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****Non invoice overdue were matched with collection lists below********");
		} else {
			logger.info("****Non invoice overdue were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}


	public void verify_Aging_second_row() throws Exception {

		Thread.sleep(5000);

		WebElement Secondrow = lwebDriver.findElement(By.xpath(
				"//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][2]/child::td[1]"));

		if (Secondrow.isEnabled()) {
			Assert.assertTrue(true);
			Secondrow.click();
			logger.info("Click on the second row in the table");
		} else {
			logger.info(" It was disabled in the second row");
			Assert.assertTrue(false);
		}

		// WebElement Ageingtabledata2 =
		// lwebDriver.findElement(By.xpath("//div[contains(text(),'Debtor Items in
		// Bucket ')]//following::tr[@class='oddRow cellCont' or @class='evenRow
		// cellCont']"));

		// System.out.println(Ageingtabledata2.getSize());
		int count = 0;
		List<WebElement> next;
		int customercount1 = 0; // Declare the variable outside the loop
		do {
			next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
			logger.info("next button");

			String customercount = lwebDriver.findElement(By.xpath("//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][2]/child::td[2]//span")).getText();
			customercount1 = Integer.parseInt(customercount); // Assign value inside the loop
			logger.info("Retrieving the invoice count for items numbered 1 through 30.");

			WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10)); // Adjust the timeout as needed
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]")));

			List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]"));
			System.out.println(text.size());
			logger.info("Retrieving the invoice count for items numbered 1 through 30.");
			count += text.size();
			System.out.println("Total invoice count for items numbered 1 through 30: " + count);

			try {
				if (!next.isEmpty()) {
					Thread.sleep(3000);
					lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
					//	next.get(0).click();
					logger.info("clicking on next button for counting");
					Thread.sleep(3000);
				}
			} catch (StaleElementReferenceException e) {
				// Handle stale element exception by re-locating the element
				logger.info("Stale element encountered. Retrying...");
				next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
				// Then proceed with interacting with the element as usual
			}
		} while (!next.isEmpty());

		Thread.sleep(3000);
		System.out.println("Final total count: " + count);

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****invoice count for items numbered 1 through 30 were matched with collection lists below********");
		} else {
			logger.info("****invoice count for items numbered 1 through 30 were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}

	public void verify_Aging_Thrid_row() throws Exception {

		Thread.sleep(5000);

		WebElement Secondrow = lwebDriver.findElement(By.xpath(
				"//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][3]/child::td[1]"));

		if (Secondrow.isEnabled()) {
			Assert.assertTrue(true);
			Secondrow.click();

			logger.info("Click on the Third row in the table");
		} else {
			logger.info(" It was disabled in the Third row");
			Assert.assertTrue(false);
		}

		// WebElement Ageingtabledata2 =
		// lwebDriver.findElement(By.xpath("//div[contains(text(),'Debtor Items in
		// Bucket ')]//following::tr[@class='oddRow cellCont' or @class='evenRow
		// cellCont']"));

		// System.out.println(Ageingtabledata2.getSize());
		int count = 0;
		List<WebElement> next;
		int customercount1 = 0; // Declare the variable outside the loop
		do {
			next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
			logger.info("next button");

			String customercount = lwebDriver.findElement(By.xpath("//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][3]//td[2]//span")).getText();
			customercount1 = Integer.parseInt(customercount); // Assign value inside the loop
			logger.info("Retrieving the invoice count for items numbered 31 through 60.");

			WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10)); // Adjust the timeout as needed
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]")));

			List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]"));
			System.out.println(text.size());
			logger.info("Retrieving the invoice count for items numbered 31 through 60.");
			count += text.size();
			System.out.println("Total invoice count for items numbered 31 through 60.: " + count);

			try {
				if (!next.isEmpty()) {
					Thread.sleep(3000);
					lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
					//	next.get(0).click();
					logger.info("clicking on next button for counting");
					Thread.sleep(3000);
				}
			} catch (StaleElementReferenceException e) {
				// Handle stale element exception by re-locating the element
				logger.info("Stale element encountered. Retrying...");
				next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
				// Then proceed with interacting with the element as usual
			}
		} while (!next.isEmpty());

		Thread.sleep(3000);
		System.out.println("Final total count: " + count);

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****invoice count for items numbered 31 through 60 were matched with collection lists below********");
		} else {
			logger.info("****invoice count for items numbered 31 through 60 were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Fliter_Action(String Invoice) throws InterruptedException {

		Thread.sleep(2000);
		BaseClass.WaitforVisiblityofElement(Fliter_for_customer);
		Fliter_for_customer.click();
		Thread.sleep(2000);
		logger.info("clicked on cust Fliter in table");
		BaseClass.WaitforVisiblityofElement(Serach_inputbox);
		Serach_inputbox.sendKeys(randomText);
		logger.info("Entered customer number in text box");
		WaitforElementToBeClickable(Apply_button_p2p);
		try {
			Apply_button_p2p.click();
		} catch (StaleElementReferenceException e) {
			WebElement apply = lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']"));
			apply.click();
		}
		logger.info("Click on Apply");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		// Scroll to the bottom of the page
		js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		Thread.sleep(2000);
	}

	public void verify_Aging_4_row() throws Exception {

		Thread.sleep(5000);

		WebElement Secondrow = lwebDriver.findElement(By.xpath(
				"//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][4]/child::td[1]"));

		if (Secondrow.isEnabled()) {
			Assert.assertTrue(true);
			Secondrow.click();

			logger.info("Click on the 4th row in the table");
		} else {
			logger.info(" It was disabled in the 4th row");
			Assert.assertTrue(false);
		}

		// WebElement Ageingtabledata2 =
		// lwebDriver.findElement(By.xpath("//div[contains(text(),'Debtor Items in
		// Bucket ')]//following::tr[@class='oddRow cellCont' or @class='evenRow
		// cellCont']"));

		// System.out.println(Ageingtabledata2.getSize());
		int count = 0;
		List<WebElement> next;
		int customercount1 = 0; // Declare the variable outside the loop
		do {
			next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
			logger.info("next button");

			String customercount = lwebDriver.findElement(By.xpath("//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][4]//td[2]//span")).getText();
			customercount1 = Integer.parseInt(customercount); // Assign value inside the loop
			logger.info("Retrieving the invoice count for items numbered 61 through 90.");

			WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10)); // Adjust the timeout as needed
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]")));

			List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]"));
			System.out.println(text.size());
			logger.info("Retrieving the invoice count for items numbered 61 through 90");
			count += text.size();
			System.out.println("Total invoice count for items numbered 61 through 90: " + count);

			try {
				if (!next.isEmpty()) {

					lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
					//	next.get(0).click();
					logger.info("clicking on next button for counting");
					Thread.sleep(3000);
				}
			} catch (StaleElementReferenceException e) {
				// Handle stale element exception by re-locating the element
				logger.info("Stale element encountered. Retrying...");
				next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
				// Then proceed with interacting with the element as usual
			}
		} while (!next.isEmpty());

		Thread.sleep(3000);
		System.out.println("Final total count: " + count);

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****invoice count for items numbered 61 through 90 were matched with collection lists below********");
		} else {
			logger.info("****invoice count for items numbered 61 through 90 were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}

	public void verify_Aging_5_row() throws Exception {

		Thread.sleep(5000);

		WebElement Secondrow = lwebDriver.findElement(By.xpath(
				"//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][5]/child::td[1]"));

		if (Secondrow.isEnabled()) {
			Assert.assertTrue(true);
			Secondrow.click();

			logger.info("Click on the 5th in the table");
		} else {
			logger.info(" It was disabled in the 5th");
			Assert.assertTrue(false);
		}

		// WebElement Ageingtabledata2 =
		// lwebDriver.findElement(By.xpath("//div[contains(text(),'Debtor Items in
		// Bucket ')]//following::tr[@class='oddRow cellCont' or @class='evenRow
		// cellCont']"));

		// System.out.println(Ageingtabledata2.getSize());
		int count = 0;
		List<WebElement> next;
		int customercount1 = 0; // Declare the variable outside the loop
		do {
			next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
			logger.info("next button");

			String customercount = lwebDriver.findElement(By.xpath("//h1[contains(text(),'My Portfolio')]//following::tr[contains(@id,'$PD_UserAgingData_p')][5]//td[2]//span")).getText();
			customercount1 = Integer.parseInt(customercount); // Assign value inside the loop
			logger.info("Retrieving the invoice count for items numbered 91 through 120.");

			WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10)); // Adjust the timeout as needed
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]")));

			List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_AgeingBucketDebtorItemListByLabel_pa')]"));
			System.out.println(text.size());
			logger.info("Retrieving the invoice count for items numbered 91 through 120");
			count += text.size();
			System.out.println("Total invoice count for items numbered 91 through 120: " + count);

			try {
				if (!next.isEmpty()) {
					Thread.sleep(3000);
					lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
					//	next.get(0).click();
					logger.info("clicking on next button for counting");
					Thread.sleep(3000);
				}
			} catch (StaleElementReferenceException e) {
				// Handle stale element exception by re-locating the element
				logger.info("Stale element encountered. Retrying...");
				next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
				// Then proceed with interacting with the element as usual
			}
		} while (!next.isEmpty());

		Thread.sleep(3000);
		System.out.println("Final total count: " + count);

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****invoice count for items numbered 91 through 120 were matched with collection lists below********");
		} else {
			logger.info("****invoice count for items numbered 91 through 120 were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_open_Dispute() throws InterruptedException {
		if (Click_on_OpenDispute.isEnabled()) {
			Assert.assertTrue(true);
			Click_on_OpenDispute.click();
			Thread.sleep(5000);
			logger.info("Click on Open Disputes in BU portal");
		} else {
			logger.info("Did not click on open Dispute page");
			Assert.assertTrue(false);
		}
		BaseClass.SwitchToDefaultFrame();
	}

	public void Click_Close_Dispute() throws InterruptedException {
		// BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");

		// BaseClass.WaitforElementToBeClickable(By.xpath("(//span[text()='Closed
		// Disputes']"));
		if (Click_on_closeDispute.isEnabled()) {
			Assert.assertTrue(true);
			Click_on_closeDispute.click();
			Thread.sleep(5000);
			logger.info("Click on closed Disputes in BU portal");
		} else {
			logger.info("Did not click on closed Dispute page");
			Assert.assertTrue(false);
		}
	}

	public void Click_on_work_queues() {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement managework = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Manage Work queues')]")));
		managework.click();
	}

	public void Select_Business_workbaskets() throws InterruptedException {
		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement ClickOnBusiness_Workbaskets1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Business Workbaskets')]")));


		if (ClickOnBusiness_Workbaskets1.isDisplayed() && ClickOnBusiness_Workbaskets1.isEnabled()) {
			Assert.assertTrue(true);
			ClickOnBusiness_Workbaskets.click();

			logger.info("Selected for Business_Workbaskets");
		} else {
			logger.info(" Business_Workbaskets was not visible on work queue page");
			Assert.assertTrue(false);
		}

	}

	public void Select_Business_workbaskets1() throws InterruptedException {
		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
		Thread.sleep(5000);

		WebElement basket = lwebDriver.findElement(By.xpath("//span[contains(text(),'Business Workbaskets')]"));
		try {
			basket.click();
		} catch (StaleElementReferenceException e) {
			basket = lwebDriver.findElement(By.xpath("//span[contains(text(),'Business Workbaskets')]"));
			basket.click();
		}

	}

	public void Select_New_workbaskets() throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement ClickOnBusiness_Basket = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'New Business Basket')]")));

		if (ClickOnBusiness_Basket.isDisplayed() && ClickOnBusiness_Basket.isEnabled()) {
			Assert.assertTrue(true);
			ClickOnBusiness_Basket.click();
			Thread.sleep(4000);
			logger.info("Clicked  on  New_workbaskets");
		} else {
			logger.info(" New_workbaskets was not visible on work queue page");
			Assert.assertTrue(false);
		}

	}

	public void Select_Name_of_Basket_and_CC_Work_group(String BasketName, String Select_CompanyCode, String Select_Work_group) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));


		logger.info("Selected report] name");
		String names[] = {"Basket_INDdgaaw1", "Basket_WI1fd3wq2", "Basket_PKswe4qud", "Basket_NZ1m5nri5", "Basket_AUS6gfyo6", "Basket_ENGd1d8snrnb", "Basket_NZed23mpgf","Basket_Z5A1fdudew","Basket_Ssf1Aadqhds"};
		String radomnames = names[new Random().nextInt(names.length)];
		WebElement workbasket_name = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Add Business Basket')]//following::label[contains(text(),'Name')]//following-sibling::div//input")));

		workbasket_name.clear();
		workbasket_name.sendKeys(radomnames);
		logger.info("Selected name of Basket");
		Thread.sleep(5000);
		value = workbasket_name.getAttribute("value");
		WebElement CC = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'CompanyCode')]//following-sibling::div/select"));
		Select drop = new Select(CC);
		drop.selectByVisibleText(Select_CompanyCode);
		logger.info("Selected CC from dropdown");

		WebElement Work_group = lwebDriver
				.findElement(By.xpath("//label[contains(text(),'Work group')]//following-sibling::div/select"));
		// System.out.println(Work_group.getText());
		Select _Work_group = new Select(Work_group);
		_Work_group.selectByVisibleText(Select_Work_group);
		Thread.sleep(3000);
		logger.info("Selected work group from dropdown");
	}

	public void Verify_Name_of_Organization_and_Unit_Division() throws InterruptedException {

		List<WebElement> Organization = lwebDriver
				.findElements(By.xpath("//span[contains(text(),'Organization')]//following-sibling::div/span"));
		if (!Organization.isEmpty()) {
			Assert.assertTrue(true);
			logger.info("Organization name was visible on BasketPage");
		} else {
			logger.info("Organization name was not visible on BasketPage");
			Assert.assertTrue(false);
		}
		List<WebElement> Unit = lwebDriver
				.findElements(By.xpath("//span[contains(text(),'Unit')]//following-sibling::div/span"));
		if (!Unit.isEmpty()) {
			Assert.assertTrue(true);
			logger.info("unit name was visible on BasketPage");
		} else {
			logger.info("unit name was not visible on BasketPage");
			Assert.assertTrue(false);
		}
		List<WebElement> Division = lwebDriver
				.findElements(By.xpath("//span[contains(text(),'Unit')]//following-sibling::div/span"));
		if (!Division.isEmpty()) {
			Assert.assertTrue(true);
			logger.info("Division name was visible on BasketPage");
		} else {
			logger.info("Division name was not visible on BasketPage");
			Assert.assertTrue(false);
		}
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Click on submit");
		Thread.sleep(2000);
	}

	public void Fliter_the_workBasket(String BasketName) throws InterruptedException {

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(80));
		WebElement enter_UN = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//i[@name='BusinessOperators_pyDisplayHarness_3']")));

		enter_UN.click();
		logger.info("Click on refresh Icon on page");
		Thread.sleep(3000);
		WebElement enter_UN2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Work Queue']//following::span[2]/child::a")));

		enter_UN2.click();
		Thread.sleep(5000);

		WebElement enter_UN3 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")));
		enter_UN3.sendKeys(value);
		;
		Thread.sleep(3000);
		logger.info("Entered BasketName in text box");
		lwebDriver
				.findElement(By.xpath(
						"//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']"))
				.click();
		logger.info("Click on Apply");

		Thread.sleep(2000);
//		for (int i = 1; i <= 2; i++) {
//			logger.info("sorting for Task Due Date");
//			lwebDriver.findElement(By.xpath(
//					"(//table[@id='gridLayoutTable']//descendant::th[@id='a1']/descendant::*[text()='Work queue'])[1]"))
//					.click();
//			Thread.sleep(3000);
//
//		}

	}

	public void Click_on_WorkQueues_from_profile_HC(String Bname) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement refresh = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),'Refresh')])[1]")));
		refresh.click();
		Thread.sleep(6000);

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement queue = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Assignments']/following::div[contains(@id,'headerlabel')]//*[text()='Work queue']")));

		queue.click();
		Thread.sleep(3000);
		String xpathExpression = "(//div[contains(text(),'Work queue')]//following::tr)[1]//table[1]//tr//tr//td";
		List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpathExpression)));
		String textToVerify = value;
		System.out.println(value);
		boolean textFound = false;
		for (WebElement element : elements) {
			if (element.getText().contains(textToVerify)) {
				textFound = true;
				break;
			}
		}

		// Check if the text was found and print the result
		if (textFound) {
			System.out.println("Pass");
			Assert.assertTrue(true);
		} else {
			System.out.println("Fail");
			Assert.assertTrue(false);
		}
	}

	public void verify_the_crossIcon() throws InterruptedException {

		WebElement Icon = lwebDriver
				.findElement(By.xpath("//i[@class='cursordefault  icons fa fa-times fa-2x greyText']"));
		if (Icon.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info("(X) icon was visible on workbasket");

		} else {
			logger.info("(X) icon was not visible on workbasket");
			Assert.assertTrue(false);

		}
	}

	public void Select_Email_click_on_Group_FBS(String Email) throws InterruptedException {

		BaseClass.SwitchtoFrameUsingFrameIdorName(InsideItem);

		lwebDriver.findElement(By.xpath("//label[contains(text(),'Group')]/following::label[contains(text(),'Work basket to Assign')]/following-sibling::div//input[@type='text']")).sendKeys(value);
		logger.info("Entered the person Work Basket ID");
		Thread.sleep(5000);

		lwebDriver.findElement(By.xpath("//label[contains(text(),'Group')]/following::label[contains(text(),'Work basket to Assign')]/following-sibling::div//input[@type='text']")).sendKeys(Keys.ARROW_DOWN);

		Thread.sleep(3000);

		lwebDriver.findElement(By.xpath("//label[contains(text(),'Group')]/following::label[contains(text(),'Work basket to Assign')]/following-sibling::div//input[@type='text']")).sendKeys(Keys.ENTER);
//WebElement addreceipt = lwebDriver.findElement(By.xpath("//button[text()='Add recipient']"));
		BaseClass.SwitchToDefaultFrame();
	}

	public void verify_the_totalAssignments() throws InterruptedException {

		WebElement totalAssignments = lwebDriver.findElement(By.xpath(
				"//table[@id='gridLayoutTable']//descendant::*[text()='Division']//following::tr[1]/td[6]//span"));
		if (!totalAssignments.equals("0")) {
			Assert.assertTrue(true);
			logger.info("Total Assignments was visible in work Basket");

		} else {
			logger.info("Total Assignments was not visible in work Basket");
			Assert.assertTrue(false);

		}
	}

	public void verify_the_crossIcon1() throws InterruptedException {
		Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		WebElement Icon = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//i[contains(@class,'cursordefault  icons fa fa-check fa-2x greyText')]")));
		if (Icon.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info("(Availability) icon was visible on workbasket");

		} else {
			logger.info("Availability) icon was not visible on workbasket");
			Assert.assertTrue(false);

		}
	}

	public void Click_on_ChangeAvailability() throws InterruptedException {

		WebElement ChangeAvailability = lwebDriver.findElement(By
				.xpath(" //table[@id='gridLayoutTable']//descendant::*[text()='Division']//following::tr[1]/td[8]//span"));
		ChangeAvailability.click();
		logger.info("Click on Change Availability");
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Click on Submit for Change workbasket");
		Thread.sleep(5000);

	}

	public void Click_on_ChangeAvailability_US() throws InterruptedException {

		WebElement ChangeAvailability = lwebDriver.findElement(By
				.xpath("//table[@id='gridLayoutTable']//descendant::*[text()='Division']//following::tr[1]/td[9]//span"));
		ChangeAvailability.click();
		logger.info("Click on Change Availability");
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Click on Submit for Change workbasket");
		Thread.sleep(5000);

	}

	public void Click_on_ClickOnfirstrow(String Email) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Click = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(" //table[@id='gridLayoutTable']//descendant::*[text()='Division']//following::tr[1]/td[2]//span")));
		Click.click();
		logger.info("Click on workbasket");
		Thread.sleep(3000);
		WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[text()='Add to Workbasket']/ancestor::*[3]//input)[1]")));

		input.sendKeys(Email);
		logger.info("Entered ZID");
		Thread.sleep(10000);
		input.sendKeys(Keys.ARROW_DOWN);
		input.sendKeys(Keys.ENTER);
		WebElement Add_to_Workbasket = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Add to Workbasket']")));
		Add_to_Workbasket.click();
		logger.info("Click on add to workbasket");
		Thread.sleep(3000);
		WebElement checkboxnotify = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//h2[text()='Users']/following::tr[4]//input)[2]")));


		checkboxnotify.click();
		if (checkboxnotify.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Notify checkbox has been selected");
		} else if (!checkboxnotify.isSelected()) {
			checkboxnotify.click();
			logger.info("Notify checkbox Was selected");
		}
		WebElement checkboxmanagework = lwebDriver
				.findElement(By.xpath("(//h2[text()='Users']/following::tr[4]//input)[4]"));
		if (checkboxmanagework.isSelected()) {
			Assert.assertTrue(true);
			logger.info("manage work checkbox has been selected");
		} else if (!checkboxmanagework.isSelected()) {
			checkboxmanagework.click();
			logger.info("manage work checkbox Was selected");
		}
	}

	public void Add_Additional_Email(String AdditionalEmail) throws InterruptedException {
		lwebDriver.findElement(By.xpath(
						"//label[text()='Additional email addresses for notification']//following-sibling::div//a[contains(text(),'Add item')]"))
				.click();
		Thread.sleep(4000);
		WebElement Emailbox = lwebDriver.findElement(By.xpath(
				"//div[contains(text(),'Email')]//following::input[contains(@name,'$PpyWorkPage$ppyHolder$pContactEmailList$l1$ppyValue')]"));

		Emailbox.sendKeys(AdditionalEmail);
		logger.info("Added the aditional email id into inputbox");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement Managework = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[contains(@name,'$PpyWorkPage$ppyHolder$pContacts$l1$pManageWork') and @value='true']")));

		if (!Managework.isSelected()) {
			Managework.click();
			logger.info("Managework click on checkbox");
		} else {

			logger.info("already selected for Managework checkbox");
		}

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Click on Submit button");
		Thread.sleep(5000);

	}

	public void Verify_the_BU_Name(String BasketName) {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName(InsideItem);
		BaseClass.WaitforVisiblityofElement(Select_BUname);
		if (Select_BUname.getText().equals(value)) {
			Assert.assertTrue(true);
			logger.info("Work Basket name was visible on Dispute page");
		} else {
			logger.info("Work Basket name was not visible on Dispute page");
			Assert.assertTrue(true);
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_the_BU_Name_1(String BasketName) {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
		BaseClass.WaitforVisiblityofElement(Select_BUname);
		if (Select_BUname.getText().equals(BasketName)) {
			Assert.assertTrue(true);
			logger.info("Work Basket name was visible on Dispute page");
		} else {
			logger.info("Work Basket name was not visible on Dispute page");
			Assert.assertTrue(true);
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_the_BU_Name2(String BasketName) {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget2Ifr");
		BaseClass.WaitforVisiblityofElement(Select_BUname);
		if (Select_BUname.getText().equals(BasketName)) {
			Assert.assertTrue(true);
			logger.info("Work Basket name was visible on Dispute page");
		} else {
			logger.info("Work Basket name was not visible on Dispute page");
			Assert.assertTrue(true);
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_the_BU_Name_GP_UK(String BasketName) {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget2Ifr");
		BaseClass.WaitforVisiblityofElement(Select_BUname);
		if (Select_BUname.getText().equals(BasketName)) {
			Assert.assertTrue(true);
			logger.info("Work Basket name was visible on Dispute page");
		} else {
			logger.info("Work Basket name was not visible on Dispute page");
			Assert.assertTrue(true);
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_the_BU_Name_HC(String BasketName) {
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
		BaseClass.WaitforVisiblityofElement(Select_BUname);
		if (Select_BUname.getText().equals(BasketName)) {
			Assert.assertTrue(true);
			logger.info("Work Basket name was visible on Dispute page");
		} else {
			logger.info("Work Basket name was not visible on Dispute page");
			Assert.assertTrue(false);
		}

		BaseClass.SwitchToDefaultFrame();
	}

	public void Add_Account_Note(String Note) throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		Thread.sleep(5000);
		try {

			lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
		} catch (NoSuchFrameException e) {
			System.out.println("frame");
		}
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement text = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//title[contains(text(),'This is a rich text editor control.')]/ancestor::html/body/p")));

//	JavascriptExecutor js=(JavascriptExecutor)driver;
//	js.executeScript("arguments[0].value='Test1'", text);

		text.sendKeys(Note);
		logger.info("Entered text");
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);
	}

	public void Add_Account_Note_HC(String Note) throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement text = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//textarea[@name='$PpyWorkPage$ppyNote']")));

//	JavascriptExecutor js=(JavascriptExecutor)driver;
//	js.executeScript("arguments[0].value='Test1'", text);

		text.sendKeys(Note);
		logger.info("Entered text");
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);
	}

	public void Click_on_Update(String UpdateNote) throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Update')]")).click();
		logger.info("Click on Update button");

		Thread.sleep(3000);
		logger.info("Validating the Account Note Text on customer page");

		String Accounttext = lwebDriver
				.findElement(By.xpath("(//h2[contains(text(),'Account Notes')]//following::div//p)[1]")).getText();
		if (Accounttext.equals(UpdateNote)) {
			Assert.assertTrue(true);
			logger.info("Account Note has been updated");
		} else {
			logger.info("Did not update Account note on customer page");
			Assert.assertTrue(false);
		}
	}

	public void Click_on_Update_HC(String UpdateNote) throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Update')]")).click();
		logger.info("Click on Update button");

		Thread.sleep(3000);
		logger.info("Validating the Account Note Text on customer page");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement enter_UN = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[contains(text(),'Account Notes')]/following::div[30]")));
		String Accounttext = enter_UN.getText();
		System.out.println(Accounttext);
		if (Accounttext.equals(UpdateNote)) {
			Assert.assertTrue(true);
			logger.info("Account Note has been updated");
		} else {
			logger.info("Did not update Account note on customer page");
			Assert.assertTrue(false);
		}
	}

	public void Click_on_Update_HC1(String UpdateNote) throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Update')]")).click();
		logger.info("Click on Update button");

		Thread.sleep(3000);
		logger.info("Validating the Account Note Text on customer page");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement enter_UN = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[contains(text(),'Account Notes')]/following::div[30]")));
		String Accounttext = enter_UN.getText();
		System.out.println(Accounttext);
		if (Accounttext.contains(UpdateNote)) {
			Assert.assertTrue(true);
			logger.info("Account Note has been updated");
		} else {
			logger.info("Did not update Account note on customer page");
			Assert.assertTrue(false);
		}
	}

	public void Click_on_Show_History(String History) throws InterruptedException {

		Click_showHistory.click();
		System.out.println(Click_showHistory.getText());
		Thread.sleep(2000);
		if (History_Note.getText().equals(History)) {
			Assert.assertTrue(true);
			logger.info("The note has been correctly added to the Note to Note History");
		} else {
			logger.info("The note was not visible under Note History");
			Assert.assertTrue(false);
		}
//	WebElement  text=lwebDriver.findElement(By.xpath("//div[text()='Note'])[1]/following::td[2]//p"));
		// System.out.println(text.getText());
	}

	public void Click_on_Show_History_HC_US(String History) throws InterruptedException {

		Click_showHistory.click();
		System.out.println(History_Note1.getText());
		Thread.sleep(2000);
		if (History_Note1.getText().contains(History)) {
			Assert.assertTrue(true);
			logger.info("The note has been correctly added to the Note to Note History");
		} else {
			logger.info("The note was not visible under Note History");
			Assert.assertTrue(false);
		}
//	WebElement  text=lwebDriver.findElement(By.xpath("//div[text()='Note'])[1]/following::td[2]//p"));
		// System.out.println(text.getText());
	}

	public void Click_on_Show_History_HC(String History) throws InterruptedException {

		Click_showHistory.click();
		System.out.println(Click_showHistory.getText());
		Thread.sleep(2000);
		if (History_Note.getText().contains(History)) {
			Assert.assertTrue(true);
			logger.info("The note has been correctly added to the Note to Note History");
		} else {
			logger.info("The note was not visible under Note History");
			Assert.assertTrue(false);
		}
//	WebElement  text=lwebDriver.findElement(By.xpath("//div[text()='Note'])[1]/following::td[2]//p"));
		// System.out.println(text.getText());
	}

	public void Verify_Cash_collector_Name_and_Timestamp() throws InterruptedException {

		WebElement CashCollector = lwebDriver
				.findElement(By.xpath("(//div[text()='Note'])[1]/following::div[text()='Cash Collector']"));
		if (CashCollector.isDisplayed() && CashCollector.isEnabled()) {
			Assert.assertTrue(true);
			logger.info("A 'cash collector' was enabled in the column header");
		} else {
			logger.info("A 'cash collector' was not enabled in the column header");
			Assert.assertTrue(false);
		}
		WebElement Time = lwebDriver.findElement(By.xpath("(//div[text()='Note'])[1]/following::div[text()='Time']"));

		if (Time.isDisplayed() && Time.isEnabled()) {
			Assert.assertTrue(true);
			logger.info("'Time' was enabled in the column header");
		} else {
			logger.info("'Time' was not enabled in the column header");
			Assert.assertTrue(false);
		}

		Thread.sleep(2000);
		if (!Verifycollector.getText().isEmpty()) {
			Assert.assertTrue(true);
			logger.info("Cash Collector name was Displayed in Note History");
		} else {
			logger.info("Cash Collector name was not Displayed in Note History");
			Assert.assertTrue(false);
		}
		WebElement Time_Date = lwebDriver.findElement(By.xpath("(//div[text()='Note'])[1]/following::td[3]//span"));

		if (!Time_Date.getText().isEmpty()) {
			Assert.assertTrue(true);
			logger.info("Time&Date  was Displayed in Note History");
		} else {
			logger.info("Time was not Displayed in Note History");
			Assert.assertTrue(false);
		}
		BaseClass.SwitchToDefaultFrame();
	}

	public void Zoom_adjustment_for_page() {

	}

	public void Click_ON_mycustomer() throws Exception {
		Thread.sleep(3000);
		Robot robot = new Robot();
		for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		Thread.sleep(2000);
		// BaseClass.WaitforVisiblityofElement(ClickOnMycustomer);
//	JavascriptExecutor jse = (JavascriptExecutor)driver;
//	jse.executeScript("document.body.style.zoom='80%'");
		Thread.sleep(2000);
		if (ClickOnMycustomer.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" My customer list was visible on Homepage");
			Thread.sleep(2000);
			ClickOnMycustomer.click();

			logger.info("Click on my customer list");
		}
		try {

		} catch (ElementClickInterceptedException e) {

		}

		Thread.sleep(4000);
		// int count=0;
		logger.info("Check the my customer count with below collections");
		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		String customercount = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'My Customers')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(customercount);
		System.out.println(customercount1);
		try {

			while (!next.isEmpty()) {

				List<WebElement> text = lwebDriver
						.findElements(By.xpath("//tr[contains(@id,'$PD_CCCollectionCustomersListByUser_pa')]"));
				System.out.println(text.size());
				count = count + text.size();
				System.out.println("Total collection list count" + count);
				lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
				Thread.sleep(2000);

			}
			System.out.println(count);
		} catch (NoSuchElementException e) {
			Assert.assertTrue(true);

		}

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****Customer lists were matched with collection lists below********");
		} else {
			logger.info("****Customer lists were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}


// Make sure to import required classes/interfaces.

	public void clickOnMyCustomer1() throws Exception {
		Thread.sleep(3000);

		// Simulate zoom out using Robot class
		Robot robot = new Robot();
		for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		Thread.sleep(2000);

		try {
			// Wait for the element to be clickable
			WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10));
			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(ClickOnMycustomer));

			// Scroll into view
			((JavascriptExecutor) lwebDriver).executeScript("arguments[0].scrollIntoView(true);", element);

			// Click on the element
			element.click();

			logger.info("Clicked on my customer list");
		} catch (ElementNotInteractableException e) {
			logger.error("ElementNotInteractableException occurred: " + e.getMessage());
			e.printStackTrace();
			return; // Exiting the method since we couldn't click on the element
		} catch (Exception ex) {
			logger.error("Exception occurred: " + ex.getMessage());
			ex.printStackTrace();
			return; // Exiting the method due to exception
		}

		Thread.sleep(4000);
		logger.info("Check the my customer count with below collections");
		int count = 0;
		List<WebElement> next;
		int customercount1 = 0; // Declare the variable outside the loop
		do {
			next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

			String customercount = lwebDriver.findElement(By.xpath("//span[contains(text(),'My Customers')]/following::div[1]/span")).getText();
			customercount1 = Integer.parseInt(customercount); // Assign value inside the loop

			List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_CCCollectionCustomersListByUser_pa')]"));
			System.out.println(text.size());
			count += text.size();
			System.out.println("Total collection list count: " + count);
			if (!next.isEmpty()) {
				next.get(0).click();
				Thread.sleep(3000);
			}
			Thread.sleep(5000);
			System.out.println("Final count");

		} while (!next.isEmpty());
		Thread.sleep(3000);
		System.out.println("Final total count: " + count);
		Thread.sleep(5000);

			if (customercount1 == count) {
				logger.info("Customer lists were matched with collection lists.");
				Assert.assertTrue(true);
			} else {
				logger.info("Customer lists were not matched with collection lists.");
				Assert.assertTrue(false);
			}

		}

	public void Click_ON_Mycustomer_CA() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnMycustomer);
		Thread.sleep(3000);
		Robot robot = new Robot();
		for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}

		Thread.sleep(3000);


		Thread.sleep(2000);
		// BaseClass.WaitforVisiblityofElement(ClickOnMycustomer);
//	JavascriptExecutor jse = (JavascriptExecutor)driver;
//	jse.executeScript("document.body.style.zoom='80%'");
		Thread.sleep(2000);
		if (ClickOnMycustomer.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" My customer list was visible on Homepage");
			Thread.sleep(2000);
			ClickOnMycustomer.click();

			logger.info("Click on my customer list");
		}
		try {

		} catch (ElementClickInterceptedException e) {

		}
		// int count=0;
		logger.info("Check the my Task count with below Task");
		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		String Tasklist = lwebDriver.findElement(By.xpath("//span[contains(text(),'My Customers')]/following::div[1]/span"))
				.getText();

		int customercount1 = Integer.parseInt(Tasklist);

		try {


			List<WebElement> text = lwebDriver
					.findElements(By.xpath("//tr[contains(@id,'$PD_CCCollectionCustomersListByUser_pa')]"));
			// System.out.println(text.size());

			count = count + text.size();
			// System.out.println(count);

			Thread.sleep(2000);


			// System.out.println(count);
		} catch (NoSuchElementException e) {
			Assert.assertTrue(true);
		}

		System.out.println("Total  MyTask count=" + count);
		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****My customer  list were matched with Tasks below********");
		} else {
			logger.info("****My customer list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}


// Make sure to import required classes/interfaces.

	public void Click_ON_MYTask() throws Exception {
		Thread.sleep(3000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Task_List = wait.until(ExpectedConditions.elementToBeClickable(ClickOnTask));

		Thread.sleep(2000);
		if (Task_List.isDisplayed()) {
			logger.info(" My Task list was visible on Homepage");
			Task_List.click();
			logger.info("Click on my Task list");
		} else {
			Assert.fail("My Task list was not visible on Homepage");
		}

		Thread.sleep(4000);
		logger.info("Check the My Task count with below collections");
		int count = 0;

		do {
			List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_CCWorkListByUser_pa')]"));
			count += text.size();

			// Check if the "Next Page" element is present
			List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

			if (!next.isEmpty()) {
				try {
					next.get(0).click();
					Thread.sleep(2000);
				} catch (ElementClickInterceptedException e) {
					// Handle the exception here or add proper logging if needed.
					// You can also wait for the blocking element to disappear using WebDriverWait if necessary.
				}
			} else {
				// If "Next Page" link is not available, break out of the loop
				break;
			}
		} while (true);

		System.out.println("Total My Task count: " + count);

		String taskCountText = lwebDriver.findElement(By.xpath("//span[contains(text(),'My Task')]/following::div[1]/span")).getText();
		int expectedTaskCount = Integer.parseInt(taskCountText);

		if (expectedTaskCount == count) {
			logger.info("*****My Task list matches with Tasks below********");
		} else {
			logger.info("****My Task list does not match with Tasks lists*****");
			Assert.fail("My Task list count does not match with actual count");
		}
	}


	public void Click_ON_mycustomer_SI() throws Exception {
		Thread.sleep(5000);
		Robot robot = new Robot();
		for (int i = 0; i < 3; i++) {
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_SUBTRACT);
			robot.keyRelease(KeyEvent.VK_CONTROL);
		}
		Thread.sleep(5000);
		// BaseClass.WaitforVisiblityofElement(ClickOnMycustomer);
//	JavascriptExecutor jse = (JavascriptExecutor)driver;
//	jse.executeScript("document.body.style.zoom='80%'");
		Thread.sleep(5000);
		if (ClickOnMycustomer.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" My customer list was visible on Homepage");
			Thread.sleep(5000);
			ClickOnMycustomer.click();

			logger.info("Click on my customer list");
		}
		try {

		} catch (ElementClickInterceptedException e) {

		}

		Thread.sleep(4000);
		// int count=0;
		logger.info("Check the my customer count with below collections");
		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		String customercount = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'My Customers')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(customercount);
		System.out.println(customercount1);
		try {


			List<WebElement> text = lwebDriver
					.findElements(By.xpath("//tr[contains(@id,'$PD_CCCollectionCustomersListByUser_pa')]"));
			System.out.println(text.size());
			count = count + text.size();
			System.out.println("Total collection list count" + count);
			lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
			Thread.sleep(2000);


			System.out.println(count);
		} catch (NoSuchElementException e) {
			Assert.assertTrue(true);

		}

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****Customer lists were matched with collection lists below********");
		} else {
			logger.info("****Customer lists were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}


// Make sure to import required classes/interfaces.

	public void Click_ON_Overdue() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnOverDue);
		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(60));
		WebElement ClickOnOverDue1 =   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Overdue Tasks')]")));

		if (ClickOnOverDue1.isDisplayed()) {
			logger.info(" Overdue Task list was visible on Homepage");
			ClickOnOverDue1.click();
			logger.info("Click on Overdue Task");
		} else {
			Assert.fail("Overdue Task list was not visible on Homepage");
		}

		Thread.sleep(4000);
		logger.info("Check the Overdue Task count with below collections");
		int count = 0;
		List<WebElement> next;

		do {
			List<WebElement> text =   wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PD_OverDueTasksByCashCollectorByUser_pa')]")));

			count += text.size();

			// Check if the "Next Page" element is present
			next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

			if (!next.isEmpty()) {
				try {
					next.get(0).click();
					Thread.sleep(2000);
				} catch (ElementClickInterceptedException e) {
					// Handle the exception here or add proper logging if needed.
					// You can also wait for the blocking element to disappear using WebDriverWait if necessary.
				}
			}
		} while (!next.isEmpty());

		// If there's no "Next Page" link, count the elements on the last page
		if (count == 0) {
			List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_OverDueTasksByCashCollectorByUser_pa')]"));
			count += text.size();
		}

		System.out.println("Total Overdue Task count: " + count);

		String overdueCountText = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'Overdue Tasks')]/following::div[1]/span")).getText();
		int expectedOverdueCount = Integer.parseInt(overdueCountText);

		if (expectedOverdueCount == count) {
			logger.info("*****Overdue Task list matches with Tasks below********");
		} else {
			logger.info("****Overdue Task list does not match with Tasks lists*****");
			Assert.fail("Overdue Task list count does not match with actual count");
		}
	}


	public void Click_ON_Overdue1() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnOverDue);
		Thread.sleep(3000);
		if (ClickOnOverDue.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" Overdue Task list was visible on Homepage");
			ClickOnOverDue.click();
			logger.info("Click on Overdue Task");
		}

		Thread.sleep(3000);
		// int count=0;
		logger.info("Check the Unassigned emails count with below Task");

		String unassignemaillist = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'Overdue Tasks')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(unassignemaillist);

		List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_OverDueTasksByCashCollectorByUser_pa')]"));
		int emailcount = text.size();

		if (customercount1 == emailcount) {
			Assert.assertTrue(true);
			logger.info("*****unassignemail list were matched with Tasks below********");
		} else {
			logger.info("****unassignemail list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}


	public void Click_ON_Ovredue_DE() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnTask);
		try {
			Thread.sleep(3000);
			if (ClickOnOverDue.isDisplayed()) {
				Assert.assertTrue(true);
				logger.info(" Overdue Task list was visible on Homepage");
				ClickOnOverDue.click();
				logger.info("Click on Overdue Task");
			}

			Thread.sleep(3000);
			// int count=0;
			logger.info("Check the OverDue count with below Task");
			int count = 0;
			List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

			String Tasklist = lwebDriver.findElement(By.xpath("//span[contains(text(),'Overdue Tasks')]/following::div[1]/span"))
					.getText();

			int customercount1 = Integer.parseInt(Tasklist);

			try {

				while (!next.isEmpty()) {
					Thread.sleep(2000);
					List<WebElement> text = lwebDriver
							.findElements(By.xpath("//tr[contains(@id,'$PD_OverDueTasksByCashCollectorByUser_pa')]"));
					// System.out.println(text.size());

					count = count + text.size();
					// System.out.println(count);
					lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
					Thread.sleep(2000);

				}
				// System.out.println(count);
			} catch (NoSuchElementException e) {
				Assert.assertTrue(true);
			}

			System.out.println("Total  MyTask count=" + count);
			if (customercount1 == count) {
				Assert.assertTrue(true);
				logger.info("*****OverDue list were matched with Tasks below********");
			} else {
				logger.info("****OverDue list not matched with Tasks lists*****");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement ClickOnTask1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Overdue Tasks')]")));
			if (ClickOnTask1.isDisplayed()) {
				Assert.assertTrue(true);
				logger.info(" My Task list was visible on Homepage");
				ClickOnTask1.click();
				logger.info("Click on My Task");
			}

			Thread.sleep(3000);
			// int count=0;
			logger.info("Check the ClickOnpromisedtoPays count with below Task");

			String P2P = lwebDriver
					.findElement(By.xpath("//span[contains(text(),'Overdue Tasks')]/following::div[1]/span")).getText();

			int customercount1 = Integer.parseInt(P2P);

			List<WebElement> text = lwebDriver
					.findElements(By.xpath("//tr[contains(@id,'$PD_OverDueTasksByCashCollectorByUser_pa')]"));
			int p2pcount = text.size();

			if (customercount1 == p2pcount) {
				Assert.assertTrue(true);
				logger.info("*****MyTask list were matched with Tasks below********");
			} else {
				logger.info("****MyTask list not matched with Tasks lists*****");
				Assert.assertTrue(false);
			}


		}

	}

	public void Select_Advanced_Item_filters(String Line_Property, String Value) throws Exception {
		logger.info("Click on additeam option under Advanced Item filters ");
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Advanced_Itema = wait.until(ExpectedConditions.elementToBeClickable(Advanced_Item));
			Advanced_Itema.click();
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[1]")));
			WebElement textbox = lwebDriver.findElement(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[1]"));
			textbox.sendKeys(Line_Property);
			logger.info("Selected for Line Item Property ");
			Thread.sleep(3000);
			textbox.sendKeys(Keys.ARROW_DOWN);

			textbox.sendKeys(Keys.ENTER);
			Thread.sleep(3000);
			WebElement
					Values = lwebDriver.findElement(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[4]"));
			Values.sendKeys(randomText);
			logger.info("Select value for customer number ");
			lwebDriver.findElement(By.xpath("//button[text()='  Submit ']")).click();
			Thread.sleep(4000);
			logger.info("Click on sumit button");
			//BaseClass.SwitchToDefaultFrame();


		} catch (TimeoutException e) {
			BaseClass.SwitchToDefaultFrame();
			BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Advanced_Itema = wait.until(ExpectedConditions.elementToBeClickable(Advanced_Item));
			Advanced_Itema.click();
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
			wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[1]")));
			WebElement textbox = lwebDriver.findElement(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[1]"));
			textbox.sendKeys(Line_Property);
			logger.info("Selected for Line Item Property ");
			Thread.sleep(3000);
			textbox.sendKeys(Keys.ARROW_DOWN);

			textbox.sendKeys(Keys.ENTER);
			Thread.sleep(3000);
			WebElement
					Values = lwebDriver.findElement(By.xpath("//h2[text()='Advanced Item filters']//following::div[2]/descendant::div[text()='Line Item Property']//following::input[4]"));
			Values.sendKeys(Value);
			logger.info("Select value for customer number ");
			lwebDriver.findElement(By.xpath("//button[text()='  Submit ']")).click();
			Thread.sleep(4000);
			logger.info("Click on sumit button");
			//BaseClass.SwitchToDefaultFrame();

		}
	}

	public void Click_ON_Overdue_SI() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnOverDue);

		if (ClickOnOverDue.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" Overdue Task list was visible on Homepage");
			ClickOnOverDue.click();
			logger.info("Click on Overdue Task");
		}

		Thread.sleep(4000);
		// int count=0;
		logger.info("Check the my customer count with below collections");
		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		String Overduecount = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'Overdue Tasks')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(Overduecount);

		try {


			List<WebElement> text = lwebDriver
					.findElements(By.xpath("//tr[contains(@id,'$PD_OverDueTasksByCashCollectorByUser_pa')]"));
			// System.out.println(text.size());
			count = count + text.size();


			// System.out.println(count);
		} catch (NoSuchElementException e) {
			Assert.assertTrue(true);
		}

		System.out.println("Total Overdue Task count" + count);
		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****Overdue Task list were matched with Tasks below********");
		} else {
			logger.info("****Overdue Task list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_ON_overdue_1() throws Exception {
		Thread.sleep(3000);

		// BaseClass.WaitforVisiblityofElement(ClickOnMycustomer);
//	JavascriptExecutor jse = (JavascriptExecutor)driver;
//	jse.executeScript("document.body.style.zoom='80%'");
		Thread.sleep(2000);
		if (ClickOnOverDue.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" Overdue Task list was visible on Homepage");
			ClickOnOverDue.click();
			logger.info("Click on Overdue Task");
		}
		try {

		} catch (ElementClickInterceptedException e) {

		}

		Thread.sleep(4000);
		// int count=0;
		logger.info("Check the my customer count with below collections");
		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		String customercount = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'Overdue Tasks')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(customercount);
		System.out.println(customercount1);
		try {

			while (!next.isEmpty()) {

				List<WebElement> text = lwebDriver
						.findElements(By.xpath("//tr[contains(@id,'$PD_CCWorkListByUser_pa')]"));
				System.out.println(text.size());
				count = count + text.size();
				System.out.println("Total collection list count" + count);
				lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
				Thread.sleep(2000);

			}
			System.out.println(count);
		} catch (NoSuchElementException e) {
			Assert.assertTrue(true);

		}

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****Customer lists were matched with collection lists below********");
		} else {
			logger.info("****Customer lists were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}


	public void Click_ON_MyTasks() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnTask);
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement Task_List = wait.until(ExpectedConditions.elementToBeClickable(ClickOnTask));
			if (Task_List.isDisplayed()) {
				Assert.assertTrue(true);
				logger.info("My Task list was visible on Homepage");
				Task_List.click();
				logger.info("Click on My Task");
			}
		} catch (StaleElementReferenceException e) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			WebElement Task_List = wait.until(ExpectedConditions.elementToBeClickable(ClickOnTask));
			if (Task_List.isDisplayed()) {
				Assert.assertTrue(true);
				logger.info("My Task list was visible on Homepage");
				Task_List.click();
				logger.info("Click on My Task");
			}
		} catch (AssertionError e) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			WebElement ClickOnTask1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'My Tasks')]")));
			if (ClickOnTask1.isDisplayed()) {
				Assert.assertTrue(true);
				logger.info("My Task list was visible on Homepage");
				ClickOnTask1.click();
				logger.info("Click on My Task");
			}
		}

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'My Task')]/following::div[1]/span")));
		String Tasklist = lwebDriver.findElement(By.xpath("//span[contains(text(),'My Task')]/following::div[1]/span")).getText();
		int customercount1 = Integer.parseInt(Tasklist);

		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		while (!next.isEmpty()) {
			try {
				List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_CCWorkListByUser_pa')]"));
				//    count += text.size();
				System.out.println(text.size());
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
				wait.until(ExpectedConditions.stalenessOf(text.get(0)));
				next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
				count += text.size();
				Thread.sleep(2000);

			} catch (StaleElementReferenceException ex) {
				next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));
			}
		}

		System.out.println("Total MyTask count = " + count);
		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("MyTask list matched with Tasks");
		} else {
			logger.info("MyTask list did not match with Tasks");
			Assert.assertTrue(false);
		}
	}


	public void Click_ON_MyTasks_SI() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnTask);
		Thread.sleep(3000);
		if (ClickOnTask.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" My Task list was visible on Homepage");
			ClickOnTask.click();
			logger.info("Click on My Task");
		}

		Thread.sleep(3000);
		// int count=0;
		logger.info("Check the my Task count with below Task");
		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		String Tasklist = lwebDriver.findElement(By.xpath("//span[contains(text(),'My Task')]/following::div[1]/span"))
				.getText();

		int customercount1 = Integer.parseInt(Tasklist);

		try {


			List<WebElement> text = lwebDriver
					.findElements(By.xpath("//tr[contains(@id,'$PD_CCWorkListByUser_pa')]"));
			// System.out.println(text.size());

			count = count + text.size();
			// System.out.println(count);

			Thread.sleep(2000);


			// System.out.println(count);
		} catch (NoSuchElementException e) {
			Assert.assertTrue(true);
		}

		System.out.println("Total  MyTask count=" + count);
		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****MyTask list were matched with Tasks below********");
		} else {
			logger.info("****MyTask list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}
	public void Click_on_Dispute_up_up_GP_MX(String couNo) throws InterruptedException, IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement refresh = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),'Refresh')])[1]")));
			refresh.click();
			Thread.sleep(3000);
		} catch (StaleElementReferenceException e) {

		}
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement DT = wait.until(ExpectedConditions.elementToBeClickable(Dispute_Task2));
		DT.click();
		Thread.sleep(3000);
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Filter = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Cust. No.']//following	::span[2]/child::a")));
		Filter.click();

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement textbox = wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")));


		textbox.sendKeys(couNo);
		logger.info("Entered customer number in text box");
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")).click();
		logger.info("Click on Apply");

	}
	public void Click_ON_mytask() throws Exception {
		Thread.sleep(3000);

		// BaseClass.WaitforVisiblityofElement(ClickOnMycustomer);
//	JavascriptExecutor jse = (JavascriptExecutor)driver;
//	jse.executeScript("document.body.style.zoom='80%'");
		BaseClass.WaitforVisiblityofElement(ClickOnTask);
		Thread.sleep(3000);
		if (ClickOnTask.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" My Task list was visible on Homepage");
			ClickOnTask.click();
			logger.info("Click on My Task");
		}
		try {

		} catch (ElementClickInterceptedException e) {

		}

		Thread.sleep(4000);
		// int count=0;
		logger.info("Check the my customer count with below collections");
		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		String customercount = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'My Task')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(customercount);
		System.out.println(customercount1);
		try {

			while (!next.isEmpty()) {

				List<WebElement> text = lwebDriver
						.findElements(By.xpath("//tr[contains(@id,'$PD_CCWorkListByUser_pa')]"));
				System.out.println(text.size());
				count = count + text.size();
				System.out.println("Total collection list count" + count);
				lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
				Thread.sleep(2000);

			}
			System.out.println(count);
		} catch (NoSuchElementException e) {
			Assert.assertTrue(true);

		}

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****Customer lists were matched with collection lists below********");
		} else {
			logger.info("****Customer lists were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_ON_Unassignemails() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnunassignemail);
		Thread.sleep(3000);
		if (ClickOnunassignemail.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" 'Unassigned emails' list was visible on Homepage");
			ClickOnunassignemail.click();
			logger.info("Click on 'Unassigned emails'");
		}

		Thread.sleep(3000);
		// int count=0;
		logger.info("Check the Unassigned emails count with below Task");

		String unassignemaillist = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'Unassigned emails')]/following::div[1]/span")).getText();
		System.out.println(unassignemaillist);
		int customercount1 = Integer.parseInt(unassignemaillist);

		List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_IncomingEmailsList')]"));
		int emailcount = text.size();
    System.out.println(emailcount);
		if (customercount1 == emailcount) {
			Assert.assertTrue(true);
			logger.info("*****unassignemail list were matched with Tasks below********");
		} else {
			logger.info("****unassignemail list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_ON_Overdue11() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnOverDue);

		if (ClickOnOverDue.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" Overdue Task list was visible on Homepage");
			ClickOnOverDue.click();
			logger.info("Click on Overdue Task");
		}

		Thread.sleep(3000);
		// int count=0;
		logger.info("Check the Unassigned emails count with below Task");

		String unassignemaillist = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'Overdue Tasks')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(unassignemaillist);

		List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_OverDueTasksByCashCollectorByUser_pa')]"));
		int emailcount = text.size();

		if (customercount1 == emailcount) {
			Assert.assertTrue(true);
			logger.info("*****unassignemail list were matched with Tasks below********");
		} else {
			logger.info("****unassignemail list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_ON_Mytaskss() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnTask);
		Thread.sleep(3000);
		if (ClickOnTask.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" My Task list was visible on Homepage");
			ClickOnTask.click();
			logger.info("Click on My Task");
		}


		Thread.sleep(3000);
		// int count=0;
		logger.info("Check the Unassigned emails count with below Task");

		String unassignemaillist = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'My Task')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(unassignemaillist);

		List<WebElement> text = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_CCWorkListByUser_pa')]"));
		int emailcount = text.size();

		if (customercount1 == emailcount) {
			Assert.assertTrue(true);
			logger.info("*****unassignemail list were matched with Tasks below********");
		} else {
			logger.info("****unassignemail list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_ON_Unassigned() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnunassignemail);
		Thread.sleep(3000);
		try {
			if (ClickOnunassignemail.isDisplayed()) {
				Assert.assertTrue(true);
				logger.info(" 'Unassigned emails' list was visible on Homepage");
				ClickOnunassignemail.click();
				logger.info("Click on 'Unassigned emails'");
			}

			Thread.sleep(3000);
			// int count=0;
			logger.info("Check the my Task count with below Task");
			int count = 0;
			List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

			String Tasklist = lwebDriver.findElement(By.xpath("//span[contains(text(),'Unassigned emails')]/following::div[1]/span"))
					.getText();

			int customercount1 = Integer.parseInt(Tasklist);

			try {

				while (!next.isEmpty()) {
					Thread.sleep(2000);
					List<WebElement> text = lwebDriver
							.findElements(By.xpath("//tr[contains(@id,'$PD_IncomingEmailsList')]"));
					// System.out.println(text.size());

					count = count + text.size();
					// System.out.println(count);
					lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
					Thread.sleep(2000);

				}
				// System.out.println(count);
			} catch (NoSuchElementException e) {
				Assert.assertTrue(true);
			}

			System.out.println("Total  MyTask count=" + count);
			if (customercount1 == count) {
				Assert.assertTrue(true);
				logger.info("*****unassigned list were matched with Tasks below********");
			} else {
				logger.info("****unassigned list not matched with Tasks lists*****");
				Assert.assertTrue(false);
			}
		} catch (AssertionError e) {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement ClickOnTask1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Unassigned emails')]")));
			if (ClickOnTask1.isDisplayed()) {
				Assert.assertTrue(true);
				logger.info(" My Task list was visible on Homepage");
				ClickOnTask1.click();
				logger.info("Click on My Task");
			}

			Thread.sleep(3000);
			// int count=0;
			logger.info("Check the ClickOnpromisedtoPays count with below Task");

			String P2P = lwebDriver
					.findElement(By.xpath("//span[contains(text(),'Unassigned emails')]/following::div[1]/span")).getText();

			int customercount1 = Integer.parseInt(P2P);

			List<WebElement> text = lwebDriver
					.findElements(By.xpath("//tr[contains(@id,'$PD_IncomingEmailsList')]"));
			int p2pcount = text.size();

			if (customercount1 == p2pcount) {
				Assert.assertTrue(true);
				logger.info("*****MyTask list were matched with Tasks below********");
			} else {
				logger.info("****MyTask list not matched with Tasks lists*****");
				Assert.assertTrue(false);
			}


		}
	}


	public void Click_ON_Promised_to_Pay() throws Exception {
		BaseClass.WaitforVisiblityofElement(ClickOnpromisedtoPay);
		Thread.sleep(3000);
		if (ClickOnpromisedtoPay.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" 'ClickOnpromised to pay' list was visible on Homepage");
			Thread.sleep(5000);
			ClickOnpromisedtoPay.click();
			logger.info("Click on 'ClickOnpromised to pay'");
		}

		Thread.sleep(3000);
		// int count=0;
		logger.info("Check the ClickOnpromisedtoPays count with below Task");

		String P2P = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'Promised to Pay')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(P2P);

		List<WebElement> text = lwebDriver
				.findElements(By.xpath("//tr[contains(@id,'$PD_PromisedToPayByCashCollectorByUser_pa')]"));
		int p2pcount = text.size();

		if (customercount1 == p2pcount) {
			Assert.assertTrue(true);
			logger.info("*****Promised to pay list were matched with Tasks below********");
		} else {
			logger.info("****Promised to pay list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_ON_My_open_Disputes() throws Exception {
		BaseClass.WaitforVisiblityofElement(My_open_Disputes);
		Thread.sleep(3000);
		if (My_open_Disputes.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" 'My_open_Disputes' list was visible on Homepage");
			Thread.sleep(5000);
			My_open_Disputes.click();
			logger.info("Click on 'My_open_Disputes'");
		}

		Thread.sleep(3000);
		// int count=0;
		logger.info("Check the My_open_Disputes count with below Task");

		String P2P = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'My Open Disputes')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(P2P);

		List<WebElement> text = lwebDriver
				.findElements(By.xpath("//tr[contains(@id,'$PD_OpenDisputesByCashCollectorByUser_pa')]"));
		int p2pcount = text.size();

		if (customercount1 == p2pcount) {
			Assert.assertTrue(true);
			logger.info("*****Open Dispute list were matched with Tasks below********");
		} else {
			logger.info("****Open Dispute list not matched with Tasks lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_ON_mycustomer1() throws Exception {


		// BaseClass.WaitforVisiblityofElement(ClickOnMycustomer);
//	JavascriptExecutor jse = (JavascriptExecutor)driver;
//	jse.executeScript("document.body.style.zoom='80%'");
		if (My_open_Disputes.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info(" 'My_open_Disputes' list was visible on Homepage");
			Thread.sleep(5000);
			My_open_Disputes.click();
			logger.info("Click on 'My_open_Disputes'");
		}
		try {

		} catch (ElementClickInterceptedException e) {

		}

		Thread.sleep(4000);
		// int count=0;
		logger.info("Check the my customer count with below collections");
		int count = 0;
		List<WebElement> next = lwebDriver.findElements(By.xpath("//a[@title='Next Page']"));

		String customercount = lwebDriver
				.findElement(By.xpath("//span[contains(text(),'My Open Disputes')]/following::div[1]/span")).getText();

		int customercount1 = Integer.parseInt(customercount);
		System.out.println(customercount1);
		try {

			while (!next.isEmpty()) {

				List<WebElement> text = lwebDriver
						.findElements(By.xpath("//tr[contains(@id,'$PD_OpenDisputesByCashCollectorByUser_pa')]"));
				System.out.println(text.size());
				count = count + text.size();
				System.out.println("Total collection list count" + count);
				lwebDriver.findElement(By.xpath("//a[@title='Next Page']")).click();
				Thread.sleep(2000);

			}
			System.out.println(count);
		} catch (NoSuchElementException e) {
			Assert.assertTrue(true);

		}

		if (customercount1 == count) {
			Assert.assertTrue(true);
			logger.info("*****Customer lists were matched with collection lists below********");
		} else {
			logger.info("****Customer lists were not matched with collection lists*****");
			Assert.assertTrue(false);
		}
	}

	public void Click_On_Bulkactions() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Select_Bulkactions1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Bulk actions')]")));

		if (Select_Bulkactions1.isDisplayed() && Select_Bulkactions1.isEnabled()) {
			Assert.assertTrue(true);
			Thread.sleep(3000);
			Select_Bulkactions1.click();
			logger.info("Clicked on Bulkactions from profile");

		} else {
			logger.info("Did not click on Bulkactions due to option was not displayed");
			Assert.assertTrue(false);
		}
	}

	public void select_for_type_of_bulk_action() throws InterruptedException {
		BaseClass.SwitchToDefaultFrame();

		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(50)); // Adjust timeout as needed
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.tagName("iframe")));
		Thread.sleep(3000);
		WebElement Bulkcheckbox = lwebDriver
				.findElement(By.xpath("//div[contains(text(),'Bulk')]/following::label[contains(text(),'Process')]"));
		Bulkcheckbox.click();
		Thread.sleep(3000);
		if (Bulkcheckbox.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info("Selected process option on Bulk actions page");

		} else {
			logger.info("Did not select any option for Bulk on page");
			Assert.assertTrue(false);
		}
	}

	public void Verify_assign_to_operatorname() throws InterruptedException {
		Thread.sleep(3000);
//		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
//	WebElement ID =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[text()='ID'])[1]")));
//	ID.click();

		List<WebElement> Cashcollectorname = lwebDriver.findElements(By.xpath(
				"//label[text()='Process Cases']//following::td[4]//input[contains(@name,'$PpyBulkProcessingPage$ppyConditionList$l2$ppyT')]"));
		if (Cashcollectorname.isEmpty()) {
			logger.info("Assigned to Operator was not populated with name");
			Assert.assertTrue(false);

		} else {
			Assert.assertTrue(true);
			logger.info("Assigned to Operator was populated with name");

		}
		WebElement add_filter = lwebDriver.findElement(By.xpath("//a[contains(text(),'+ Add Filter')]"));
		if (!add_filter.isDisplayed()) {
			Assert.assertTrue(false);
			logger.info("add filter was not visible on page");
		}
	}

	public void Select_lineitem_for_transfor() {
		WebElement Lineitem = lwebDriver
				.findElement(By.xpath("(//tr[contains(@id,'$PpyBulkProcessReport$ppxResults$l1')][1]/td//input)[2]"));
		Lineitem.click();
		if (Lineitem.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Lineitem  have been selected for tarnsfor to other users");
		} else {
			logger.info("Lineitem was not  selected for tarnsfor to other users");
			Assert.assertTrue(false);
		}
	}

	public String CaseID() {
		String caseID = lwebDriver
				.findElement(By.xpath("//tr[contains(@id,'$PpyBulkProcessReport$ppxResults$l1')][1]/td[3]//a"))
				.getText();
		System.out.println(caseID);

		return caseID;
	}

	public void Select_Transfer_from_SelectActions() throws InterruptedException {
		Thread.sleep(3000);

		WebElement SelectActions = lwebDriver.findElement(By.xpath("//button[contains(text(),'Select Action')]"));
		SelectActions.click();
		Thread.sleep(3000);
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Transfer_assignment =wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Transfer assignment')]")));

		Transfer_assignment.click();
		Thread.sleep(3000);

	}

	public void Transfer_assignment(String User_Name) throws InterruptedException {
		Thread.sleep(3000);
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement	Select_user =		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'        Transfer assignment       ')]/following::label[text()='Transfer to']/following::div[1]/select")));

		Select select = new Select(Select_user);
		select.selectByVisibleText("User");
		logger.info("Selected user from drop down");
		Thread.sleep(3000);

		WebElement Username = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//*[contains(text(),'s name')]/following-sibling::div/input)[1]")));
		Username.sendKeys(User_Name);
		logger.info("Entered other's user name in input box");
		Thread.sleep(5000);
		Username.sendKeys(Keys.ARROW_DOWN);
		Username.sendKeys(Keys.ENTER);

		WebElement Bulk_process_Checkbox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//span[contains(text(),'        Transfer assignment       ')]/following::input[contains(@name,'$PTempWorkPage$ppyProcessInBackground')])[2]")));


		Bulk_process_Checkbox.click();
		if (Bulk_process_Checkbox.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Bulk process in background check box have selected on Transfer assignment pop up window");
		} else {
			logger.info("Bulk process in background check box was not selected on Transfer assignment pop up window");
		}

		lwebDriver.findElement(By.xpath("//*[text()='OK']")).click();
		logger.info("Click on ok");
		Thread.sleep(3000);
	}

	public void verify_the_lineitem_for_Transferred() throws InterruptedException {
		String CaseID;
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement fliter = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='ID']//following	::span[2]/child::a")));
		fliter.click();
		CaseID = this.CaseID();
		logger.info("Clicked on case ID fliter");
		Thread.sleep(4000);
		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input"))
				.sendKeys(this.CaseID());
		logger.info("Entered Case ID in text box");
		Thread.sleep(3000);
		lwebDriver
				.findElement(By.xpath(
						"//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']"))
				.click();
		logger.info("Clicked on Apply button");
		Thread.sleep(3000);
		WebElement Transferred_column = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PpyBulkProcessReport$ppxResults$l1')]//td[@class='dataLabelRead']//label")));
		System.out.println(Transferred_column.getText());
		if (Transferred_column.getText().equals("Transferred")) {
			Assert.assertTrue(true);
			logger.info("****The email has been successfully transferred to another user***");
		} else {
			logger.info("****Since the line item does not contain 'Transferred', the email has not been transferred to another user.***");
			Assert.assertTrue(false);
		}
		logger.info("****I'm about to delve into another user's profile to confirm whether the task has undergone the transformation we discussed.***");
		try {
			BaseClass.SwitchToDefaultFrame();
			Thread.sleep(3000);
			WebElement Icon = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@id='TABANCHOR']//span[@class='textIn']")));
			JavascriptExecutor j = (JavascriptExecutor) driver;
			j.executeScript("arguments[0].click();", Icon);
			lwebDriver.findElement(By.xpath("//td[text()='Close All']")).click();
			logger.info("clicked on clear task");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		} catch (StaleElementReferenceException e) {

		}
		WebElement Refresh = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@name,'MyWorkList_pyDisplayHarness_2')]")));
		Refresh.click();
		Thread.sleep(5000);
		After_Task_Count = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'My Tasks')]/following::div[1]/span")));
		System.out.println(After_Task_Count.getText());

		if (!After_Task_Count.equals(Task_count)) {
			Assert.assertTrue(true);
			logger.info("The task has been successfully removed from my work page's task list.");
		} else {
			logger.info("Unfortunately, the task still persists on my work page's task list");
			Assert.assertTrue(false);
		}
		Thread.sleep(5000);
		SwitchToDefaultFrame();

//		Thread.sleep(5000);
//		WebElement ClickOnBurgerMenu1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@id='appview-nav-toggle-one']")));
//
//		ClickOnBurgerMenu1.click();
//
//		if (Clickonother_work.isEnabled()) {
//			Assert.assertTrue(true);
//			Clickonother_work.click();
//			logger.info("Click on other's work button");
//		} else {
//			logger.info("Did not Click on other's work button ");
//			Assert.assertTrue(false);
//		}
//		BaseClass.SwitchToDefaultFrame();
//		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
//		WebElement SelectedUser = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//label[contains(text(),'Selected User')]/following-sibling::div/input)[1]")));
//		Thread.sleep(5000);
//		SelectedUser.sendKeys("Z004KWYD");
//		logger.info("Search with GID in serach box");
//		Thread.sleep(5000);
//		SelectedUser.sendKeys(Keys.ARROW_DOWN);
//		SelectedUser.sendKeys(Keys.ENTER);
//		Thread.sleep(5000);
//		String tittle = lwebDriver.getTitle();
//		System.out.println(tittle);
//		String Actual = lwebDriver.getTitle();
//		String Expected = "CaseWorkerByUser";
//		Assert.assertEquals(Actual, Expected);
//		logger.info("We are on another user work page");
//		ChromeOptions options = new ChromeOptions();
//		options.addArguments("--window-size=1366,768");
//		BaseClass.SwitchToDefaultFrame();
//		SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");
//		WebElement My_Task = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@data-context,'D_WorkListTileInformation_pa')]//span[text()='My Tasks']")));
//		My_Task.click();
//		Thread.sleep(5000);
//		logger.info("Clicked on my task");

//		WebElement Icon =	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@node_name='CashCollectorTileWorkListByUser' and @readonly='true']//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Case ID']//following::span[2]/child::a")));
//		Icon.click();
//
//		logger.info("click on fliter");
//		Thread.sleep(6000);
//		WebElement cus_name =	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")));
//		cus_name.sendKeys("12345");
//		logger.info("Entered customer name in text box");
//////		String Customer_number = cus_name.getAttribute("value");
//		System.out.println("CaseID");
//		Thread.sleep(3000);
//		lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")).click();
//		logger.info("click on apply");

		// Adjust the timeout as needed
//		try {
//			// Sleep for 5 seconds (Thread.sleep(5000))
//			Thread.sleep(5000);
//
//			// Set up page load timeout to 60 seconds
//			driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
//
//			// XPath expression to locate the desired element
//			String xpathExpression = "//div[@node_name='CashCollectorTileWorkListByUser' and @readonly='true']//input[contains(@name,'D_CCWorkListByUserPpxResult')]/following::table[1]//tr[contains(@id,'$PD_CCWorkListByUser_pa')]//td[3]//span";
//
//			// Set up WebDriverWait with a timeout of 60 seconds
//			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(60));
//
//			// Use WebDriverWait to wait for the presence of the element
//			WebElement visibleElement = wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpathExpression)));
//
//			// Now that the element is present, you can interact with it
//			logger.info("Element " + visibleElement.getText());
//
//			// Find all elements that match the XPath expression
//			List<WebElement> elements = driver.findElements(By.xpath(xpathExpression));
//			System.out.println("Element size: " + elements.size());
//
//			// Iterate over the elements
//			boolean dataFound = false;
//			for (int i = 0; i < elements.size(); i++) {
//				WebElement currentElement = elements.get(i);
//				try {
//					// Get the text of the current element
//					String elementText = currentElement.getText();
//					System.out.println("Element " + (i + 1) + ": " + elementText);
//
//					// Check if the desired data is present
//					if (!elementText.isEmpty() && elementText.contains(CaseID)) {
//						dataFound = true;
//						logger.info("The task has seamlessly transformed to the designated person, and you can spot the task ID prominently displayed in your task list on the other user's page.");
//
//						// Capture a screenshot when the element is found
//						((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE).renameTo(new File("screenshot_element_found.png"));
//
//						// Exit the loop when the data is found
//						break;
//					}
//				} catch (org.openqa.selenium.StaleElementReferenceException e) {
//					// Handle StaleElementReferenceException by re-finding elements
//					elements = driver.findElements(By.xpath(xpathExpression));
//				}
//			}
//
//			// Assert outside the loop
//			assert dataFound : "Test failed! Element with text 'B-97470' not found.";
//
//			// Log a success message
//			System.out.println("Test passed!");
//		} catch (Exception e) {
//			// Handle exceptions as needed
//			e.printStackTrace();
//		}
	}
// If you reach here and haven't found the CaseID, fail the assertion.



	public void verify_the_lineitem_for_Transferred_or_not() {
		String Lineitem = lwebDriver
				.findElement(By.xpath("(//tr[contains(@id,'$PpyBulkProcessRepor')][1]/td[8]//label")).getText();
		if (Lineitem.equals("Transferred")) {
			Assert.assertTrue(true);
			logger.info("******lineiteam has been Transferred to user******");
		} else {
			logger.info("*****lineiteam was not Transferred to user*****");
			Assert.assertTrue(false);
		}
		BaseClass.SwitchToDefaultFrame();
	}
	public void Click_On_Availability() {

		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(80));
		WebElement Select_Availability1 =   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Availability')]")));
try {
		if (Select_Availability1.isDisplayed() && Select_Availability1.isEnabled()) {
			Assert.assertTrue(true);
			Thread.sleep(3000);
			Select_Availability1.click();
			logger.info("Clicked on Availability from profile");

		} else {
			logger.info("Did not click on Availability due to option was not displayed");
			Assert.assertTrue(false);
		}
}catch(StaleElementReferenceException e) {

	WebElement Select_Availability2 =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Availability')]")));

	if (Select_Availability2.isDisplayed() && Select_Availability2.isEnabled()) {
		Assert.assertTrue(true);
		Select_Availability2.click();
		logger.info("Clicked on Availability from profile");

	}
	else {
		logger.info("Did not click on Availability due to option was not displayed");
		Assert.assertTrue(false);
	}

} catch (InterruptedException e) {
	throw new RuntimeException(e);
}
	}
	public void Select_Send_automatic_reply() {
		//lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
WebElement 		Send_automatic_reply = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[contains(text(),'Send automatic reply')]/following::input[1]")));


		if(!Send_automatic_reply.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Send automatic reply was selected");
			Send_automatic_reply.click();

		}
		else {
			logger.info("Send automatic reply has been selected");

		}
	}
		public void Select_From_Date() throws InterruptedException {
			
			WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
   	WebElement calendar =	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h2[contains(text(),'My Unavailability')]/following::div[text()='From']/following::tr[1]/td[1]//img")));
			
   	calendar.click();
			Thread.sleep(3000);

			lwebDriver.findElement(By.xpath("//*[(text()='Today')]")).click();
			Thread.sleep(3000);
	}
		public void Select_To_Date() throws InterruptedException {
			lwebDriver.findElement(By.xpath("//h2[contains(text(),'My Unavailability')]/following::div[text()='From']/following::tr[1]/td[2]//img")).click();
			Thread.sleep(3000);
			lwebDriver.findElement(By.xpath("//*[(text()='Today')]")).click();
			logger.info("Selected To date for Unavailability");
			Thread.sleep(3000);
	}

		public void Set_Default_to_assignee(String ZID) throws InterruptedException {
			Thread.sleep(3000);
			lwebDriver.findElement(By.xpath("//label[contains(text(),'Default to assignee')]/following-sibling::div/input")).clear();
			lwebDriver.findElement(By.xpath("//label[contains(text(),'Default to assignee')]/following-sibling::div/input")).sendKeys(ZID);
			Thread.sleep(3000);
			logger.info("Entred Default to assignee ZID");
			lwebDriver.findElement(By.xpath("//button[contains(text(),'  Submit ')]")).click();
			Thread.sleep(6000);
			logger.info("Click on Submit");

			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
//			WebElement mycustomer_list = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='My Customers']")));
//			logger.info("Click on mycustomer list");
//			mycustomer_list.click();
			Thread.sleep(5000);

			// Adjust the timeout as needed

// Step 1: Identify all matching elements with an explicit wait
//			List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//td[@data-attribute-name='Cust. No.']//span")));
//
//// Step 2: Generate a random index
//			Random rand = new Random();
//			int randomIndex = rand.nextInt(elements.size());

// Step 3: Get the randomly selected element with an explicit wait
//			WebElement randomElement = wait.until(ExpectedConditions.elementToBeClickable(elements.get(randomIndex)));
//
//// Step 4: Get the text from the randomly selected element
//			randomText = randomElement.getText();

// Now 'randomText' contains the text from the randomly selected element
//			System.out.println("Randomly selected text: " + randomText);
//			BaseClass.SwitchToDefaultFrame();


			WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']")));


			try {
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
				element.click();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			} catch (StaleElementReferenceException e) {
				WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
				WebElement element1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
				element1 = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
				element1.click();
				logger.info("Clicked on serach button");
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			}
			BaseClass.SwitchToDefaultFrame();

			lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));


			wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input")));

			WebElement customer = lwebDriver
					.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
			try {

				customer.sendKeys("000");
				logger.info("Enterd cutomer number");
			} catch (StaleElementReferenceException e) {

				customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
				customer.sendKeys("0000618287");
				logger.info("Enterd cutomer number");
			}

			WebElement sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
			try {
				Thread.sleep(5000);
				sumbit.click();
				logger.info("Click on serach Icon");

			} catch (StaleElementReferenceException e) {

				sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
				sumbit.click();
				logger.info("Enterd cutomer number");
			}

			// Wait for the element to be both visible and clickable
			WebElement qaCollectionElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//tr[contains(@id,'$PD_CollectionsByCustomerSearch_pa')])[1]//td[1]")));

			// Click on the element
			qaCollectionElement.click();
			logger.info("Clicked on collection ");
			// Switch back to the default frame
			SwitchToDefaultFrame();

			BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget1Ifr");
			// Wait for the page to be fully loaded
			wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));

			WebElement checkbox = null;
			int retries = 0;

			while (retries < 3) {  // Limit the number of retries to avoid an infinite loop
				try {
					checkbox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[contains(@name,'$PD_OpenDebtorItemListByCollection_pa')])[2]")));
					checkbox.click();
					logger.info("Selected line item");
					break;  // Break out of the loop if successful
				} catch (StaleElementReferenceException e) {
					// Handle stale element exception, e.g., retry the operation
					System.err.println("StaleElementReferenceException: " + e.getMessage());
					retries++;
				} catch (TimeoutException e) {
					// Handle timeout exception
					System.err.println("TimeoutException: " + e.getMessage());
					retries++;
				}
			}

			if (checkbox == null) {
				System.err.println("Failed to click the checkbox after multiple attempts.");
			}
			BaseClass.WaitforVisiblityofElement(ClickOnEmailWithItem);
			ClickOnEmailWithItem.click();
			logger.info("Clicked on email with Item copy option");
			BaseClass.SwitchToDefaultFrame();
			Thread.sleep(3000);
			BaseClass.SwitchToDefaultFrame();
			// lwebDriver.switchTo().frame(lwebDriver.findElement(By.xpath("//iframe[@name='PegaGadget6Ifr']")));
			try {
				BaseClass.SwitchtoFrameUsingFrameIdorName(InsideItem);
			}catch(NoSuchFrameException exception){

			}
			try {
				WebElement Templete = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Correspondence Template')]//following::input[@name='$PpyWorkPage$pCorrName']")));
				wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
				Templete.sendKeys("a");
				logger.info("The email task was indeed opened, but it should have activated the email task tab, considering the user is unavailable for the day.");
				Assert.assertTrue(false);
			}catch(TimeoutException e){
				Assert.assertTrue(true);
				logger.info("The email task remains unopened as the individual or user is currently unavailable for the day.");
			}
			logger.info("Now, let's configure the user's availability settings for the collection.******");
			Thread.sleep(3000);
		}

	public void Set_Default_to_assignee_01(String ZID,String customernumber) throws InterruptedException {
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Default to assignee')]/following-sibling::div/input")).clear();
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Default to assignee')]/following-sibling::div/input")).sendKeys(ZID);
		Thread.sleep(3000);
		logger.info("Entred Default to assignee ZID");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Submit ')]")).click();
		Thread.sleep(6000);
		logger.info("Click on Submit");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
//			WebElement mycustomer_list = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='My Customers']")));
//			logger.info("Click on mycustomer list");
//			mycustomer_list.click();
		Thread.sleep(5000);

		// Adjust the timeout as needed

// Step 1: Identify all matching elements with an explicit wait
//			List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//td[@data-attribute-name='Cust. No.']//span")));
//
//// Step 2: Generate a random index
//			Random rand = new Random();
//			int randomIndex = rand.nextInt(elements.size());

// Step 3: Get the randomly selected element with an explicit wait
//			WebElement randomElement = wait.until(ExpectedConditions.elementToBeClickable(elements.get(randomIndex)));
//
//// Step 4: Get the text from the randomly selected element
//			randomText = randomElement.getText();

// Now 'randomText' contains the text from the randomly selected element
//			System.out.println("Randomly selected text: " + randomText);
//			BaseClass.SwitchToDefaultFrame();


		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']")));


		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		} catch (StaleElementReferenceException e) {
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement element1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
			element1 = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element1.click();
			logger.info("Clicked on serach button");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}
		BaseClass.SwitchToDefaultFrame();

		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));


		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input")));

		WebElement customer = lwebDriver
				.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		try {

			customer.sendKeys(customernumber);
			logger.info("Enterd cutomer number");
		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
			customer.sendKeys("0000618287");
			logger.info("Enterd cutomer number");
		}

		WebElement sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
		try {
			Thread.sleep(5000);
			sumbit.click();
			logger.info("Click on serach Icon");

		} catch (StaleElementReferenceException e) {

			sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
			sumbit.click();
			logger.info("Enterd cutomer number");
		}

		// Wait for the element to be both visible and clickable
		WebElement qaCollectionElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//tr[contains(@id,'$PD_CollectionsByCustomerSearch_pa')])[1]//td[1]")));

		// Click on the element
		qaCollectionElement.click();
		logger.info("Clicked on collection ");
		// Switch back to the default frame
		SwitchToDefaultFrame();

		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget1Ifr");
		// Wait for the page to be fully loaded
		wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));

		WebElement checkbox = null;
		int retries = 0;

		while (retries < 3) {  // Limit the number of retries to avoid an infinite loop
			try {
				checkbox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[contains(@name,'$PD_OpenDebtorItemListByCollection_pa')])[2]")));
				checkbox.click();
				logger.info("Selected line item");
				break;  // Break out of the loop if successful
			} catch (StaleElementReferenceException e) {
				// Handle stale element exception, e.g., retry the operation
				System.err.println("StaleElementReferenceException: " + e.getMessage());
				retries++;
			} catch (TimeoutException e) {
				// Handle timeout exception
				System.err.println("TimeoutException: " + e.getMessage());
				retries++;
			}
		}

		if (checkbox == null) {
			System.err.println("Failed to click the checkbox after multiple attempts.");
		}
		BaseClass.WaitforVisiblityofElement(ClickOnEmailWithItem);
		ClickOnEmailWithItem.click();
		logger.info("Clicked on email with Item copy option");
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
		// lwebDriver.switchTo().frame(lwebDriver.findElement(By.xpath("//iframe[@name='PegaGadget6Ifr']")));
		try {
			BaseClass.SwitchtoFrameUsingFrameIdorName(InsideItem);
		}catch(NoSuchFrameException exception){

		}
		try {
			WebElement Templete = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Correspondence Template')]//following::input[@name='$PpyWorkPage$pCorrName']")));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
			Templete.sendKeys("a");
			logger.info("The email task was indeed opened, but it should have activated the email task tab, considering the user is unavailable for the day.");
			Assert.assertTrue(false);
		}catch(TimeoutException e){
			Assert.assertTrue(true);
			logger.info("The email task remains unopened as the individual or user is currently unavailable for the day.");
		}
		logger.info("Now, let's configure the user's availability settings for the collection.******");
		Thread.sleep(3000);
	}

	public void Set_Default_to_assignee_2(String ZID,String customername) throws InterruptedException {
		Thread.sleep(3000);
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Default to assignee')]/following-sibling::div/input")).clear();
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Default to assignee')]/following-sibling::div/input")).sendKeys(ZID);
		Thread.sleep(3000);
		logger.info("Entred Default to assignee ZID");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Submit ')]")).click();
		Thread.sleep(6000);
		logger.info("Click on Submit");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
//			WebElement mycustomer_list = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='My Customers']")));
//			logger.info("Click on mycustomer list");
//			mycustomer_list.click();
		Thread.sleep(5000);

		// Adjust the timeout as needed

// Step 1: Identify all matching elements with an explicit wait
//			List<WebElement> elements = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//td[@data-attribute-name='Cust. No.']//span")));
//
//// Step 2: Generate a random index
//			Random rand = new Random();
//			int randomIndex = rand.nextInt(elements.size());

// Step 3: Get the randomly selected element with an explicit wait
//			WebElement randomElement = wait.until(ExpectedConditions.elementToBeClickable(elements.get(randomIndex)));
//
//// Step 4: Get the text from the randomly selected element
//			randomText = randomElement.getText();

// Now 'randomText' contains the text from the randomly selected element
//			System.out.println("Randomly selected text: " + randomText);
//			BaseClass.SwitchToDefaultFrame();


		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']")));


		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element.click();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		} catch (StaleElementReferenceException e) {
			WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(40));
			WebElement element1 = wait1.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_7']")));
			element1 = lwebDriver.findElement(By.xpath("//a[@name='pyPortalHeader_pyDisplayHarness_30']"));
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			element1.click();
			logger.info("Clicked on serach button");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		}
		BaseClass.SwitchToDefaultFrame();

		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));


		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input")));

		WebElement customer = lwebDriver
				.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
		try {

			customer.sendKeys(customername);
			logger.info("Enterd cutomer number");
		} catch (StaleElementReferenceException e) {

			customer = lwebDriver.findElement(By.xpath("//label[@for='7fbbb3fc']/following-sibling::div//span/input"));
			customer.sendKeys("0000618287");
			logger.info("Enterd cutomer number");
		}

		WebElement sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
		try {
			Thread.sleep(5000);
			sumbit.click();
			logger.info("Click on serach Icon");

		} catch (StaleElementReferenceException e) {

			sumbit = lwebDriver.findElement(By.xpath(" //button[.='Search']"));
			sumbit.click();
			logger.info("Enterd cutomer number");
		}

		// Wait for the element to be both visible and clickable
		WebElement qaCollectionElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//tr[contains(@id,'$PD_CollectionsByCustomerSearch_pa')])[1]//td[1]")));

		// Click on the element
		qaCollectionElement.click();
		logger.info("Clicked on collection ");
		// Switch back to the default frame
		SwitchToDefaultFrame();

		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget1Ifr");
		// Wait for the page to be fully loaded
		wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));

		WebElement checkbox = null;
		int retries = 0;

		while (retries < 3) {  // Limit the number of retries to avoid an infinite loop
			try {
				checkbox = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//input[contains(@name,'$PD_OpenDebtorItemListByCollection_pa')])[2]")));
				checkbox.click();
				logger.info("Selected line item");
				break;  // Break out of the loop if successful
			} catch (StaleElementReferenceException e) {
				// Handle stale element exception, e.g., retry the operation
				System.err.println("StaleElementReferenceException: " + e.getMessage());
				retries++;
			} catch (TimeoutException e) {
				// Handle timeout exception
				System.err.println("TimeoutException: " + e.getMessage());
				retries++;
			}
		}

		if (checkbox == null) {
			System.err.println("Failed to click the checkbox after multiple attempts.");
		}
		Thread.sleep(5000);
		BaseClass.WaitforVisiblityofElement(ClickOnEmail1);
		ClickOnEmail1.click();
		logger.info("Clicked on email with Item copy option");
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
		// lwebDriver.switchTo().frame(lwebDriver.findElement(By.xpath("//iframe[@name='PegaGadget6Ifr']")));
		try {
			BaseClass.SwitchtoFrameUsingFrameIdorName(InsideItem);
		} catch (NoSuchFrameException exception) {

		} catch (TimeoutException e) {


		}
		try {
			WebElement Templete = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Correspondence Template')]//following::input[@name='$PpyWorkPage$pCorrName']")));
			wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("body")));
			Templete.sendKeys("a");
			logger.info("The email task was indeed opened, but it should have activated the email task tab, considering the user is unavailable for the day.");
			Assert.assertTrue(false);
		} catch (TimeoutException e) {
			Assert.assertTrue(true);
			logger.info("The email task remains unopened as the individual or user is currently unavailable for the day.");
		}

		Assert.assertTrue(true);
		logger.info("The email task remains unopened as the individual or user is currently unavailable for the day.");

		logger.info("Now, let's configure the user's availability settings for the collection.******");
		Thread.sleep(3000);
	}

		public void Verify_the_page_tittle() throws InterruptedException {
			logger.info("Going to verify for page tittle");
			String PageTittle=lwebDriver.getTitle();
			System.out.println(PageTittle);
//			String actual = lwebDriver.getTitle();
//			String expected = "CCMT - Cash Collector Portal";
//			Assert.assertEquals(actual, expected);
			logger.info("*****Availability was submited successfully*****");
}

		public void Verify_the_page_tittle_US() throws InterruptedException {
			logger.info("Going to verify for page tittle");
			String PageTittle=lwebDriver.getTitle();
			System.out.println(PageTittle);
			String actual = lwebDriver.getTitle();
			String expected = "CCMT - Cash Collector Manager Portal";
			Assert.assertEquals(actual, expected);
			logger.info("*****Availability was submited successfully*****");
}
		public void Dowmload_Allitems_in_collection() throws InterruptedException {
			BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
			Thread.sleep(3000);
			if(Download_items.isDisplayed()) {
				Assert.assertTrue(true);
				Download_items.click();
				logger.info("Clicked on download icon on collection page");
			}
			else {
				logger.info(" download icon was displayed  on collection page");
				Assert.assertTrue(false);
			}
			lwebDriver.findElement(By.xpath("//span[contains(text(),'Download Debtor Items')]")).click();
			Thread.sleep(10000);
		}
		public void getdata() throws IOException, InterruptedException {
			try {
				FileInputStream fis = new FileInputStream("D:\\UserData\\z004n9pt\\Documents\\GIRI\\OpenDebtorItemsByCollectionToExport.xlsx");
				XSSFWorkbook workbook = new XSSFWorkbook(fis);
			    XSSFSheet sheet = workbook.getSheetAt(0);
			    XSSFRow row = sheet.getRow(0);
			    String  value = null;

			    int col_num = -1;

			    for(int i=0; i <row.getLastCellNum(); i++)
			    {
			        if(row.getCell(i).getStringCellValue().trim().equals("Ref. No."))
			            col_num = i;
			    }

			    for(int i=1;i<row.getLastCellNum();i++) {
			    	 row = sheet.getRow(i);

			    	    XSSFCell cell = row.getCell(col_num);
			    	    value = cell.getStringCellValue();
			    	      //System.out.println(value);
			    }
			    System.out.println(value);
			    }catch(NullPointerException e) {
			    System.out.println(e);
			    }

		   // System.out.println(value);

		}
		public void Enteredinvoice__number_UK() throws InterruptedException, IOException {
			SwitchToDefaultFrame();
			logger.info("before");
			WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
			driver.switchTo().frame(iframe);
			System.out.println("Switching to frame...");
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
				System.out.println("Switching to frame complete.");
				WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
				ClickOnItemForContactUKRC.click();
				JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
				js2.executeScript("window.scrollBy(0,300)");
				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				try {
					Thread.sleep(2000);
					BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
					ClickOnContactEdit.click();
					Thread.sleep(3000);
				} catch (StaleElementReferenceException e) {
					ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
					ClickOnContactEdit.click();
					Thread.sleep(3000);
				}
				WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));

				if (!No_items.getText().isEmpty()) {
					ClickOnAddContact.click();
					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
					// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
					Thread.sleep(2000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
					this.ClickOnContactUpdate();
					Thread.sleep(5000);
				} else if (No_items.getText().isEmpty()) {
					ClickOnAddContact.click();
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
					Thread.sleep(2000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
					this.ClickOnContactUpdate();
					Thread.sleep(5000);

				}
			}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();
			BaseClass.SwitchToDefaultFrame();
			System.out.println("Switching to frame...");
			WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
			driver.switchTo().frame(iframe2);
			System.out.println("Switching to frame...");
			System.out.println("Switching to frame complete.");
			// Set the maximum wait time in seconds
		    wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		    WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		    wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		    JavascriptExecutor j = (JavascriptExecutor) driver;
		    j.executeScript("arguments[0].click();", Bulk_Section);
		    logger.info("Click on Bulk Section button");

		    WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		    invoiceNumbersTextarea.sendKeys(Line_item_IT22.getText() + "," + Line_item_IT222.getText());

		    WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		    wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		    WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		    Select Delimiter = new Select(Select);
		    Delimiter.selectByVisibleText(",");

		    lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		    logger.info("Clicked on Submit button");

		    WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		    wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		    BaseClass.SwitchToDefaultFrame();
		}

	public void Enteredinvoice__number_IN() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_IN.getText() + "," + Line_item_IN_2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_MX() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_MX.getText() + "," + Line_item_MX2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_INNN_RC() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item__IN.getText() + "," + Line_item__IN2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_MY() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_MY.getText() + "," + Line_item_MY2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_SHS() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_SHS.getText() + "," + Line_item_SHS2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_FBN() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");
		WebElement invoiceNumbersTextarea =	wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")));
	//	WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_FBA.getText() + "," + Line_item_FBA2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_AU_01() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_AU.getText() + "," + Line_item_AU_12.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_FR() throws InterruptedException, IOException {
		SwitchToDefaultFrame();
		logger.info("before");
		WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe);
		System.out.println("Switching to frame...");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
			System.out.println("Switching to frame complete.");
			WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[2]/form/div[3]/div[2]/section/div/span[2]/div/span/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div[4]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div[1]/i")));
			ClickOnItemForContactUKRC.click();

			JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
			js2.executeScript("window.scrollBy(0,300)");

			ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
			try {
				Thread.sleep(2000);
				BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			} catch (StaleElementReferenceException e) {
				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			}

			WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));


			if (!No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
				// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);


			} else if (No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);

			}
		}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();


		BaseClass.SwitchToDefaultFrame();
		System.out.println("Switching to frame...");
		WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe2);
		System.out.println("Switching to frame...");
		System.out.println("Switching to frame complete.");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_FR.getText() + "," + Line_item_FR2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_BR_GP() throws InterruptedException, IOException {
		SwitchToDefaultFrame();
		logger.info("before");
		WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe);
		System.out.println("Switching to frame...");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
			System.out.println("Switching to frame complete.");
			WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[2]/form/div[3]/div[2]/section/div/span[2]/div/span/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div[4]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div[1]/i")));
			ClickOnItemForContactUKRC.click();
			JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
			js2.executeScript("window.scrollBy(0,300)");
			ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
			try {
				Thread.sleep(2000);
				BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			} catch (StaleElementReferenceException e) {
				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			}
			WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));

			if (!No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
				// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);
			} else if (No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);

			}
		}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();
		BaseClass.SwitchToDefaultFrame();
		System.out.println("Switching to frame...");
		WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe2);
		System.out.println("Switching to frame...");
		System.out.println("Switching to frame complete.");

		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_PT1.getText() + "," + Line_item_PT2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_GP_CA() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_CA_GP.getText() + "," + Line_item_CA_GP2.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_PT() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_PT.getText() + "," + Line_item2_PT.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public  void Enteredinvoice__number_AU() throws InterruptedException, IOException {
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15)); // Set the maximum wait time in seconds
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");

		WebElement invoiceNumbersTextarea = lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		invoiceNumbersTextarea.sendKeys(Line_item_AU.getText() + "," + Line_item_AU1.getText());

		WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Submit')]")));

		WebElement Select = lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");

		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");

		WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10)); // Set the maximum wait time in seconds
		wait3.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Submit')]")));

		BaseClass.SwitchToDefaultFrame();
	}

	public void ClickOnContactUpdate() throws InterruptedException {

		Thread.sleep(3000);
		ClickOnUpdate.click();
		Thread.sleep(6000);

		BaseClass.SwitchToDefaultFrame();


	}

		public void Enteredinvoice__number_HC() throws InterruptedException, IOException {

		Thread.sleep(5000);
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


		// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
		// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofSeconds(5));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_HC.getText()+","+Line2_item_HC.getText());
		Thread.sleep(5000);
		logger.info("Sent Ref.No numbers to textbox in BulkSections");
		WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");
		Thread.sleep(5000);



		BaseClass.SwitchToDefaultFrame();


	}
		
		public void Enteredinvoice__number_HC_MESA() throws InterruptedException, IOException {

			SwitchToDefaultFrame();
			logger.info("before");
			WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
			driver.switchTo().frame(iframe);
			System.out.println("Switching to frame...");
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
				System.out.println("Switching to frame complete.");
				WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
				ClickOnItemForContactUKRC.click();

				JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
				js2.executeScript("window.scrollBy(0,300)");

				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				try {
					Thread.sleep(2000);
					BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
					ClickOnContactEdit.click();
					Thread.sleep(3000);
				} catch (StaleElementReferenceException e) {
					ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
					ClickOnContactEdit.click();
					Thread.sleep(3000);
				}

				WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));


				if (!No_items.getText().isEmpty()) {
					ClickOnAddContact.click();
					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
					// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
					Thread.sleep(2000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
					this.ClickOnContactUpdate();
					Thread.sleep(5000);


				} else if (No_items.getText().isEmpty()) {
					ClickOnAddContact.click();
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
					Thread.sleep(2000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
					this.ClickOnContactUpdate();
					Thread.sleep(5000);

				}
			}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();


			BaseClass.SwitchToDefaultFrame();
			System.out.println("Switching to frame...");
			WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
			driver.switchTo().frame(iframe2);


	    	// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
	    	// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

	    	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	  WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
	    	  wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	 JavascriptExecutor j = (JavascriptExecutor) driver;
	    	 j.executeScript("arguments[0].click();", Bulk_Section);
	    	 logger.info("Click on Bulk Section button");
	    		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_HC_MES.getText()+","+Line2_item_HC_MES.getText());
	    		   Thread.sleep(5000);
	    		   logger.info("Sent Ref.No numbers to textbox in BulkSections");
	    		   WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
	    	 	   Select Delimiter = new Select(Select);
	    	 	  Delimiter.selectByVisibleText(",");
	    	 	   lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	    	 	  logger.info("Clicked on Submit button");
	    	 	    Thread.sleep(5000);



	BaseClass.SwitchToDefaultFrame();


	}

	public void Enteredinvoice__number_HC1() throws InterruptedException, IOException {

		Thread.sleep(5000);
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


		// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
		// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofSeconds(5));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_HC.getText()+","+Line2_item_HC.getText());
		Thread.sleep(5000);
		logger.info("Sent Ref.No numbers to textbox in BulkSections");
		WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");
		Thread.sleep(5000);



		BaseClass.SwitchToDefaultFrame();


	}

	public void Enteredinvoice__number_IT1() throws InterruptedException, IOException {
		SwitchToDefaultFrame();
		logger.info("before");
		WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe);
		System.out.println("Switching to frame...");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
			System.out.println("Switching to frame complete.");
			WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[2]/form/div[3]/div[2]/section/div/span[2]/div/span/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div[4]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div[1]/i")));
			ClickOnItemForContactUKRC.click();

			JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
			js2.executeScript("window.scrollBy(0,300)");

			ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
			try {
				Thread.sleep(2000);
				BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			} catch (StaleElementReferenceException e) {
				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			}

			WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));


			if (!No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
				// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);


			} else if (No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);

			}
		}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();


		BaseClass.SwitchToDefaultFrame();
		System.out.println("Switching to frame...");
		WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe2);
		System.out.println("Switching to frame...");
		System.out.println("Switching to frame complete.");
		Thread.sleep(5000);
		// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
		// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_IT22.getText()+","+Line_item_IT222.getText());
		Thread.sleep(5000);
		logger.info("Sent Ref.No numbers to textbox in BulkSections");
		WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");
		Thread.sleep(5000);



		BaseClass.SwitchToDefaultFrame();


	}

	public void Enteredinvoice__number_CH() throws InterruptedException, IOException {
		SwitchToDefaultFrame();
		logger.info("before");
		WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe);
		System.out.println("Switching to frame...");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
			System.out.println("Switching to frame complete.");
			WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[2]/form/div[3]/div[2]/section/div/span[2]/div/span/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div[4]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div[1]/i")));
			ClickOnItemForContactUKRC.click();

			JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
			js2.executeScript("window.scrollBy(0,300)");

			ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
			try {
				Thread.sleep(2000);
				BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			} catch (StaleElementReferenceException e) {
				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			}

			WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));


			if (!No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
				// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);


			} else if (No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);

			}
		}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();


		BaseClass.SwitchToDefaultFrame();
		System.out.println("Switching to frame...");
		WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe2);
		System.out.println("Switching to frame...");
		System.out.println("Switching to frame complete.");
		Thread.sleep(5000);

		// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
		// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));


		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_CH.getText()+","+Line_item_CH2.getText());
		Thread.sleep(5000);
		logger.info("Sent Ref.No numbers to textbox in BulkSections");
		WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");
		Thread.sleep(5000);



		BaseClass.SwitchToDefaultFrame();


	}



		public void Enteredinvoice__number_SI() throws InterruptedException, IOException {

	    	  Thread.sleep(5000);
			SwitchToDefaultFrame();
			logger.info("before");
			WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
			driver.switchTo().frame(iframe);
			System.out.println("Switching to frame...");
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
				System.out.println("Switching to frame complete.");
				WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h1[contains(text(),'Collection')]//following::i[7]")));
				ClickOnItemForContactUKRC.click();

				JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
				js2.executeScript("window.scrollBy(0,300)");

				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				try {
					Thread.sleep(2000);
					BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
					ClickOnContactEdit.click();
					Thread.sleep(3000);
				} catch (StaleElementReferenceException e) {
					ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
					ClickOnContactEdit.click();
					Thread.sleep(3000);
				}

				WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));
				if (!No_items.getText().isEmpty()) {
					ClickOnAddContact.click();
					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
					// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
					Thread.sleep(2000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
					this.ClickOnContactUpdate();
					Thread.sleep(5000);


				} else if (No_items.getText().isEmpty()) {
					ClickOnAddContact.click();
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
					Thread.sleep(2000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
					this.ClickOnContactUpdate();
					Thread.sleep(5000);
				}
			}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();
			BaseClass.SwitchToDefaultFrame();
			System.out.println("Switching to frame...");
			WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
			driver.switchTo().frame(iframe2);
			System.out.println("Switching to frame...");
			System.out.println("Switching to frame complete.");
	    	// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
	    	// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	    	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	  WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
	    	  wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	 JavascriptExecutor j = (JavascriptExecutor) driver;
	    	 j.executeScript("arguments[0].click();", Bulk_Section);
	    	 logger.info("Click on Bulk Section button");
	    		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line2_item_SI1.getText()+","+Line2_item_SI.getText());
	    		   Thread.sleep(5000);
	    		   logger.info("Sent Ref.No numbers to textbox in BulkSections");
	    		   WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
	    	 	   Select Delimiter = new Select(Select);
	    	 	  Delimiter.selectByVisibleText(",");
	    	 	   lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	    	 	  logger.info("Clicked on Submit button");
	    	 	    Thread.sleep(5000);



	BaseClass.SwitchToDefaultFrame();


	}

	public void Enteredinvoice__number_IT() throws InterruptedException, IOException {

		Thread.sleep(5000);
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


		// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
		// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofSeconds(5));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_IT.getText()+","+Line_item2_IT.getText());
		Thread.sleep(5000);
		logger.info("Sent Ref.No numbers to textbox in BulkSections");
		WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");
		Thread.sleep(5000);



		BaseClass.SwitchToDefaultFrame();


	}


	public void Enteredinvoice__number_CA() throws InterruptedException, IOException {

		Thread.sleep(5000);
		BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


		// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
		// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofSeconds(5));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
		JavascriptExecutor j = (JavascriptExecutor) driver;
		j.executeScript("arguments[0].click();", Bulk_Section);
		logger.info("Click on Bulk Section button");
		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_CA.getText()+","+Line2_item_CA.getText());
		Thread.sleep(5000);
		logger.info("Sent Ref.No numbers to textbox in BulkSections");
		WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Select);
		Delimiter.selectByVisibleText(",");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");
		Thread.sleep(5000);



		BaseClass.SwitchToDefaultFrame();


	}// System.out.println(R
		
		public void Enteredinvoice__number_DE() throws InterruptedException, IOException {

			SwitchToDefaultFrame();
			logger.info("before");
			WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
			driver.switchTo().frame(iframe);
			System.out.println("Switching to frame...");
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
			if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
				System.out.println("Switching to frame complete.");
				WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
				ClickOnItemForContactUKRC.click();

				JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
				js2.executeScript("window.scrollBy(0,300)");

				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				try {
					Thread.sleep(2000);
					BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
					ClickOnContactEdit.click();
					Thread.sleep(3000);
				} catch (StaleElementReferenceException e) {
					ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
					ClickOnContactEdit.click();
					Thread.sleep(3000);
				}

				WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));


				if (!No_items.getText().isEmpty()) {
					ClickOnAddContact.click();
					wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
					// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
					Thread.sleep(2000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
					this.ClickOnContactUpdate();
					Thread.sleep(5000);


				} else if (No_items.getText().isEmpty()) {
					ClickOnAddContact.click();
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
					Thread.sleep(4000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
					Thread.sleep(2000);
					lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
					this.ClickOnContactUpdate();
					Thread.sleep(5000);

				}
			}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();


			BaseClass.SwitchToDefaultFrame();
			System.out.println("Switching to frame...");
			WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
			driver.switchTo().frame(iframe2);
			System.out.println("Switching to frame...");
			System.out.println("Switching to frame complete.");


	    	// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
	    	// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

	    	  
	    	  WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
	 WebElement BulkSection =    	  wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	 BulkSection.click();
	    	 logger.info("Click on Bulk Section button");
	    		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_DE.getText()+","+Line_item_DE2.getText());
	    		   Thread.sleep(5000);
	    		   logger.info("Sent Ref.No numbers to textbox in BulkSections");
	    		   WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
	    	 	   Select Delimiter = new Select(Select);
	    	 	  Delimiter.selectByVisibleText(",");
	    	 	   lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	    	 	  logger.info("Clicked on Submit button");
	    	 	    Thread.sleep(5000);



	BaseClass.SwitchToDefaultFrame();


	}

		public void Enteredinvoice__number_GP() throws InterruptedException, IOException {

	    	  Thread.sleep(5000);
	    	  BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


	    	// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
	    	// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

	    	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofSeconds(5));
	    	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	  WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
	    	  wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	 JavascriptExecutor j = (JavascriptExecutor) driver;
	    	 j.executeScript("arguments[0].click();", Bulk_Section);
	    	 logger.info("Click on Bulk Section button");
	    		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_GP.getText()+","+Line2_item_GP.getText());
	    		   Thread.sleep(5000);
	    		   logger.info("Sent Ref.No numbers to textbox in BulkSections");
	    		   WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
	    	 	   Select Delimiter = new Select(Select);
	    	 	  Delimiter.selectByVisibleText(",");
	    	 	   lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	    	 	  logger.info("Clicked on Submit button");
	    	 	    Thread.sleep(5000);



	BaseClass.SwitchToDefaultFrame();


	}
		
		public void Enteredinvoice__number_GP1() throws InterruptedException, IOException {

	    	  Thread.sleep(5000);
	    	  BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


	    	// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
	    	// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

	    	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofSeconds(5));
	    	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	  WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
	    	  wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	 JavascriptExecutor j = (JavascriptExecutor) driver;
	    	 j.executeScript("arguments[0].click();", Bulk_Section);
	    	 logger.info("Click on Bulk Section button");
	    		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_GP1.getText()+","+Line2_item_GP2.getText());
	    		   Thread.sleep(5000);
	    		   logger.info("Sent Ref.No numbers to textbox in BulkSections");
	    		   WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
	    	 	   Select Delimiter = new Select(Select);
	    	 	  Delimiter.selectByVisibleText(",");
	    	 	   lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	    	 	  logger.info("Clicked on Submit button");
	    	 	    Thread.sleep(5000);



	BaseClass.SwitchToDefaultFrame();


	}
		
		public void Enteredinvoice__number_BR() throws InterruptedException, IOException {

	    	  Thread.sleep(5000);
	    	  BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


	    	// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
	    	// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

	    	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofSeconds(5));
	    	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	  WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
	    	  wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	 JavascriptExecutor j = (JavascriptExecutor) driver;
	    	 j.executeScript("arguments[0].click();", Bulk_Section);
	    	 logger.info("Click on Bulk Section button");
	    		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_GP2.getText()+","+Line21_item_GP2.getText());
	    		   Thread.sleep(5000);
	    		   logger.info("Sent Ref.No numbers to textbox in BulkSections");
	    		   WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
	    	 	   Select Delimiter = new Select(Select);
	    	 	  Delimiter.selectByVisibleText(",");
	    	 	   lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	    	 	  logger.info("Clicked on Submit button");
	    	 	    Thread.sleep(5000);



	BaseClass.SwitchToDefaultFrame();


	}
		
		public void Enteredinvoice__number_SEU() throws InterruptedException, IOException {

	    	  Thread.sleep(5000);
	    	  BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);


	    	// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
	    	// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

	    	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofSeconds(5));
	    	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	  WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
	    	  wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
	    	 JavascriptExecutor j = (JavascriptExecutor) driver;
	    	 j.executeScript("arguments[0].click();", Bulk_Section);
	    	 logger.info("Click on Bulk Section button");
	    		lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")).sendKeys(Line_item_SEU.getText()+","+Line_item_SEU2.getText());
	    		   Thread.sleep(5000);
	    		   logger.info("Sent Ref.No numbers to textbox in BulkSections");
	    		   WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
	    	 	   Select Delimiter = new Select(Select);
	    	 	  Delimiter.selectByVisibleText(",");
	    	 	   lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	    	 	  logger.info("Clicked on Submit button");
	    	 	    Thread.sleep(5000);



	BaseClass.SwitchToDefaultFrame();


	}



      public void Enteredinvoice__number_US() throws InterruptedException, IOException {

		  SwitchToDefaultFrame();
		  logger.info("before");
		  WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
		  driver.switchTo().frame(iframe);
		  System.out.println("Switching to frame...");
		  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		  if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
			  System.out.println("Switching to frame complete.");
			  WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[2]/form/div[3]/div[2]/section/div/span[2]/div/span/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div[4]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div[1]/i")));
			  ClickOnItemForContactUKRC.click();

			  JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
			  js2.executeScript("window.scrollBy(0,300)");

			  ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
			  try {
				  Thread.sleep(2000);
				  BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
				  ClickOnContactEdit.click();
				  Thread.sleep(3000);
			  } catch (StaleElementReferenceException e) {
				  ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				  ClickOnContactEdit.click();
				  Thread.sleep(3000);
			  }

			  WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));


			  if (!No_items.getText().isEmpty()) {
				  ClickOnAddContact.click();
				  wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
				  // BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
				  Thread.sleep(4000);
				  lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
				  Thread.sleep(4000);
				  lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
				  Thread.sleep(2000);
				  lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				  this.ClickOnContactUpdate();
				  Thread.sleep(5000);


			  } else if (No_items.getText().isEmpty()) {
				  ClickOnAddContact.click();
				  Thread.sleep(4000);
				  lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
				  Thread.sleep(4000);
				  lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
				  Thread.sleep(2000);
				  lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				  this.ClickOnContactUpdate();
				  Thread.sleep(5000);

			  }
		  }
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();
		  BaseClass.SwitchToDefaultFrame();
		  System.out.println("Switching to frame...");
		  WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
		  driver.switchTo().frame(iframe2);
    	// BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Bulk Selection')]"));
    	// WebElement l = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
    	  wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
    	  WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
    	  wait1.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));
    	 JavascriptExecutor j = (JavascriptExecutor) driver;
    	 j.executeScript("arguments[0].click();", Bulk_Section);
    	 logger.info("Click on Bulk Section button");
		//  WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40));
		  WebElement Doc_number =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")));
		  Doc_number.sendKeys(Line_item_US.getText()+","+Line2_item_US.getText());

    		   Thread.sleep(5000);
    		   logger.info("Sent Ref.No numbers to textbox in BulkSections");
    		   WebElement Select =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
    	 	   Select Delimiter = new Select(Select);
    	 	  Delimiter.selectByVisibleText(",");
    	 	   lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
    	 	  logger.info("Clicked on Submit button");
    	 	    Thread.sleep(5000);



BaseClass.SwitchToDefaultFrame();


}
 	   public void Enter_text_to_searchbox() throws InterruptedException {
 		  WebElement Searchtext2222 = lwebDriver.findElement(By.xpath("//label[text()='Search Text']/following::input"));
 		 WebElement Ref_No = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[21]//span"));

 		  try {
 			 Searchtext2222.sendKeys(Ref_No.getText());
 		  }catch(StaleElementReferenceException e1) {
 			 Searchtext2222 = lwebDriver.findElement(By.xpath("//label[text()='Search Text']/following::input"));
 			Ref_No = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[21]//span"));
 			Searchtext2222.sendKeys(Ref_No.getText());
 			Thread.sleep(4000);
 		  }
 	   }



public void Verify_LineIteamNote(String previous) throws InterruptedException {

	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::table[2]"))
			.getText();
	logger.info("Validating the Fisr Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}

}

	public void Verify_LineIteamNote_MX(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			 Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]//td[@data-attribute-name='Note']//td"))
					.getText();
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void Verify_LineIteamNote_CH(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]//td[10]//td"))
					.getText();
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void Verify_LineIteamNote_MX_2(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]//td[@data-attribute-name='Note']//td"))
					.getText();
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}
	public void Verify_LineIteamNote_CH_second_line(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]//td[10]//td"))
					.getText();
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}
	public void Verify_LineIteamNote_IN(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[@data-attribute-name='Text']//span"))
					.getText();
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void Verify_LineIteamNote_SHS(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[@data-attribute-name='Texto']//tbody//td"))
					.getText();
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void Verify_LineIteamNote_MY(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Lineitemnotea =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[19]/div/table/tbody/tr/td")));
			Lineitemnote = Lineitemnotea.getText();
			System.out.println(Lineitemnote);
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		Thread.sleep(5000);
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void Verify_LineIteamNote_MY_2(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
			WebElement Lineitemnotea =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[19]/div/table/tbody/tr/td")));
			Lineitemnote = Lineitemnotea.getText();
			System.out.println(Lineitemnote);
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		Thread.sleep(5000);
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void Verify_LineIteamNote_FBA(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[@data-attribute-name='Note']//span"))
					.getText();
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void Verify_LineIteamNote_FR(String previous) throws InterruptedException, IOException {
		String Lineitemnote;
		Thread.sleep(4000);
		try {
			Lineitemnote = lwebDriver
					.findElement(By.xpath(
							"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]//td[15]//tbody//td"))
					.getText();
		}catch (NoSuchElementException e){
			throw new IOException("No Note column is available on line items for displaying item notes");
		}
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void Verify_LineIteamNote_GP_CA(String previous) throws InterruptedException {

		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]//td[11]//tbody//td"))
				.getText();
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}


	public void Verify_LineIteamNote_IT(String previous) throws InterruptedException {

		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Note']//td"))
				.getText();
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

	public void
	Verify_Second_LineIteamNote_IT_RC(String previous) throws InterruptedException {

		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Note']//td"))
				.getText();
		logger.info("Validating the Fisr Line item  note");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}

	}

public void Verify_LineIteamNote_US(String previous) throws InterruptedException {

	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[1]//td[13]//td"))
			.getText();
	logger.info("Validating the Fisr Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}

}

public void Verify_LineIteamNote_HC1(String previous) throws InterruptedException {

	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[14]//td"))
			.getText();
	logger.info("Validating the Fisr Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
}

public void Verify_LineIteamNote_DE1(String previous) throws InterruptedException {

	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[25]//td"))
			.getText();
	logger.info("Validating the Fisr Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
}

public void Verify_LineIteamNote_HC1_BR(String previous) throws InterruptedException {

	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::table/descendant::td "))
			.getText();
	logger.info("Validating the Fisr Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
}

public void Verify_LineIteamNote_EN1(String previous) throws InterruptedException {

	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[14]//td"))
			.getText();
	logger.info("Validating the Fisr Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
}

public void Verify_LineIteamNote_NL1(String previous) throws InterruptedException {

	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[16]//span)[2]"))
			.getText();

	String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
	System.out.println(amount);
	logger.info("Validating the Fisr Line item  note");
	if (amount.contains(previous)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
}
	public void Verify_Second_LineIteamNote_HC1(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[14]//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		 l.click();
		 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		 l2.click();
		 Thread.sleep(3000);
		 BaseClass.SwitchToDefaultFrame();
	}
	
	public void Verify_Second_LineIteamNote_DE2(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[25]//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		 l.click();
		 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		 l2.click();
		 Thread.sleep(3000);
		 BaseClass.SwitchToDefaultFrame();
	}
	
	public void Verify_Second_LineIteamNote_HC1_2(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[2]/descendant::table/descendant::td "))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		 l.click();
		 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		 l2.click();
		 Thread.sleep(3000);
		 BaseClass.SwitchToDefaultFrame();
	}
	
	
	public void Verify_Second_LineIteamNote_EN1(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[2]/descendant::td[14]//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		 l.click();
		 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		 l2.click();
		 Thread.sleep(3000);
		 BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_NL2(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[16]//span)[2]"))
				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);
		logger.info("Note on second line item validation");
		if (amount.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		 l.click();
		 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		 l2.click();
		 Thread.sleep(3000);
		 BaseClass.SwitchToDefaultFrame();
	}



public void Verify_LineIteamNote_UK(String previous) throws InterruptedException {

	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::table[2]"))
			.getText();
	logger.info("Validating the First Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//BaseClass.SwitchToDefaultFrame();
}

public void Verify_LineIteamNote_(String previous) throws InterruptedException {
	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::table[2]//td"))
			.getText();
	logger.info("Validating the First Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//

}

public void Verify_LineIteamNote_HC_BR(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::table/descendant::td "))
			.getText();
	logger.info("Validating the First Line item  note");
	if (previous.equals(Lineitemnote) || Lineitemnote.contains(previous) ) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//BaseClass.SwitchToDefaultFrame();
}

public void Verify_LineIteamNote_HC(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[28]//span/span"))
			.getText();
	System.out.println(Lineitemnote);
	logger.info("Validating the First Line item  note");
	if (previous.equals(Lineitemnote) || Lineitemnote.contains(previous) ) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//BaseClass.SwitchToDefaultFrame();
}
	public void Verify_LineIteamNote_GP_HC(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[20]//td"))
				.getText();
		System.out.println(Lineitemnote);
		logger.info("Validating the First Line item  note");
		if (previous.equals(Lineitemnote) || Lineitemnote.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}
	public void Verify_LineIteamNote_HC_US_Note(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[15]"))
				.getText();
		System.out.println(Lineitemnote);
		logger.info("Validating the First Line item  note");
		if (previous.equals(Lineitemnote) || Lineitemnote.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_LineIteamNote_GP_US(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[14]//td"))
				.getText();
		System.out.println(Lineitemnote);
		logger.info("Validating the First Line item  note");
		if (previous.equals(Lineitemnote) || Lineitemnote.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}
	public void Verify_LineIteamNote_SUS(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//td[@data-attribute-name='Note']//span)[1]"))
				.getText();
		logger.info("Validating the First Line item  note");
		if (previous.equals(Lineitemnote) || Lineitemnote.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}
public void Verify_LineIteamNote_HC_BR1(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
	WebElement Lineitemnote1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[12]//td")));
	String Lineitemnote = Lineitemnote1
			.getText();
	logger.info("Validating the First Line item  note");
	if (previous.equals(Lineitemnote) || Lineitemnote.contains(previous) ) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//BaseClass.SwitchToDefaultFrame();
}

public void Verify_LineIteamNote_En(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[1]/descendant::td[14]//td"))
			.getText();
	logger.info("Validating the First Line item  note");
	if (previous.equals(Lineitemnote) || Lineitemnote.contains(previous) ) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//BaseClass.SwitchToDefaultFrame();
}

public void Verify_LineIteamNote_NL(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[16]//span)[2]"))
			.getText();

	String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
	System.out.println(amount);

	logger.info("Validating the First Line item  note");
	if (amount.contains(previous) ) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//BaseClass.SwitchToDefaultFrame();
}

	public void Verify_LineIteamNote_GP_NL(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[1]/descendant::td[@data-attribute-name='Note']//span[2]"))
				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);

		logger.info("Validating the First Line item  note");
		if (amount.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_LineIteamNote_GP_IT(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[1]/descendant::td[@data-attribute-name='Note']//td"))
				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);

		logger.info("Validating the First Line item  note");
		if (amount.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_LineIteamNote_CA(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Checkbox = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[11]//td")));
		String Lineitemnote = Checkbox.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);

		logger.info("Validating the First Line item  note");
		if (amount.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_LineIteamNote_ZA(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);





		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[18]//td"))

				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);

		logger.info("Validating the First Line item  note");
		if (amount.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}


	public  void Verify_LineIteamNote_PT(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
		Thread.sleep(4000);





		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[1]/descendant::td[@data-attribute-name='Note']//tbody//td"))

				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);

		logger.info("Validating the First Line item  note");
		if (amount.contains(previous) ) {
			Assert.assertTrue(true);
			logger.info("The  first note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		//BaseClass.SwitchToDefaultFrame();
	}



public void Verify_LineIteamNote_DE(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[25]//td"))
			.getText();

	String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
	System.out.println(amount);

	logger.info("Validating the First Line item  note");
	if (amount.contains(previous) ) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//BaseClass.SwitchToDefaultFrame();
}

public void Verify_LineIteamNote_SI(String previous) throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::table"))
			.getText();
	logger.info("Validating the First Line item  note");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  first note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	//BaseClass.SwitchToDefaultFrame();
}

public void Verify_Second_LineIteamNote(String previous) throws InterruptedException {
	Thread.sleep(4000);

	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::table[2]"))
			.getText();
	logger.info("Note on second line item validation");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
	 l.click();
	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
	 l2.click();
	 Thread.sleep(3000);
	 BaseClass.SwitchToDefaultFrame();
}

	public void Verify_Second_LineIteamNote_MX(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]//td[@data-attribute-name='Note']//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
//		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//		l.click();
//		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//		l2.click();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_IN(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][1]/descendant::td[@data-attribute-name='Text']//span"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
//		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//		l.click();
//		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//		l2.click();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_MY(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[@data-attribute-name='Text']//tbody//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
//		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//		l.click();
//		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//		l2.click();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
	}
	public void Verify_Second_LineIteamNote_SHS(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[@data-attribute-name='Texto']//tbody//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
//		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//		l.click();
//		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//		l2.click();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
	}
	public void Verify_Second_LineIteamNote_FBA(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[@data-attribute-name='Note']//span"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
//		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//		l.click();
//		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//		l2.click();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_FR(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]//td[15]//tbody//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
//		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//		l.click();
//		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//		l2.click();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_GP_CA(String previous) throws InterruptedException {
		Thread.sleep(4000);

		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]//td[11]//tbody//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
//		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//		l.click();
//		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//		l2.click();
		Thread.sleep(3000);
		BaseClass.SwitchToDefaultFrame();
	}

public void Verify_Second_LineIteamNote_US(String previous) throws InterruptedException {
	Thread.sleep(4000);

	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[2]//td[13]//td"))
			.getText();
	logger.info("Note on second line item validation");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
	 l.click();
	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
	 l2.click();
	 Thread.sleep(3000);
	 BaseClass.SwitchToDefaultFrame();
}

public void Verify_Second_LineIteamNote_UK(String previous) throws InterruptedException {
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::table[2]"))
			.getText();
	logger.info("Note on second line item validation");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
	 l.click();
	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
	 l2.click();
	 Thread.sleep(6000);
	BaseClass.SwitchToDefaultFrame();
}

public void Verify_Second_LineIteamNote_HC(String previous) throws InterruptedException {
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[2]/descendant::td[28]//span/span"))
			.getText();
	logger.info("Note on second line item validation");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
	 l.click();
	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
	 l2.click();
	 Thread.sleep(6000);
	BaseClass.SwitchToDefaultFrame();
}

	public void Verify_Second_LineIteamNote_GP_US_1(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[2]/descendant::td[20]//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		l.click();
		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_HC_US_Note(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[2]/descendant::td[15]"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		l.click();
		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}
	public void Verify_Second_LineIteamNote_GP_US(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//td[14]//td"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		l.click();
		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}
	public void Verify_Second_LineIteamNote_SEU(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[12]//span"))
				.getText();
		logger.info("Note on second line item validation");
		if (previous.equals(Lineitemnote)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		l.click();
		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}

public void Verify_Second_LineIteamNote_BR111(String previous) throws InterruptedException {
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[12]//td"))
			.getText();
	logger.info("Note on second line item validation");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
//	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//	 l.click();
//	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//	 l2.click();
	 Thread.sleep(3000);
	BaseClass.SwitchToDefaultFrame();
}

public void Verify_Second_LineIteamNote_HC_BR1(String previous) throws InterruptedException {
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[2]/descendant::table/descendant::td"))
			.getText();
	logger.info("Note on second line item validation");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
	 l.click();
	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
	 l2.click();
	 Thread.sleep(6000);
	BaseClass.SwitchToDefaultFrame();
}

public void Verify_Second_LineIteamNote_EN(String previous) throws InterruptedException {
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')])[2]/descendant::td[14]//td"))
			.getText();
	logger.info("Note on second line item validation");
	if (previous.equals(Lineitemnote)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
	 l.click();
	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
	 l2.click();
	 Thread.sleep(6000);
	BaseClass.SwitchToDefaultFrame();
}

public void Verify_Second_LineIteamNote_NL(String previous) throws InterruptedException {
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[16]//span)[2]"))
			.getText();

	String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
	System.out.println(amount);
	logger.info("Note on second line item validation");
	if (amount.contains(previous)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
//	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//	 l.click();
//	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//	 l2.click();
	 Thread.sleep(6000);
	BaseClass.SwitchToDefaultFrame();
}

	public void Verify_Second_LineIteamNote_NL_GP(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[16]//span)[2]"))
				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);
		logger.info("Note on second line item validation");
		if (amount.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		l.click();
		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_IT(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[2]/descendant::td[@data-attribute-name='Note']//td"))
				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);
		logger.info("Note on second line item validation");
		if (amount.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		l.click();
		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_CA(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[11]//td"))
				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);
		logger.info("Note on second line item validation");
		if (amount.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
//		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
//		l.click();
//		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
//		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_ZA(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[18]//td"))
				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);
		logger.info("Note on second line item validation");
		if (amount.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		l.click();
		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}

	public void Verify_Second_LineIteamNote_PT(String previous) throws InterruptedException {
		Thread.sleep(4000);
		String Lineitemnote = lwebDriver
				.findElement(By.xpath(
						"(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')])[2]/descendant::td[@data-attribute-name='Note']//tbody//td"))
				.getText();

		String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
		System.out.println(amount);
		logger.info("Note on second line item validation");
		if (amount.contains(previous)) {
			Assert.assertTrue(true);
			logger.info("The  second note was correctly updated and  displayed on the line item");
		} else {
			logger.info("The line item does not contain a Note");
			Assert.assertTrue(false);
		}
		WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		l.click();
		WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
		l2.click();
		Thread.sleep(6000);
		BaseClass.SwitchToDefaultFrame();
	}

public void Verify_Second_LineIteamNote_DE1(String previous) throws InterruptedException {
	Thread.sleep(4000);
	String Lineitemnote = lwebDriver
			.findElement(By.xpath(
					"//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_p')][2]/descendant::td[25]//td"))
			.getText();

	String amount =Lineitemnote.replaceAll("[^A-Z a-z] ", "");
	System.out.println(amount);
	logger.info("Note on second line item validation");
	if (amount.contains(previous)) {
		Assert.assertTrue(true);
		logger.info("The  second note was correctly updated and  displayed on the line item");
	} else {
		logger.info("The line item does not contain a Note");
		Assert.assertTrue(false);
	}
	 WebElement l = lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
	 l.click();
	 WebElement l2 = lwebDriver.findElement(By.xpath("//span[contains(text(),'Refresh')]"));
	 l2.click();
	 Thread.sleep(6000);
	BaseClass.SwitchToDefaultFrame();
}

public void Enteredinvoice__number_US1() throws InterruptedException, IOException {
BaseClass.SwitchToDefaultFrame();

	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
	WebElement Bulk_Section111 =wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[text()='Bulk Selection']")));

//	WebElement Bulk_Section111 = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));

try {
	 JavascriptExecutor j = (JavascriptExecutor) driver;
	 j.executeScript("arguments[0].click();", Bulk_Section111);
	 logger.info("Click on Bulk Section button");
}catch(StaleElementReferenceException e) {

	Bulk_Section111 = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	JavascriptExecutor j = (JavascriptExecutor) driver;
	 j.executeScript("arguments[0].click();", Bulk_Section111);
	 logger.info("Click on Bulk Section button");

}




}







public void Enter_Text() throws InterruptedException, IOException {

WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
WebElement Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[21]//span"));
WebElement Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[21]//span"));

try {
	ref.sendKeys(Line1.getText()+";"+Line2.getText());
}catch(StaleElementReferenceException e) {

	ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	 Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[21]//span"));
	 Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[21]//span"));
	ref.sendKeys(Line_item_US.getText()+";"+Line2_item_US.getText());
	logger.info("Sent Ref.No numbers to textbox in BulkSections");

}

}

	public void Enter_Text_IT2() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		WebElement Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Ref. No.']//span"));
		WebElement Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Ref. No.']//span"));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Ref. No.']//span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Ref. No.']//span"));
			ref.sendKeys(Line_item_US.getText()+";"+Line2_item_US.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}


	public void Enter_Text_CH() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		WebElement Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Referenz']//span"));
		WebElement Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Referenz']//span"));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Referenz']//span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Referenz']//span"));
			ref.sendKeys(Line_item_US.getText()+";"+Line2_item_US.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}



public void Enter_Text_UK() throws InterruptedException, IOException {

WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

	WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Ref. No.']//div")));

	WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Ref. No.']//div")));




try {
	ref.sendKeys(Line1.getText()+";"+Line2.getText());
}catch(StaleElementReferenceException e) {

	ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	 Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Ref. No.']//div"));
	 Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Ref. No.']//div"));
	ref.sendKeys(Line1.getText()+";"+Line2.getText());
	logger.info("Sent Ref.No numbers to textbox in BulkSections");

}

}

	public void Enter_Text_IN() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[14]//span/span")));

		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[14]//span/span")));




		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[14]//span/span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[14]//span/span"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_Mx() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Document No.']/div")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Document No.']/div")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Document No.']/div"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Document No.']/div"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_Mx2() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Assignment']//tbody//td")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Assignment']//tbody//td")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Assignment']//tbody//td"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Assignment']//tbody//td"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_HC_MX() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Assignment']//tbody//td")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Assignment']//tbody//td")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Assignment']//tbody//td"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Assignment']//tbody//td"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_IN_RC() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Doc Number')]//span")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Doc Number')]//span")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Doc Number')]//span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Doc Number')]//span"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_MY() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Document')]//span")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Document')]//span")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Document')]//span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Document')]//span"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_SHS() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='No doc.']//div")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='No doc.']//div")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='No doc.']//div"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='No doc.']//div"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_FBA() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Document #']//span")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Document #']//span")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Reference']//span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Reference']//span"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_AU_01() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Document No.']//span")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Document No.']//span")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Document No.']//span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Document No.']//span"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_FR() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
         Thread.sleep(4000);
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//following::td[contains(@data-attribute-name,'Doc. Num.')][1]/div)[1]")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//following::td[contains(@data-attribute-name,'Doc. Num.')][1]/div)[1]")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//following::td[contains(@data-attribute-name,'Doc. Num.')][1]/div)[1]"));
			Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//following::td[contains(@data-attribute-name,'Doc. Num.')][1]/div)[1]"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_BR() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='No. Doc.']/div")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='No. Doc.']/div")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='No. Doc.']/div"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='No. Doc.']/div"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_GP_CA() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Doc.')]/div")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Doc.')]/div")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[contains(@data-attribute-name,'Doc.')]/div"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[contains(@data-attribute-name,'Doc.')]/div"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_PT() throws InterruptedException, IOException {

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Doc. No.']/div")));
		WebElement Line2 =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Doc. No.']/div")));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Doc. No.']/div"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Doc. No.']/div"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

public void Enter_Text_HC() throws InterruptedException, IOException {

//*[text()='Bulk Selection']

//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//
//try {
//	Bulk.click();
//}catch(StaleElementReferenceException e) {
//	Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//	Bulk.click();
//}

WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
WebElement Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[5]//span"));
WebElement Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[5]//span"));

try {
	ref.sendKeys(Line1.getText()+";"+Line2.getText());
}catch(StaleElementReferenceException e) {

	ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	 Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[5]//span"));
	 Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[5]//span"));
	ref.sendKeys(Line1.getText()+";"+Line2.getText());
	logger.info("Sent Ref.No numbers to textbox in BulkSections");

}

}

	public void Enter_Text_DES() throws InterruptedException, IOException {

//*[text()='Bulk Selection']

//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//
//try {
//	Bulk.click();
//}catch(StaleElementReferenceException e) {
//	Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//	Bulk.click();
//}

		WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		WebElement Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Reference']//span"));
		WebElement Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Reference']//span"));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Reference']//span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Reference']//span"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

public void Enter_Text_HC_MESA() throws InterruptedException, IOException {

	//*[text()='Bulk Selection']

	//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	//
	//try {
//		Bulk.click();
	//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
	//}

	WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	WebElement Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[contains(@data-attribute-name,'Doc No.')][1]/descendant::span[2]"));
	WebElement Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//td[contains(@data-attribute-name,'Doc No.')][1]/descendant::span[2]"));

	try {
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
	}catch(StaleElementReferenceException e) {

		ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		 Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]//td[contains(@data-attribute-name,'Doc No.')][1]/descendant::span[2]"));
		 Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//td[contains(@data-attribute-name,'Doc No.')][1]/descendant::span[2]"));
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
		logger.info("Sent Ref.No numbers to textbox in BulkSections");

	}

	}

public void Enter_Text_SI() throws InterruptedException, IOException {

	//*[text()='Bulk Selection']

	//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	//
	//try {
//		Bulk.click();
	//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
	//}
	WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
	WebElement ref =	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")));

	WebDriverWait wait1= new WebDriverWait(driver,Duration.ofSeconds(40));
	WebElement Line1 =	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]")));
//	WebElement Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
	WebElement Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span)[1]"));

	try {
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
	}catch(StaleElementReferenceException e) {

		ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		 Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
		 Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span)[1]"));
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
		logger.info("Sent Ref.No numbers to textbox in BulkSections");

	}

	}

	public void Enter_Text_NL() throws InterruptedException, IOException {

		//*[text()='Bulk Selection']

		//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
		//
		//try {
//		Bulk.click();
		//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
		//}
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement ref =	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")));

		WebDriverWait wait1= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[3]//span)[1]")));
//	WebElement Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
		WebElement Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[3]//span)[1]"));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[3]//span)[1]"));
			Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[3]//span)[1]"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}
	public void Enter_Text_IT() throws InterruptedException, IOException {

		//*[text()='Bulk Selection']

		//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
		//
		//try {
//		Bulk.click();
		//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
		//}
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement ref =	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")));

		WebDriverWait wait1= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Doc. Num.']//span")));
//	WebElement Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
		WebElement Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Doc. Num.']//span"));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[@data-attribute-name='Doc. Num.']//span"));
			Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[@data-attribute-name='Doc. Num.']//span"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}

	public void Enter_Text_NL1() throws InterruptedException, IOException {

		//*[text()='Bulk Selection']

		//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
		//
		//try {
//		Bulk.click();
		//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
		//}
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement ref =	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea")));

		WebDriverWait wait1= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Line1 =	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[3]//span)[1]")));
//	WebElement Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
		WebElement Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[3]//span)[1]"));

		try {
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
		}catch(StaleElementReferenceException e) {

			ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
			Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[3]//span)[1]"));
			Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[3]//span)[1]"));
			ref.sendKeys(Line1.getText()+";"+Line2.getText());
			logger.info("Sent Ref.No numbers to textbox in BulkSections");

		}

	}
public void Enter_Text_DE() throws InterruptedException, IOException {

	//*[text()='Bulk Selection']

	//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	//
	//try {
//		Bulk.click();
	//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
	//}

	WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	WebElement Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[6]//span"));
	WebElement Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[6]//span"));

	try {
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
	}catch(StaleElementReferenceException e) {

		ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		 Line1 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[6]//span"));
		 Line2 =	lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[6]//span"));
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
		logger.info("Sent Ref.No numbers to textbox in BulkSections");

	}

	}

public void Enter_Text_GP() throws InterruptedException, IOException {

	//*[text()='Bulk Selection']

	//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	//
	//try {
//		Bulk.click();
	//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
	//}

	WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	WebElement Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
	WebElement Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span)[1]"));

	try {
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
	}catch(StaleElementReferenceException e) {

		ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		 Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
		 Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span)[1]"));
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
		logger.info("Sent Ref.No numbers to textbox in BulkSections");

	}

	}

public void Enter_Text_GP1() throws InterruptedException, IOException {

	//*[text()='Bulk Selection']

	//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	//
	//try {
//		Bulk.click();
	//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
	//}

	WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	WebElement Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[5]//span)[1]"));
	WebElement Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[5]//span)[1]"));

	try {
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
	}catch(StaleElementReferenceException e) {

		ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		 Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[5]//span)[1]"));
		 Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[5]//span)[1]"));
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
		logger.info("Sent Ref.No numbers to textbox in BulkSections");

	}

	}

public void Enter_Text_BR1() throws InterruptedException, IOException {

	//*[text()='Bulk Selection']

	//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	//
	//try {
//		Bulk.click();
	//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
	//}

	WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	WebElement Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
	WebElement Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span)[1]"));

	try {
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
	}catch(StaleElementReferenceException e) {

		ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		 Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[4]//span)[1]"));
		 Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[4]//span)[1]"));
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
		logger.info("Sent Ref.No numbers to textbox in BulkSections");

	}

	}

public void Enter_Text_BR2() throws InterruptedException, IOException {

	//*[text()='Bulk Selection']

	//WebElement Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
	//
	//try {
//		Bulk.click();
	//}catch(StaleElementReferenceException e) {
//		Bulk = lwebDriver.findElement(By.xpath("//*[text()='Bulk Selection']"));
//		Bulk.click();
	//}

	WebElement ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
	WebElement Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[7]//span)[1]"));
	WebElement Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[7]//span)[1]"));

	try {
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
	}catch(StaleElementReferenceException e) {

		ref =	lwebDriver.findElement(By.xpath("//label[contains(text(),'Invoice Numbers')]/following::div//textarea"));
		 Line1 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][1]/td[7]//span)[1]"));
		 Line2 =	lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]/td[7]//span)[1]"));
		ref.sendKeys(Line1.getText()+";"+Line2.getText());
		logger.info("Sent Ref.No numbers to textbox in BulkSections");

	}

	}
public void Delimiter() throws InterruptedException {

	WebElement Delimiter1 =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));

	try {
		Select Delimiter = new Select(Delimiter1);
	 	  Delimiter.selectByVisibleText(";");
	 	    Thread.sleep(5000);
	}catch(StaleElementReferenceException e) {

		Delimiter1 =  	lwebDriver.findElement(By.xpath("//label[contains(text(),'Delimiter')]/following-sibling::div/Select"));
		Select Delimiter = new Select(Delimiter1);
	 	  Delimiter.selectByVisibleText(";");
	 	    Thread.sleep(5000);
	}
}
	public void submit() throws InterruptedException {


		 WebElement Submit =	lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]"));

		 try {
			 Submit.click();
			 Thread.sleep(4000);
			}catch(StaleElementReferenceException e) {
				Submit =	lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]"));
				Submit.click();
				Thread.sleep(4000);
			}
}
	public void Click_on_Attachment() throws InterruptedException {
		SwitchToDefaultFrame();
		logger.info("before");
		WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe);
		System.out.println("Switching to frame...");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
			System.out.println("Switching to frame complete.");
			WebElement ClickOnItemForContactUKRC = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//h2[contains(@id,'headerlabel')]/div)[1]")));
			ClickOnItemForContactUKRC.click();

			JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
			js2.executeScript("window.scrollBy(0,300)");

			ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
			try {
				Thread.sleep(2000);
				BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			} catch (StaleElementReferenceException e) {
				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				ClickOnContactEdit.click();
				Thread.sleep(3000);
			}

			WebElement No_items = lwebDriver.findElement(By.xpath("(//div[text()='No items'])[1]"));


			if (!No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")));
				// BaseClass.WaitforElementToBeClickable(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input"));
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);


			} else if (No_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")).sendKeys("B");
				Thread.sleep(4000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")).sendKeys("Giri");
				Thread.sleep(2000);
				lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")).sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();
				Thread.sleep(5000);

			}
		}
//		WebElement ClickOnItemForContactUKRC1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//body/div[@id='PEGA_HARNESS']/form[1]/div[3]/div[2]/section[1]/div[1]/span[2]/div[1]/span[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[5]/div[2]/div[1]/div[1]")));
//		ClickOnItemForContactUKRC1.click();


		BaseClass.SwitchToDefaultFrame();
		System.out.println("Switching to frame...");
		WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe2);
		System.out.println("Switching to frame...");
		System.out.println("Switching to frame complete.");
		Thread.sleep(5000);
		if(Attachment_Icon.isDisplayed()) {
			Assert.assertTrue(true);
			Attachment_Icon.click();
			logger.info("Click on Attachment Icon");
		}
		else {
			logger.info(" Attachment Icon was not visible on collection page");
			Assert.assertTrue(false);
		}

		lwebDriver.findElement(By.xpath("//span[contains(text(),'File from device')]")).click();
		Thread.sleep(4000);
		logger.info("Selected option for File from device from attachment icon");


	}


	public void Select_file_from_desktop() throws InterruptedException {

		lwebDriver.findElement(By.xpath("//input[contains(@id,'$PpyAttachmentPage$ppxAttachName')]")).sendKeys("D:\\UserData\\z004n9pt\\OneDrive - Siemens AG\\Documents\\AutoIt\\Dev Interface Tests.xlsx");
         logger.info("File was selected from Local System");

		Thread.sleep(5000);
	List<WebElement> Filename =	lwebDriver.findElements(By.xpath("//input[contains(@id,'$PpyAttachmentPage$ppxAttachName')]"));
       if(!Filename.isEmpty()) {
    	   Assert.assertTrue(true);
    	   logger.info("File was uploaded from Disktop to application");

       }
       else {
    	   logger.info("File was  not uploaded from Disktop to application");
    	   Assert.assertTrue(false);
       }


		}

public void Click_on_Attach() throws InterruptedException {

	BaseClass.WaitforVisiblityofElement(Click_Attach);
	Click_Attach.click();
	logger.info("Click on attach button");
	Thread.sleep(5000);
}

public void verify_the_attachment_on_collection() {
	List<WebElement> attachment = lwebDriver.findElements(By.xpath("//h2[contains(text(),'Recent attachments')]/following::img"));

	if(!attachment.isEmpty()) {
		Assert.assertTrue(true);
		logger.info("Attachment was attached on collection");

	}else {
	logger.info("Attachment was not attached on collection");
	Assert.assertTrue(false);
	}

}
public void Verify_Dot_Icon() throws InterruptedException {

	List<WebElement> Doticon = lwebDriver.findElements(By.xpath("//h2[contains(text(),'Recent attachments')]/following::button[contains(@name,'pyCaseAttachmentItem_pyWorkPage.pyAttachment')]/i"));
	for(WebElement Dot:Doticon) {


	if(!Doticon.isEmpty()) {
		Assert.assertTrue(true);
		Dot.click();
		Thread.sleep(4000);
		logger.info("Dot icon was visible on collection");
		logger.info("Clicked on three dot's icon");

	}else {
	logger.info("Dot icong was not visible on collection");
	Assert.assertTrue(false);
	}

}
}
public void Download_the_Attachment() throws InterruptedException {
  WebElement Doticon = lwebDriver.findElement(By.xpath("//span[contains(text(),'Download')]"));
  Doticon.click();

  Thread.sleep(5000);
  logger.info("Clicked on Download option from dot icon");


}
public void Delete_the_Attachment() throws InterruptedException {
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
	List<WebElement> Doticon1 = driver.findElements(By.xpath("//h2[contains(text(),'Recent attachments')]/following::button[contains(@name,'pyCaseAttachmentItem_pyWorkPage.pyAttachment')]/i"));
	for(WebElement Dot:Doticon1) {
try {

	if(!Doticon1.isEmpty()) {
		Assert.assertTrue(true);
		Dot.click();
		Thread.sleep(4000);
		logger.info("Dot icon was visible on collection");
		logger.info("Clicked on three dot's icon");

	}else {
	logger.info("Dot icong was not visible on collection");
	Assert.assertTrue(false);
	}
}catch(StaleElementReferenceException e) {
	 Doticon1 = lwebDriver.findElements(By.xpath("//h2[contains(text(),'Recent attachments')]/following::button[contains(@name,'pyCaseAttachmentItem_pyWorkPage.pyAttachment')]/i"));

	 if(!Doticon1.isEmpty()) {
			Assert.assertTrue(true);
			Dot.click();
			Thread.sleep(4000);
			logger.info("Dot icon was visible on collection");
			logger.info("Clicked on three dot's icon");

		}else {
		logger.info("Dot icong was not visible on collection");
		Assert.assertTrue(false);
		}


}

		try {
			// Wait until the 'Delete' element is clickable
			WebElement Doticon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Delete')]")));
			// Click the 'Delete' element
			Doticon.click();
		} catch (ElementNotInteractableException e) {
			System.out.println("Element is not interactable: " + e.getMessage());
		}
	  Thread.sleep(5000);
	  logger.info("Clicked on Delete option from dot icon");



	  lwebDriver.findElement(By.xpath("//button[contains(text(),'  Submit ')]")).click();
	  Thread.sleep(5000);
	  List<WebElement> attachment = lwebDriver.findElements(By.xpath("//h2[contains(text(),'Recent attachments')]/following::img/following::div[1]//a"));

	  for(WebElement Attachment:attachment  )

		if(Attachment.getText().isEmpty()) {
			Assert.assertTrue(true);
			logger.info("********Attachment has been  Deleted on collection**********");

		}else {
		logger.info("Attachment was not Deleted on collection");
		Assert.assertTrue(false);
		}

	}
}

public void Verify_under_infromation() throws InterruptedException {
    BaseClass.SwitchToDefaultFrame();
    BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
    WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10));
    WebElement informationButton = null;
    
    try {
        informationButton = wait.until(ExpectedConditions.elementToBeClickable(Click_on_Infromation1));
    } catch (TimeoutException e) {
        logger.error("Timeout while waiting for the information button to be clickable");
        return; // Exit the method if the button is not clickable
    }
    
    informationButton.click();
    
    String branchValue = lwebDriver.findElement(By.xpath("(//*[contains(text(),'Branches')])[1]/following-sibling::div//a")).getText();
    
    if (branchValue.equals("No")) {
        logger.info("No Branches Available for this collection");
        Assert.assertTrue(true);
    } else {
        logger.info("Branches are Available for this collection");
        Assert.assertTrue(false);
    }
}


public void Actions() throws InterruptedException {

	//BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	Thread.sleep(5000);

	try {
	Click_on_Actions.click();
	logger.info("Clicked on Actions button");
	}catch(StaleElementReferenceException e) {
		Click_on_Actions=lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		Click_on_Actions.click();
	}
}
public void Select_Customermanagement() throws InterruptedException {
WebElement e =lwebDriver.findElement(By.xpath("//span[contains(text(),'Customer Management')]"));
try {
if(e.isDisplayed()) {
	Assert.assertTrue(true);
	e.click();
	logger.info("Selected customer management from actions drop down");
}else {
	logger.info("We are not able to see customer management option in action dropdown");
	Assert.assertTrue(false);

}
}catch(StaleElementReferenceException e1) {
	e =lwebDriver.findElement(By.xpath("//span[contains(text(),'Customer Management')]"));
	if(e.isDisplayed()) {
		Assert.assertTrue(true);
		e.click();
		logger.info("Selected customer management from actions drop down");
	}else {
		logger.info("We are not able to see customer management option in action dropdown");
		Assert.assertTrue(false);

	}
}
Thread.sleep(5000);

}
public String get_Company_code() {

	BaseClass.WaitforVisiblityofElement(CC);
	String cc = CC.getText();

	return cc;

}
public void Search_with_cc() throws InterruptedException {
	WebElement Available_Customers =lwebDriver.findElement(By.xpath("//h2[contains(text(),'Available Customers')]/following::input[contains(@name,'$PpyWorkPage$pSearchString')]"));
	
	try {
		String CC = this.get_Company_code();
		
		Available_Customers.sendKeys(this.get_Company_code());
	}catch(TimeoutException e) {
		Available_Customers.sendKeys("0000818820");	
	}
	logger.info("Search with same company code");
	lwebDriver.findElement(By.xpath("//button[contains(text(),'Search')]")).click();
	logger.info("Click on search button");
	Thread.sleep(5000);
}

public void Search_with_cc_UK() throws InterruptedException {
	WebElement Available_Customers =lwebDriver.findElement(By.xpath("//h2[contains(text(),'Available Customers')]/following::input[contains(@name,'$PpyWorkPage$pSearchString')]"));
	String CC = this.get_Company_code();
	
	Available_Customers.sendKeys(this.get_Company_code());
	//Available_Customers.sendKeys("0000818820");
	logger.info("Search with same company code");
	lwebDriver.findElement(By.xpath("//button[contains(text(),'Search')]")).click();
	logger.info("Click on search button");
	Thread.sleep(5000);
}
public void Click_add() throws InterruptedException {
		Thread.sleep(5000);

	BaseClass.WaitforVisiblityofElement(Click_on_Add);

	if(Click_on_Add.isDisplayed()) {
		Assert.assertTrue(true);
		Click_on_Add.click();
		logger.info("Clicked on add customer for Merge");
	}
	else {
		logger.info("Did not Click on add for merge");
		Assert.assertTrue(false);
	}
}
public void Verify_mainBranch_Selected_or_not() throws InterruptedException {
	Thread.sleep(3000);

	for(WebElement branch:Checking_main) {

		if(branch.isSelected()) {
			Assert.assertTrue(true);
			logger.info("Main branch was selected on page");
		}
		else {

		}
	}
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		logger.info("Clicked on Submit button");
		Thread.sleep(5000);
		if(lwebDriver.getPageSource().contains(" Fatal error: Unable to load data page D_Customer. Required parameters : CustomerID. cannot be blank")) {
			lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
			logger.info("Clicked on Submit button");
			Thread.sleep(5000);
	}
	}

	public void Verify_mainBranch_Selected_or_not_for_remove() throws InterruptedException {
		Thread.sleep(3000);

		WebElement radio = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersForCustomerManage')][1]/td[1]//input[2]"));
		WebElement radio2 = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersForCustomerManage')][2]/td[1]//input[2]"));


		if(!radio.isSelected()) {
			lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersForCustomerManage')][1]/td[9]//a")).click();
			logger.info("Remove the branch that is not considered the main branch by clicking the remove button");
		}else if(!radio2.isSelected()) {
			lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersForCustomerManage')][2]/td[9]//a")).click();
			logger.info("Remove the branch that is not considered the main branch by clicking the remove button");
		}else {
			logger.info("Main branch was not seleted");
			Assert.assertTrue(false);

		}
	lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	logger.info("Clicked on Submit button");
	Thread.sleep(5000);
	if(lwebDriver.getPageSource().contains(" Fatal error: Unable to load data page D_Customer. Required parameters : CustomerID. cannot be blank")) {
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		Thread.sleep(5000);
	}
	BaseClass.SwitchToDefaultFrame();
}

	public void Verify_mainBranch_Selected_or_not_for_change_branch() throws InterruptedException {
		Thread.sleep(3000);

		WebElement radio = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersForCustomerManage')][1]/td[1]//input[2]"));
		WebElement radio2 = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersForCustomerManage')][2]/td[1]//input[2]"));


		if(!radio.isSelected()) {
			lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersForCustomerManage')][1]/td[1]//input[2]")).click();
			logger.info("There has been a change to the main branch's radio button");
		}else if(!radio2.isSelected()) {
			lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersForCustomerManage')][2]/td[1]//input[2]")).click();
			logger.info("There has been a change to the main branch's radio button");
		}else {
			logger.info("Main branch was not seleted");
			Assert.assertTrue(false);

		}
	lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	logger.info("Clicked on Submit button");
	Thread.sleep(5000);
	if(lwebDriver.getPageSource().contains(" Fatal error: Unable to load data page D_Customer. Required parameters : CustomerID. cannot be blank")) {
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		Thread.sleep(5000);
	}
	BaseClass.SwitchToDefaultFrame();
}
	public void Verify_the_Branchcount_under_information() throws InterruptedException {
	    BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60)); // 60 seconds timeout

		try {
			// Wait for the element to be clickable
			WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[contains(text(),'Collection')]//following::i[7]")));

			// Click the element
			element.click();
		} catch (StaleElementReferenceException e) {
			// Handle StaleElementReferenceException by re-locating the element and clicking again
			WebElement element = driver.findElement(By.xpath("//h1[contains(text(),'Collection')]//following::i[7]"));
			element.click();
		} catch (NoSuchElementException e2) {
			// Handle NoSuchElementException as needed
			// You can log an error or take appropriate action
			e2.printStackTrace(); // This will print the exception stack trace
		}
	    
	    logger.info("Selected information for customer");
	}


public void Verify_the_Branchcount_under_information_HC() throws InterruptedException {
//	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);

BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget0Ifr");


Thread.sleep(3000);


	WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
WebElement Click_on_Infromation2 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//h2[contains(@id,'headerlabel')]/div)[1]")));
	try {
		Click_on_Infromation2.click();
		Thread.sleep(5000);
	}catch(StaleElementReferenceException e) {
		Click_on_Infromation2 =lwebDriver.findElement(By.xpath("(//h2[contains(@id,'headerlabel')]/div)[1]"));
		Click_on_Infromation2.click();
		Thread.sleep(5000);

}catch(NoSuchElementException e2 ) {
	WebElement Click_on_Infromation3 =lwebDriver.findElement(By.xpath("(//h2[contains(@id,'headerlabel')]/div)[1]"));
	Click_on_Infromation3.click();
	Thread.sleep(5000);
}
	logger.info("Selected information for customer");
}
public void Verify_under_infromation_for_branchcount() {

      String Branchvalue = lwebDriver.findElement(By.xpath("(//*[contains(text(),'Branches')])[1]/following-sibling::div//a")).getText();
      if(Branchvalue.equals("2 (view)")) {
    	  Assert.assertTrue(true);
    	  logger.info("Collections have been merged into one collection" );
      }
    	  else {
    		  logger.info("Collections have not  merged into one collection");
    		  Assert.assertTrue(false);
    	  }

      }

public void Verify_under_infromation_for_branchcount_for_remove() {

    String Branchvalue = lwebDriver.findElement(By.xpath("(//*[contains(text(),'Branches')])[1]/following-sibling::div//a")).getText();
    if(Branchvalue.equals("No")) {
  	  Assert.assertTrue(true);
  	  logger.info("******Merged collection has been removed from main branch collection*******" );
    }
  	  else {
  		  logger.info("*****Merged collection have not  removed from main branch collection*******");
  		  Assert.assertTrue(false);
  	  }
       BaseClass.SwitchToDefaultFrame();
    }

public void Validating_customernames() throws InterruptedException {

WebElement Branch =	lwebDriver.findElement(By.xpath("(//*[contains(text(),'Branches')])[1]/following-sibling::div//a"));
Branch.click();
Thread.sleep(3000);

    String Customernumber1 = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersByCollection_pa')][1]//td[@data-attribute-name='Customer Number']//span")).getText();
    String Customernumber2 = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersByCollection_pa')][2]/td[@data-attribute-name='Customer Number']//span")).getText();



    this.ClickOnCustomerSearchOption1();
    this.EnterCustomerNumberInSearchAndClickOnSearchButton1(Customernumber1);
    this.ClickOnCollectionInQUKRC1();
    if(this.Customername().equals(this.Customername())) {
    	Assert.assertTrue(true);
    	logger.info("***Customer name was changed but customer number remains same***");

    }else {
    	logger.info("***Customer name was not changed but customer number remains same***");
    	Assert.assertTrue(false);
    }

    this.ClickOnCustomerSearchOption1();
    this.EnterCustomerNumberInSearchAndClickOnSearchButton1(Customernumber2);
    this.ClickOnCollectionInQUKRC1();
    if(this.Customername().equals(this.Customername())) {
    	Assert.assertTrue(true);
    	logger.info("***Customer name was changed but customer number remains same***");

    }else {
    	logger.info("***Customer name was not changed but customer number remains same***");
    	Assert.assertTrue(false);
    }
BaseClass.SwitchToDefaultFrame();
	}

public void Validating_customernames_HC() throws InterruptedException {


WebElement Branch =	lwebDriver.findElement(By.xpath("(//*[contains(text(),'Branches')])[1]/following-sibling::div//a"));
Branch.click();
Thread.sleep(3000);

    String Customernumber1 = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersByCollection_pa')][1]//td[@data-attribute-name='Customer Number']//span")).getText();
    String Customernumber2 = lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PD_CustomersByCollection_pa')][2]/td[@data-attribute-name='Customer Number']//span")).getText();

    try {
    	BaseClass.SwitchToDefaultFrame();
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(11));
    	lwebDriver.findElement(By.xpath("//a[@id='TABANCHOR']//span[@class='textIn']")).click();
    	lwebDriver.findElement(By.xpath("//td[text()='Close All']")).click();
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    	}catch(StaleElementReferenceException e) {

    	}

    this.ClickOnCustomerSearchOption1();

this.EnterCustomerNumberInSearchAndClickOnSearchButton12(Customernumber1);
//BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget2Ifr");


    this.ClickOnCollectionInQUKRC1();


    if(this.Customername().equals(this.Customername())) {
    	Assert.assertTrue(true);
    	logger.info("***Customer name was changed but customer number remains same***");

    }else {
    	logger.info("***Customer name was not changed but customer number remains same***");
    	Assert.assertTrue(false);
    }
BaseClass.SwitchToDefaultFrame();
try {
	BaseClass.SwitchToDefaultFrame();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(11));
	lwebDriver.findElement(By.xpath("//a[@id='TABANCHOR']//span[@class='textIn']")).click();
	lwebDriver.findElement(By.xpath("//td[text()='Close All']")).click();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}catch(StaleElementReferenceException e) {

	}

    this.ClickOnCustomerSearchOption1();

    this.EnterCustomerNumberInSearchAndClickOnSearchButton12(Customernumber2);
    this.ClickOnCollectionInQUKRC1();


    if(this.Customername_HC().equals(this.Customername1())) {
    	Assert.assertTrue(true);
    	logger.info("***Customer name was changed but customer number remains same***");

    }else {
    	logger.info("***Customer name was not changed but customer number remains same***");
    	Assert.assertTrue(false);
    }
BaseClass.SwitchToDefaultFrame();
	}
public void updateResult(String excellocation, String sheetName, String testCaseName, String testStaus) {
	 try {

		 FileInputStream file = new FileInputStream(new File(excellocation) ) ;
		 XSSFWorkbook workbook = new XSSFWorkbook(file);
		 XSSFSheet sheet = workbook.getSheet(sheetName);
		  int totalRow = sheet.getLastRowNum() +1;
		  for(int i=1;i<totalRow;i++) {
			  XSSFRow r=sheet.getRow(i);
			  String ce=r.getCell(1).getStringCellValue();
			  if(ce.contains(testCaseName)) {
				  r.createCell(2).setCellValue(testStaus);
				  file.close();
				  System.out.println("result updated");
				  FileOutputStream outFile = new FileOutputStream(new File(excellocation));

				  workbook.write(outFile);
				  outFile.close();
			  }

		  }
	 }catch(Exception e) {
		 e.printStackTrace();
	 }

}

public void Verify_the_customername() throws InterruptedException {
	Thread.sleep(5000);
	//String Customername1 = lwebDriver.findElement(By.xpath("//h1[contains(text(),'Collection')]//following::i[7]/following::div[1]/h2/div")).getText();
	System.out.println(Customername());
	if(!this.Customername().equals(equals(Customername()))) {
		Assert.assertTrue(true);
		logger.info("A change has been made to the main branch and the customer name has also been altered.");

	}
	else {
		logger.info("Did not change the main branch for collections");
		Assert.assertTrue(false);
	}
	BaseClass.SwitchToDefaultFrame();
}

public void Click_on_reports_from_mainmenu() throws InterruptedException {
	BaseClass.WaitforVisiblityofElement(Click_on_Reports);
try {
	Click_on_Reports.click();
	Thread.sleep(2000);
}catch(StaleElementReferenceException e) {
	Click_on_Reports = lwebDriver.findElement(By.xpath("//span[contains(text(),'Reports')]"));
	Click_on_Reports.click();
	Thread.sleep(2000);
}
}
public void Click_on_reports_from_mainmenu2() throws InterruptedException {
	Thread.sleep(5000);
try {
	Click_on_Reports.click();
	Thread.sleep(2000);
}catch(StaleElementReferenceException e) {
	Click_on_Reports = lwebDriver.findElement(By.xpath("//span[contains(text(),'Reports')]"));
	Click_on_Reports.click();
	Thread.sleep(2000);
}
}

public void Click_on_reports_from_mainmenu_UK() throws InterruptedException {
	BaseClass.WaitforVisiblityofElement(Click_on_Reports);

	Click_on_Reports.click();
	Thread.sleep(2000);
}
public void Click_on_addcategory() {
	lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
	try {
		Click_addcategory.click();
		logger.info("Clicked on addcategory");
	}catch(NoSuchElementException e) {
		logger.info("addcategory option is not avalible on page", e);
		Assert.assertTrue(false);

	}

}
public void Enter_CategoryName(String CategoryName, String Select_Categorytype) throws InterruptedException {


	WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
	WebElement Dropdown =	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[contains(text(),'Category type')])/following-sibling::div//Select")));
	Select select = new Select(Dropdown);
	select.selectByVisibleText(Select_Categorytype);
logger.info("Selected report] name");
	String names[] = {"Repor_09dfa","Report_3safe","Rept_1bvfy","Report_1_2qdswj","Rort_m_p5dhjk","Repovrt_RRqw_1jhl8","epr_6ayn5","Rersv_Ru_21qbc"};
            String radomnames = names[new Random().nextInt(names.length)];
	WebElement input =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[contains(text(),'Category name')])/following-sibling::div//input")));

	input.clear();
	input.sendKeys(radomnames);
         Thread.sleep(5000);
             String value = input.getAttribute("value");
             logger.info("Selected report type as a public");
             lwebDriver.findElement(By.xpath("(//*[contains(text(),'Category description')])/following-sibling::div//input")).sendKeys(Keys.TAB);
             logger.info("Selected Description name as like report name");
             Thread.sleep(5000);
             lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
             Thread.sleep(10000);
             logger.info("Clicked on submit button");
             if(lwebDriver.getPageSource().contains("This instance already exists")) {

            	 String names1[] = {"Report_RC1","Report_RC1","Report_RC","Report_RC02","Report_RC03","Report_RC061"};
                 String radomnames1 = names[new Random().nextInt(names.length)];
              WebElement Category_name1 =   lwebDriver.findElement(By.xpath("(//*[contains(text(),'Category name')])/following-sibling::div//input"));
              input.clear();
				 input.sendKeys(radomnames);
              Thread.sleep(5000);
                  String value1 = input.getAttribute("value");
                  logger.info("Selected report type as a public");
                  lwebDriver.findElement(By.xpath("(//*[contains(text(),'Category description')])/following-sibling::div//input")).clear();
                  lwebDriver.findElement(By.xpath("(//*[contains(text(),'Category description')])/following-sibling::div//input")).sendKeys(Keys.TAB);
                  logger.info("Selected Description name as like report name");
                  Thread.sleep(5000);
                  lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
                  Thread.sleep(5000);
                  logger.info("Clicked on submit button");

             }
             List<WebElement>	public_reports  =lwebDriver.findElements(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//a[contains(@name,'pzCategoryC')]"));
             for(WebElement Public_reports:public_reports ) {
         		if(Public_reports.equals(value)) {
         			Public_reports.click();
         			logger.info("Clicked on public report");
         			Thread.sleep(5000);
         		}
         	}

      WebElement  searching_for_slim_reports  =lwebDriver.findElement(By.xpath("//a[contains(text(),'All reports')]/following::div[1]//input"));
      searching_for_slim_reports.sendKeys("Slim");
      logger.info("Finding a slim report based on a predefined criteria");
	Thread.sleep(5000);
      searching_for_slim_reports.sendKeys(Keys.ENTER);
      Thread.sleep(5000);
	WebElement click_on_reports =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7')][1]//td[3]//a")));
	 click_on_reports.click();
      logger.info("Clicked on a predefined criteria");
	Thread.sleep(5000);
	lwebDriver.switchTo().defaultContent();
	 Thread.sleep(5000);
	System.out.println("Before waiting for the frame");
	wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id(ItemFrame)));
	System.out.println("After waiting for the frame");
	try {
		// Set up FluentWait with a timeout of 40 seconds and a polling interval of 500 milliseconds
		Wait<WebDriver> fluentWait = new FluentWait<>(driver)
				.withTimeout(Duration.ofSeconds(40))
				.pollingEvery(Duration.ofMillis(500))
				.ignoring(org.openqa.selenium.NoSuchElementException.class);

		By elementLocator = By.xpath("//button[contains(text(),'Actions')]");

		// Wait for the element to be present using FluentWait
		WebElement element = fluentWait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));

		// Perform actions with the element once it's present
		element.click();
	} catch (Exception e) {
		e.printStackTrace();
	}
      logger.info("Clicked on a Actions dropdown");
      lwebDriver.findElement(By.xpath("//span[contains(text(),'Save as')]")).click();
      logger.info("Selected a 'Save as' from dropdown");
      WebElement Tittle =lwebDriver.findElement(By.xpath("//label[contains(text(),'Title')]/following-sibling::div//input"));
      Tittle.clear();
      String names1[] = {"Slim Standard Repo1","Slim Standard Reporting2","Report2","Slimreports","AB","AACC","BCDW_1","RPS","GPS"};
      String radomnames1 = names1[new Random().nextInt(names1.length)];
      Tittle.sendKeys(radomnames1);
      logger.info("The title of the report has been edited");
      Thread.sleep(5000);
      String value1 = Tittle.getAttribute("value");



     WebElement Category =lwebDriver.findElement(By.xpath("//label[contains(text(),'Category')]/following-sibling::div//Select"));
     Select select1 = new Select(Category);
     select1.selectByVisibleText(value);
     logger.info("Selected the public report name in Category");
     Thread.sleep(5000);
     lwebDriver.findElement(By.xpath("//button[contains(text(),'  Submit ')]")).click();
     Thread.sleep(5000);
     logger.info("Click on submit button");
	WebElement Done_editing =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Done editing')]")));
	Done_editing.click();
  //  lwebDriver.findElement(By.xpath("//button[contains(text(),'Done editing')]")).click();
    logger.info("Click on 'cross Icon'");
    Thread.sleep(5000);

 //   lwebDriver.findElement(By.xpath("//img[contains(@name,'pyReportEditorHeader_pyReportConten')]")).click();
	WebElement Cross_button =	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//img[contains(@name,'pyReportEditorHeader_pyReportConten')]")));
	Cross_button.click();
    logger.info("Closed the window");
    logger.info("*** Checking whether the report was saved into the public report****");
    Thread.sleep(5000);
    BaseClass.SwitchToDefaultFrame();
    lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
    WebElement	public_reports1  =lwebDriver.findElement(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//a[contains(text(),'"+value+"')]"));

    public_reports1.click();
    logger.info("Click on public report from 'Public categories'");
    Thread.sleep(10000);
    WebElement	reports_count  =lwebDriver.findElement(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//a[contains(text(),'"+value+"')]/following::td[1]//span/span"));
    System.out.println(reports_count.getText());
    String count = reports_count.getText();
    int i=Integer.parseInt(count);

    if(i!=0) {
    Assert.assertTrue(true);
    logger.info("Report count was visible in public reports section");
    }else {
    	 logger.info("Report was visible in public reports section");
    	 Assert.assertTrue(false);
    }
	}


	public void Enter_CategoryName_SI(String CategoryName, String Select_Categorytype) throws InterruptedException {
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(60));
		WebElement Dropdown =	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[contains(text(),'Category type')])/following-sibling::div//Select")));
		Select select = new Select(Dropdown);
		select.selectByVisibleText(Select_Categorytype);
		logger.info("Selected report] name");
		String names[] = {"Redport_adfsa1","Rdeport_sfa1","Repsort_s1","Report_1fs","Repordt_a4fd","Rdeports_7afl1s","Reportfdt_7sf11","Reportt_svfrda","Report_71dv","Report_sk1db","Report_78bd11","Report_7n1sb","Rert_qk1dlq","Reprt_8zvd1q"};

		String radomnames = names[new Random().nextInt(names.length)];
		WebElement input =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[contains(text(),'Category name')])/following-sibling::div//input")));

		input.clear();
		input.sendKeys(radomnames);
		Thread.sleep(5000);
		String value = input.getAttribute("value");
		logger.info("Selected report type as a public");
		lwebDriver.findElement(By.xpath("(//*[contains(text(),'Category description')])/following-sibling::div//input")).sendKeys(Keys.TAB);
		logger.info("Selected Description name as like report name");
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
		Thread.sleep(10000);
		logger.info("Clicked on submit button");
		if(lwebDriver.getPageSource().contains("This instance already exists")) {

			String names1[] = {"Report_RC1","Report_RC1","Report_RC","Report_RC02","Report_RC03","Report_RC061"};
			String radomnames1 = names[new Random().nextInt(names.length)];
			WebElement Category_name1 =   lwebDriver.findElement(By.xpath("(//*[contains(text(),'Category name')])/following-sibling::div//input"));
			input.clear();
			input.sendKeys(radomnames);
			Thread.sleep(5000);
			String value1 = input.getAttribute("value");
			logger.info("Selected report type as a public");
			lwebDriver.findElement(By.xpath("(//*[contains(text(),'Category description')])/following-sibling::div//input")).clear();
			lwebDriver.findElement(By.xpath("(//*[contains(text(),'Category description')])/following-sibling::div//input")).sendKeys(Keys.TAB);
			logger.info("Selected Description name as like report name");
			Thread.sleep(5000);
			lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
			Thread.sleep(5000);
			logger.info("Clicked on submit button");

		}
//		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		List<WebElement>	public_reports =		wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//a[contains(@name,'pzCategoryC')]")));
//		List<WebElement>	public_reports  =lwebDriver.findElements(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//a[contains(@name,'pzCategoryC')]"));
		for(WebElement Public_reports:public_reports ) {
			if(Public_reports.equals(value)) {
				Public_reports.click();
				logger.info("Clicked on public report");
				Thread.sleep(5000);
			}
		}

		WebElement  searching_for_slim_reports  =lwebDriver.findElement(By.xpath("//a[contains(text(),'All reports')]/following::div[1]//input"));
		searching_for_slim_reports.sendKeys("Slim");
		logger.info("Finding a slim report based on a predefined criteria");
		Thread.sleep(5000);
		searching_for_slim_reports.sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		WebElement click_on_reports =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7')][1]//td[3]//a")));
		click_on_reports.click();
		logger.info("Clicked on a predefined criteria");
		Thread.sleep(5000);
		lwebDriver.switchTo().defaultContent();
		Thread.sleep(5000);
		System.out.println("Before waiting for the frame");
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id(ItemFrame)));
		System.out.println("After waiting for the frame");
		try {
			// Set up FluentWait with a timeout of 40 seconds and a polling interval of 500 milliseconds
			Wait<WebDriver> fluentWait = new FluentWait<>(driver)
					.withTimeout(Duration.ofSeconds(40))
					.pollingEvery(Duration.ofMillis(500))
					.ignoring(org.openqa.selenium.NoSuchElementException.class);

			By elementLocator = By.xpath("//button[contains(text(),'Actions')]");

			// Wait for the element to be present using FluentWait
			WebElement element = fluentWait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));

			// Perform actions with the element once it's present
			element.click();
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.info("Clicked on a Actions dropdown");
		lwebDriver.findElement(By.xpath("//span[contains(text(),'Save as')]")).click();
		logger.info("Selected a 'Save as' from dropdown");
		WebElement Tittle =lwebDriver.findElement(By.xpath("//label[contains(text(),'Title')]/following-sibling::div//input"));
		Tittle.clear();
		String names1[] = {"Slim Standard Repo1","Slim Standard Reporting2","Report2","Slimreports","AB","AACC","BCDW_1","RPS","GPS"};
		String radomnames1 = names1[new Random().nextInt(names1.length)];
		Tittle.sendKeys(radomnames1);
		logger.info("The title of the report has been edited");
		Thread.sleep(5000);
		String value1 = Tittle.getAttribute("value");



		WebElement Category =lwebDriver.findElement(By.xpath("//label[contains(text(),'Category')]/following-sibling::div//Select"));
		Select select1 = new Select(Category);
		select1.selectByVisibleText(value);
		logger.info("Selected the public report name in Category");
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Submit ')]")).click();
		Thread.sleep(5000);
		logger.info("Click on submit button");
		lwebDriver.findElement(By.xpath("//button[contains(text(),'Done editing')]")).click();
		logger.info("Click on 'Done editing'");
		Thread.sleep(5000);
		lwebDriver.findElement(By.xpath("//img[contains(@name,'pyReportEditorHeader_pyReportConten')]")).click();
		logger.info("Closed the window");
		logger.info("*** Checking whether the report was saved into the public report****");
		Thread.sleep(5000);
		BaseClass.SwitchToDefaultFrame();
		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
		WebElement	public_reports1  =lwebDriver.findElement(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//a[contains(text(),'"+value+"')]"));

		public_reports1.click();
		logger.info("Click on public report from 'Public categories'");
		Thread.sleep(10000);
		WebElement	reports_count  =lwebDriver.findElement(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//a[contains(text(),'"+value+"')]/following::td[1]//span/span"));
		System.out.println(reports_count.getText());
		String count = reports_count.getText();
		int i=Integer.parseInt(count);

		if(i!=0) {
			Assert.assertTrue(true);
			logger.info("Report count was visible in public reports section");
		}else {
			logger.info("Report was not visible in public reports section");
			Assert.assertTrue(false);
		}
	}
public void copy_reportName() throws InterruptedException {


	WebElement First_report_count = lwebDriver.findElement(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//tr[contains(@id,'$PD_pzReportBrowser7$ppzRBAllCategori')][1]//span/span"));

	String reportcount =First_report_count.getText();
	System.out.println(reportcount);

	lwebDriver.findElement(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7.p')][1]//button[contains(@name,'pzRBShortcutsGrid7_D_pzReportBrowser7.pzRBShortcuts(1)_196')]")).click();
	Thread.sleep(3000);
	WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));

	lwebDriver.findElement(By.xpath("//span[text()='Copy']")).click();
	logger.info("Click on copy option");

	// Locate the cancel button using XPath
//	WebElement cancelButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'  Cancel ')]")));
//
//	// Use JavaScript to click on the cancel button
//	JavascriptExecutor js = (JavascriptExecutor) driver;
//	js.executeScript("arguments[0].click();", cancelButton);

	// Log the click action

	WebElement First_report_name = lwebDriver.findElement(By.xpath("//label[contains(text(),'Report category')]/following-sibling::div//Select/option[3]"));
	String reportname =First_report_name.getText();
	//System.out.println(reportname);
	First_report_name.click();
     Thread.sleep(5000);
	WebElement sumbit = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'  Submit ')]")));

     Thread.sleep(6000);

     logger.info("Selected public report from dropdown");
     logger.info("Click on Submit");
     WebElement First_report_count2 = lwebDriver.findElement(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//tr[contains(@id,'$PD_pzReportBrowser7$ppzRBAllCategori')][1]//span/span"));

 	String reportcount2 =First_report_count2.getText();
 	System.out.println(First_report_count2);

 	if(First_report_count2.equals(reportcount2)) {
 		Assert.assertTrue(false);
 		logger.info("Report was not copied to another report");
 	}else {
 		logger.info("The report was successfully completed and copied to another report");
 		Assert.assertTrue(true);
 	}


}

public void Click_Scheduled() throws InterruptedException {
	BaseClass.SwitchToDefaultFrame();
	lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));

	WebElement First_report_count = lwebDriver.findElement(By.xpath("//h2[contains(text(),'Public categories')]/following::table[@id='EXPAND-OUTERFRAME']//tr[contains(@id,'$PD_pzReportBrowser7$ppzRBAllCategori')][1]//span/span"));

	String reportcount =First_report_count.getText();
	//System.out.println(reportcount);

	lwebDriver.findElement(By.xpath("    //tr[contains(@base_ref,'D_pzReportBrowser7.pzRBShortcuts(1)')] //button[contains(@name,'pzRBShortcutsGrid7_D_pzReportBrowser7.')]")).click();
	Thread.sleep(3000);
logger.info("Cliked on setting icon on reports");
System.out.println(lwebDriver.getTitle());
	WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40));
	WebElement Cliked_on_Schedule =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[text()='Schedule']")));
	Cliked_on_Schedule.click();
	logger.info("Cliked on Schedule button");
    Set<String> s=lwebDriver.getWindowHandles();
    for(String i:s) {
    	String t=lwebDriver.switchTo().window(i).getTitle();
    	//System.out.println(t);
    }
            Thread.sleep(5000);

            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//h2[contains(text(),'Task Definition')]/following::label[text()='Task Name']/following::td[1]//input")));

			WebElement Task_Definition = lwebDriver.findElement(By.xpath("//h2[contains(text(),'Task Definition')]/following::label[text()='Task Name']/following::td[1]//input"));
			WebElement Category_name = lwebDriver.findElement(By.xpath("//h2[contains(text(),'Task Definition')]/following::label[text()='Category name']/following::td[1]//span"));

		String TaskName =	Task_Definition.getAttribute("value");

		     if(!TaskName.isEmpty() && !Category_name.getText().isEmpty() ) {
		    	 Assert.assertTrue(true);
		    	 logger.info("Task Definition was visibled on Schedule page");

		     }else {
		    	 logger.info("Task Definition was not visibled on Schedule page");
		    	 Assert.assertTrue(false);
		     }

		     if(!Category_name.getText().isEmpty() ) {
		    	 Assert.assertTrue(true);
		    	 logger.info("Task Category_name was visibled on Schedule page");

		     }else {
		    	 logger.info("Task Category_name was not visibled on Schedule page");
		    	 Assert.assertTrue(false);
		     }

		//lwebDriver.findElement(By.xpath("(//*[contains(text(),'Submit')])[2]")).click();
		Thread.sleep(5000);

		}
public void  Set_Task_Output_Processing(String select_format_report) throws InterruptedException {
	Thread.sleep(5000);
	WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40));
	WebElement OutputFile_Format =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//select[contains(@name,'$PpyWorkPage$ppyTaskOutputProcessing$ppyOutputType')]")));
//	WebElement OutputFile_Format =lwebDriver.findElement(By.xpath("//h2[contains(text(),'Task Output Processing')]/following::label[contains(text(),'Output File Format')]/following::td[1]//select"));
	 Select Format = new Select(OutputFile_Format);
	 Format.selectByVisibleText(select_format_report);
	 Thread.sleep(5000);
	 logger.info("Selected OutputFile_Format for report like PDF, excel");
	 WebElement Send_Notifications_to_the_following_users =lwebDriver.findElement(By.xpath("(//input[contains(@name,'$PpyWorkPage$ppyTaskOutputProcessing$ppySendNotification')])[2]" ));

	 if(Send_Notifications_to_the_following_users.isSelected()) {
		Assert.assertTrue(true);
		logger.info("Send Notifications to the following users check box was selected on Schedule page");
	 }else {
		 Send_Notifications_to_the_following_users.click();
		 logger.info("Sen Notifications to the following users check box was selected on Schedule page");
	 }



}
public void Send_Notifications_to_the_following_users() throws Exception {
		Thread.sleep(5000);
	WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40));
	WebElement Icon =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@class='iconInsert']")));
	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Icon);
	Icon.click();
	WebElement Enter_ZID = lwebDriver.findElement(By.xpath("//input[contains(@name,'$PpyWorkPage$ppyTaskOutputProcessing$ppySu')][1]"));
	String Value = Enter_ZID.getAttribute("value");
	if(Value.isEmpty()) {
		Enter_ZID.sendKeys("Z004N9PT");
		Thread.sleep(4000);
		Enter_ZID.sendKeys(Keys.ARROW_LEFT);
		Enter_ZID.sendKeys(Keys.ENTER);
		logger.info("Enter user ZID for notification.");
	}else {
		WebElement ZID =	lwebDriver.findElement(By.xpath("(//input[contains(@name,'$PpyWorkPage$ppyTaskOutputProcessing$ppySu')])[2]"));
		Thread.sleep(4000);
		ZID.sendKeys("Z004N4XR");
		ZID.sendKeys(Keys.ARROW_LEFT);
		ZID.sendKeys(Keys.ENTER);
		logger.info("Enter user ZID for notification.");
	}

	lwebDriver.findElement(By.xpath("(//*[contains(text(),'Submit')])[2]")).click();
	Thread.sleep(6000);
	logger.info("Click on submit button");
	try {
		if(lwebDriver.getPageSource().contains("Enter a value beyond the current date and time")) {

			WebElement Time_of_Day = lwebDriver.findElement(By.xpath("//*[contains(text(),'Time Of Day')]/following-sibling::div//Select"))	;
			Select select = new Select(Time_of_Day);
			select.selectByVisibleText("08 PM");
			Thread.sleep(3000);
			lwebDriver.findElement(By.xpath("//a[@class='iconInsert']")).click();
			lwebDriver.findElement(By.xpath("(//*[contains(text(),'Submit')])[2]")).click();
			logger.info("Click on submit button");
		}
	}catch(NullPointerException e) {
		System.out.println(e);
	}
	Thread.sleep(6000);
	Set<String> s=lwebDriver.getWindowHandles();
	for(String i:s) {
		String t=lwebDriver.switchTo().window(i).getTitle();
		System.out.println(t);
	}
	}


	public void Send_Notifications_to_the_following_users_HC_US() throws Exception {
		Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Icon = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@class='iconInsert']")));

		// Scroll to the element
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Icon);
		Icon.click();
		Thread.sleep(3000);

		// Optionally add a small pause to ensure the scroll has completed
		WebElement Enter_ZID = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@name,'$PpyWorkPage$ppyTaskOutputProcessing$ppySu')][1]")));
		String Value = Enter_ZID.getAttribute("value");

		if(Value.isEmpty()) {
			WebElement Enter_ZID1 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@name,'$PpyWorkPage$ppyTaskOutputProcessing$ppySu')][1]")));
			Enter_ZID1.sendKeys("Z004N4XR");
			Thread.sleep(4000);
			Enter_ZID1.sendKeys(Keys.ARROW_LEFT);
			Enter_ZID1.sendKeys(Keys.ENTER);
			logger.info("Enter user ZID for notification.");
		}else {
			WebElement ZID =	lwebDriver.findElement(By.xpath("(//input[contains(@name,'$PpyWorkPage$ppyTaskOutputProcessing$ppySu')])[2]"));
			Thread.sleep(4000);
			ZID.sendKeys("Z004N4XR");
			ZID.sendKeys(Keys.ARROW_LEFT);
			ZID.sendKeys(Keys.ENTER);
			logger.info("Enter user ZID for notification.");
		}
		WebElement submit = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[contains(text(),'Submit')])[2]")));
		submit.click();
		Thread.sleep(6000);
		logger.info("Click on submit button");
		try {
			if(lwebDriver.getPageSource().contains("Enter a value beyond the current date and time")) {

				WebElement Time_of_Day = lwebDriver.findElement(By.xpath("//*[contains(text(),'Time Of Day')]/following-sibling::div//Select"))	;
				Select select = new Select(Time_of_Day);
				select.selectByVisibleText("08 PM");
				Thread.sleep(3000);
				lwebDriver.findElement(By.xpath("//a[@class='iconInsert']")).click();
				lwebDriver.findElement(By.xpath("(//*[contains(text(),'Submit')])[2]")).click();
				logger.info("Click on submit button");
			}
		}catch(NullPointerException e) {
			System.out.println(e);
		}
		Thread.sleep(6000);
		Set<String> s=lwebDriver.getWindowHandles();
		for(String i:s) {
			String t=lwebDriver.switchTo().window(i).getTitle();
			System.out.println(t);
		}
	}



	public void Verify_Report_Scheduled_or_not() throws InterruptedException {
      System.out.println(lwebDriver.getTitle());



	    BaseClass.SwitchToDefaultFrame();
		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
	Thread.sleep(5000);
	WebElement text =lwebDriver.findElement(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7.pzRBShortcuts(1)')]//td[4]//label"));
System.out.println(text.getText());
	if(text.getText().equals("Scheduled and subscribed")) {
		Assert.assertTrue(true);
		logger.info("Report have been Scheduled and subscribed");
	}else {
		logger.info("Report have not  Scheduled and subscribed");
		Assert.assertTrue(false);
	}
	}
	public void Unsubscribe() throws InterruptedException {

	lwebDriver.findElement(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7.pzRBShortcuts(1)')] //button[contains(@name,'pzRBShortcutsGrid7_D_pzReportBrowser7.')]")).click();
	Thread.sleep(4000);
		WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement Unsubscribe =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Unsubscribe')]")));
		Unsubscribe.click();
		//span[contains(text(),'Unsubscribe')]
	logger.info("Selct  Unsubscribe option from setting icon");
	Thread.sleep(4000);


	Set<String> s=lwebDriver.getWindowHandles();
	for(String i:s) {
		String t=lwebDriver.switchTo().window(i).getTitle();
		//System.out.println(t);
	}
		WebElement Unsubscribea =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//*[contains(text(),'Unsubscribe')])[2]")));
		Unsubscribea.click();
		logger.info("Click on Unsubscribe");
		Thread.sleep(4000);
		Set<String> s1=lwebDriver.getWindowHandles();
		for(String i1:s1) {
			String t1=lwebDriver.switchTo().window(i1).getTitle();
		//	System.out.println(t1);
	}
		}


	public void Verify_Report_UnScheduled_or_not() throws InterruptedException {
	   //   System.out.println(lwebDriver.getTitle());



		    BaseClass.SwitchToDefaultFrame();
			lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
		Thread.sleep(5000);
		WebElement text =lwebDriver.findElement(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7.pzRBShortcuts(1)')]//td[4]//label"));
	//System.out.println(text.getText());
		if(text.getText().equals("Scheduled but not subscribed")) {
			Assert.assertTrue(true);
			logger.info("*****Report have been unsubscribe and subscribed*****");
		}else {
			logger.info("*****Report Did not Unsubscribe.*******");
			Assert.assertTrue(false);
		}

}
	public void Delete_for_report() throws InterruptedException {

	List<WebElement> Reports = lwebDriver.findElements(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7')]"));
	try {
	int Reportcount= Reports.size();
	System.out.println(Reportcount);
	}catch(StaleElementReferenceException e) {
		Reports = lwebDriver.findElements(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7')]"));
		int Reportcount= Reports.size();
		System.out.println(Reportcount);
	}


		WebElement Icon = 	lwebDriver.findElement(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7.pzRBShortcuts(1)')] //button[contains(@name,'pzRBShortcutsGrid7_D_pzReportBrowser7.')]"));

		try {
			Icon.click();
			Thread.sleep(3000);
			}catch(StaleElementReferenceException e) {
				Icon = 	lwebDriver.findElement(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7.pzRBShortcuts(1)')] //button[contains(@name,'pzRBShortcutsGrid7_D_pzReportBrowser7.')]"));
				Icon.click();
				Thread.sleep(3000);
			}



		WebElement Delete =lwebDriver.findElement(By.xpath("//span[contains(text(),'Delete')]"));

		try {
			Delete.click();
			Thread.sleep(3000);


			}catch(StaleElementReferenceException e) {
				Delete =lwebDriver.findElement(By.xpath("//span[contains(text(),'Delete')]"));
				Delete.click();
				Thread.sleep(3000);

			}



		Thread.sleep(3000);
		logger.info("*****Click on Delete option from Icon menu******");


		WebElement Submit =lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]"));

		try {
			Submit.click();
			Thread.sleep(3000);
			if(lwebDriver.getPageSource().contains("pzRBShortcuts: Delete record failed: Fail: Database-Authorization-NoDeleteAccess.")) {

	        	  logger.info("Unable to delete the report due to Fail: Database-Authorization-NoDeleteAccess.");
	        	  Assert.assertTrue(true);
	           }
			}catch(StaleElementReferenceException e) {
				Submit =lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]"));
				Submit.click();
				Thread.sleep(3000);
				if(lwebDriver.getPageSource().contains("pzRBShortcuts: Delete record failed: Fail: Database-Authorization-NoDeleteAccess.")) {

		        	  logger.info("Unable to delete the report due to Fail: Database-Authorization-NoDeleteAccess.");
		        	  Assert.assertTrue(true);
		           }
			}
		Thread.sleep(5000);
		logger.info("*****Click on submit for Delete report******");
		List<WebElement> Afterdeletereport = lwebDriver.findElements(By.xpath("//tr[contains(@id,'$PD_pzReportBrowser7$ppzRBS')]"));
		int Afterdeletereportcount= Reports.size();

			System.out.println(Afterdeletereportcount);

			if(Reports!=Afterdeletereport) {
			Assert.assertTrue(true);
			logger.info("*****Report has been deleted******");
			}else {
				logger.info("*****Report have not  deleted******");
				Assert.assertTrue(true);


	}
			BaseClass.SwitchToDefaultFrame();
}
	public void Click_on_Addreport() {
		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
		BaseClass.WaitforVisiblityofElement(Click_addreport);
		try {
			Click_addreport.click();
			logger.info("Clicked on addcategory");
		}catch(NoSuchElementException e) {
			logger.info("addcategory option is not avalible on page", e);
			Assert.assertTrue(false);

		}
	}
	public void Select_Casetype_and_reporttype_submit() throws InterruptedException {
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[contains(text(),'Case type')])[1]/following-sibling::div//Select")));
	WebElement dropdown =	lwebDriver.findElement(By.xpath("(//*[contains(text(),'Case type')])[1]/following-sibling::div//Select"));
		Select Casetype = new Select(dropdown);
		Casetype.selectByIndex(4);

		WebDriverWait wait1= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement dropdown1	=	wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//*[contains(text(),'Report type')])[1]/following-sibling::div//Select")));

	Select Casetype1 = new Select(dropdown1);
	Casetype1.selectByVisibleText("List");
logger.info("Create new report page was open");
logger.info("Selected Case type from dropdown on Create new report page");
logger.info("Selected report type from dropdown on Create new report page");
	lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]")).click();
	logger.info("Click on Submit button");
	Thread.sleep(5000);
BaseClass.SwitchToDefaultFrame();
	}

	public void Search_in_DataExplorer() throws InterruptedException {
		Thread.sleep(5000);
		BaseClass.SwitchToDefaultFrame();
             try {
             logger.info("Before");
			BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
				 logger.info("After");
			FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
		            .withTimeout(Duration.ofSeconds(30))
		            .pollingEvery(Duration.ofSeconds(5))
		            .ignoring(NoSuchElementException.class);

		        WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//label[contains(text(),'Data Explorer')]/following::input[5])[1]")));
		        
			
    			logger.info("Searching column name in Data Explorer box");
    			element.sendKeys("Customer ID");
    			element.sendKeys(Keys.ENTER);
    			logger.info("Press 'enter button' on box");
    			Thread.sleep(5000);

             }catch(NoSuchFrameException e) {
            	 BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
            	 
            	 

            	 FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
     		            .withTimeout(Duration.ofSeconds(30))
     		            .pollingEvery(Duration.ofSeconds(5))
     		            .ignoring(NoSuchElementException.class);

     		        WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//label[contains(text(),'Data Explorer')]/following::input[5])[1]")));
     		        
     			
         			logger.info("Searching column name in Data Explorer box");
         			element.sendKeys("Customer ID");
         			element.sendKeys(Keys.ENTER);
         			logger.info("Press 'enter button' on box");
         			Thread.sleep(5000);
            			}catch(TimeoutException e) {
            				
            	         lwebDriver.navigate().refresh();
            	         
            	         FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
            			            .withTimeout(Duration.ofSeconds(30))
            			            .pollingEvery(Duration.ofSeconds(5))
            			            .ignoring(NoSuchElementException.class);

            			        WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//label[contains(text(),'Data Explorer')]/following::input[5])[1]")));
            			        
            				
            	    			logger.info("Searching column name in Data Explorer box");
            	    			element.sendKeys("Customer ID");
            	    			element.sendKeys(Keys.ENTER);
            	    			logger.info("Press 'enter button' on box");
            	    			Thread.sleep(5000);
            			}
	}
			

	public String value_for_inputbox() throws InterruptedException {
		try {
		String value = Search_box.getAttribute("value");
		System.out.println(value);
		return value;
		}catch(StaleElementReferenceException e) {
			Search_box =	lwebDriver.findElement(By.xpath("//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppySearchForProperty')]"));
			String value = Search_box.getAttribute("value");
			System.out.println(value);
			return value;
		}
	}
	public void Drag_and_drop() throws InterruptedException {

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement sourceelement =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//ul[@id='gridNode']//label[contains(text(),'"+this.value_for_inputbox()+"')]")));

	//	WebElement sourceelement = lwebDriver.findElement(By.xpath("//ul[@id='gridNode']//label[contains(text(),'"+this.value_for_inputbox()+"')]"));
		WebElement Desti = lwebDriver.findElement(By.xpath("//div[contains(text(),' Drop column to add Filter ')]"));
		Actions act = new Actions(lwebDriver);

		act.dragAndDrop(sourceelement, Desti).perform();
		Thread.sleep(5000);

		WebElement Editfilter = lwebDriver.findElement(By.xpath("//h2[contains(text(),'Edit filter')]"));

		if(!Editfilter.getText().isEmpty()) {
			Assert.assertTrue(true);
			logger.info("Column have been drag and drop from Data Explorer to Drop column to add Filter page");

		}else {
			logger.info("Column was not drag and drop for filter box");
			Assert.assertTrue(true);
		}
		lwebDriver.findElement(By.xpath("//h2[contains(text(),'Edit filter')]/following::*[text()='Cancel']")).click();

	}
	public void Click_on_DoneEDIT() {
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		 wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[contains(text(),'Done editing')]")));
		 lwebDriver.findElement(By.xpath("//button[contains(text(),'Done editing')]")).click();
		 logger.info("Click on Done editing button on page");
	}
	public void setup_Tittle(String Tittleforreport) throws InterruptedException {
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
	WebElement Tittle =	 wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyReportTitle')])[1]")));
		Tittle.clear();
		Thread.sleep(3000);
	WebElement	input_box = driver.findElement(By.xpath("//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyReportTitle')]"));


	input_box.sendKeys(Tittleforreport);
logger.info("Entered Tittle for report on Save report as popup");



	}
	public String Value_Tittle() {
		BaseClass.WaitforVisiblityofElement(Tittle);
     try {
	  String valueTittle = Tittle.getAttribute("value");
	  System.out.print(valueTittle);

	  return valueTittle;
     }catch(StaleElementReferenceException e) {
    	 Tittle = lwebDriver.findElement(By.xpath("//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyReportTitle')]"));
    	 String valueTittle = Tittle.getAttribute("value");
   	  System.out.print(valueTittle);

   	  return valueTittle;
     }

	}
	public void Set_Description() throws InterruptedException {
		 lwebDriver.findElement(By.xpath("//*[contains(text(),'Description')]/following-sibling::div//textarea")).sendKeys(this.Value_Tittle());
		 lwebDriver.findElement(By.xpath("//button[contains(text(),'  Submit ')]")).click();
		 Thread.sleep(3000);
		 logger.info("Entered Description for report on Save report as popup & Submit");



	}
	public void Click_on_Actions_and_Select_Report_details() throws InterruptedException {
		logger.info("***Selecting an action from the dropdown menu and validating it***");
//		BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Actions')]"));
		Thread.sleep(5000);
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
	WebElement Actions_drop =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Actions')]")));
		Thread.sleep(5000);
		 Actions_drop.click();
		logger.info("***Selected an action from the dropdown menu and validating it***");
		 logger.info("Click on Actions button");
		WebElement Report =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Report details')]")));
		Report.click();
		 logger.info("Click on Report details from Actions dropdown");
		 Thread.sleep(3000);
	WebElement Description =	 lwebDriver.findElement(By.xpath("//span[contains(text(),'Description')]/following-sibling::div/span"));
	WebElement Category =	 lwebDriver.findElement(By.xpath("//span[contains(text(),'Category')]/following-sibling::div/span"));
	WebElement Report_Key =	 lwebDriver.findElement(By.xpath("//span[contains(text(),'Report key')]/following-sibling::div/span"));

	if(!Description.getText().isEmpty() && !Category.getText().isEmpty() && !Report_Key.getText().isEmpty()) {
		Assert.assertTrue(true);
		logger.info(" Report details was visibled on page");

	}else {
		logger.info(" Report details was Mismatched  on page");
		Assert.assertTrue(false);
	}
		WebElement cancelButton = driver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]"));

		// Use JavaScript to click on the cancel button
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", cancelButton);

		// Log the click action
		logger.info("Clicked on cancel button");


	}

	public void Click_on_Actions_and_Select_Summarize_details() throws InterruptedException {
		//BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Actions')]"));
		Thread.sleep(5000);
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(60));
		WebElement Action =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Actions')]")));
	try {
		Action.click();
		 logger.info("Click on Actions button");
	}catch(StaleElementReferenceException e) {
		WebElement Action2 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Actions')]")));
		Action2.click();
		 logger.info("Click on Actions button");
	}
		WebElement Summarz =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Summarize')]")));
	try {
		Summarz.click();
		 logger.info("Click on Summarize from Actions dropdown");
	}catch(StaleElementReferenceException e) {

		WebElement Summarzz =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Summarize')]")));
		Summarzz.click();

		logger.info("Click on Summarize from Actions dropdown");
	}

		 Thread.sleep(3000);
	WebElement Label =	 lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBo')][1]/td[2]"));
	WebElement EnteredOn =	 lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBo')][3]/td[2]"));
	WebElement Checks =	 lwebDriver.findElement(By.xpath("//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBody$ppy')]"));
try {
	if(!Label.getText().isEmpty() && !EnteredOn.getText().isEmpty() && !EnteredOn.getText().isEmpty()) {
		Assert.assertTrue(true);
		logger.info(" Summarize and Sort details was visibled on page");

	}else {
		logger.info(" Summarize and Sort details was Mismatched  on page");
		Assert.assertTrue(false);
	}
}catch(StaleElementReferenceException e) {
	 Label =	 lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBo')][1]/td[2]"));
	 EnteredOn =	 lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBo')][3]/td[2]"));
	 Checks =	 lwebDriver.findElement(By.xpath("//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBody$ppy')]"));
	 if(!Label.getText().isEmpty() && !EnteredOn.getText().isEmpty() && !EnteredOn.getText().isEmpty()) {
			Assert.assertTrue(true);
			logger.info(" Summarize and Sort details was visibled on page");

		}else {
			logger.info(" Summarize and Sort details was Mismatched  on page");
			Assert.assertTrue(false);
		}

	}
	 lwebDriver.findElement(By.xpath("(//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBody$ppy')]/following::*[contains(text(),'Cancel')])[1]")).click();
     Thread.sleep(5000);


	}

	public void Click_on_Actions_and_Select_Report_details2() throws InterruptedException {
		logger.info("***Selecting an action from the dropdown menu and validating it***");
//		BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Actions')]"));
		Thread.sleep(5000);
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		WebElement Actions_drop =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Actions')]")));
		Thread.sleep(5000);
		Actions_drop.click();
		logger.info("***Selected an action from the dropdown menu and validating it***");
		logger.info("Click on Actions button");
		WebElement Report =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Dettagli report')]")));
		Report.click();
		logger.info("Click on Report details from Actions dropdown");
		Thread.sleep(3000);
		WebElement Description =	 lwebDriver.findElement(By.xpath("//span[contains(text(),'Description')]/following-sibling::div/span"));
		WebElement Category =	 lwebDriver.findElement(By.xpath("//span[contains(text(),'Category')]/following-sibling::div/span"));
		WebElement Report_Key =	 lwebDriver.findElement(By.xpath("//span[contains(text(),'Report key')]/following-sibling::div/span"));

		if(!Description.getText().isEmpty() && !Category.getText().isEmpty() && !Report_Key.getText().isEmpty()) {
			Assert.assertTrue(true);
			logger.info(" Report details was visibled on page");

		}else {
			logger.info(" Report details was Mismatched  on page");
			Assert.assertTrue(false);
		}
		lwebDriver.findElement(By.xpath("//button[contains(text(),'  Cancel ')]")).click();
		logger.info("Clicked on cancel button");


	}

	public void Click_on_Actions_and_Select_Summarize_details2() throws InterruptedException {
		//BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Actions')]"));
		Thread.sleep(5000);
		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(60));
		WebElement Action =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Actions')]")));
		try {
			Action.click();
			logger.info("Click on Actions button");
		}catch(StaleElementReferenceException e) {
			WebElement Action2 =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'Actions')]")));
			Action2.click();
			logger.info("Click on Actions button");
		}
		WebElement Summarz =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Summarize')]")));
		try {
			Summarz.click();
			logger.info("Click on Summarize from Actions dropdown");
		}catch(StaleElementReferenceException e) {

			WebElement Summarzz =	wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[contains(text(),'Summarize')]")));
			Summarzz.click();

			logger.info("Click on Summarize from Actions dropdown");
		}

		Thread.sleep(3000);
		WebElement Label =	 lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBo')][1]/td[2]"));
		WebElement EnteredOn =	 lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBo')][3]/td[2]"));
		WebElement Checks =	 lwebDriver.findElement(By.xpath("//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBody$ppy')]"));
		try {
			if(!Label.getText().isEmpty() && !EnteredOn.getText().isEmpty() && !EnteredOn.getText().isEmpty()) {
				Assert.assertTrue(true);
				logger.info(" Summarize and Sort details was visibled on page");

			}else {
				logger.info(" Summarize and Sort details was Mismatched  on page");
				Assert.assertTrue(false);
			}
		}catch(StaleElementReferenceException e) {
			Label =	 lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBo')][1]/td[2]"));
			EnteredOn =	 lwebDriver.findElement(By.xpath("//tr[contains(@id,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBo')][3]/td[2]"));
			Checks =	 lwebDriver.findElement(By.xpath("//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBody$ppy')]"));
			if(!Label.getText().isEmpty() && !EnteredOn.getText().isEmpty() && !EnteredOn.getText().isEmpty()) {
				Assert.assertTrue(true);
				logger.info(" Summarize and Sort details was visibled on page");

			}else {
				logger.info(" Summarize and Sort details was Mismatched  on page");
				Assert.assertTrue(false);
			}

		}
		lwebDriver.findElement(By.xpath("(//input[contains(@name,'$PpyReportContentPage$ppyReportDefinition$ppyUI$ppyBody$ppy')]/following::*[contains(text(),'Cancel')])[1]")).click();
		Thread.sleep(5000);


	}
	public void Click_on_Actions_and_Select_Export_Pdf() throws InterruptedException {
		//BaseClass.WaitforElementToBeClickable(By.xpath("//button[contains(text(),'Actions')]"));
		Thread.sleep(5000);
	WebElement Action =	 lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
	System.out.println(lwebDriver.getTitle());
	try {
		Action.click();
		 logger.info("Click on Actions button");
	}catch(StaleElementReferenceException e) {
		Action =	 lwebDriver.findElement(By.xpath("//button[contains(text(),'Actions')]"));
		Action.click();
	}
	WebElement PDF =	 lwebDriver.findElement(By.xpath("//span[contains(text(),'Export to PDF')]"));

	try {
		PDF.click();
		logger.info("Click on Export to PDF from Actions dropdown");
	}catch(StaleElementReferenceException e) {
		PDF = lwebDriver.findElement(By.xpath("//span[contains(text(),'Export to PDF')]"));
		PDF.click();
		logger.info("Click on Export to PDF from Actions dropdown");
	}

		System.out.println(lwebDriver.getTitle());
		logger.info("Report was Export to PDF and opended separate window");

		lwebDriver.findElement(By.xpath("//img[@name='pyReportEditorHeader_pyReportContentPage_19']")).click();
		logger.info("Closed The Editing report window and go back to reports main page");
		BaseClass.SwitchToDefaultFrame();
     Thread.sleep(5000);


	}
public void verify_newreport_Created_or_not(String Tittle) throws InterruptedException {
	BaseClass.SwitchToDefaultFrame();
		lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));


   try {
	   WebElement	searching_for_slim_reports2  =lwebDriver.findElement(By.xpath("//a[contains(text(),'All reports')]/following::div[1]//input"));
	   searching_for_slim_reports2.clear();
	    Thread.sleep(2000);
	   searching_for_slim_reports2.sendKeys(Tittle);
	   logger.info("Entered report name in search box on reports page");
	   searching_for_slim_reports2.sendKeys(Keys.ENTER);
    Thread.sleep(5000);
   }catch(StaleElementReferenceException e) {
	   WebElement	searching_for_slim_reports2  =lwebDriver.findElement(By.xpath("//a[contains(text(),'All reports')]/following::div[1]//input"));
		searching_for_slim_reports2  =lwebDriver.findElement(By.xpath("//a[contains(text(),'All reports')]/following::div[1]//input"));

		searching_for_slim_reports2.sendKeys(Tittle);
		searching_for_slim_reports2.sendKeys(Keys.ENTER);
	    Thread.sleep(5000);
   }

	WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40));
	WebElement Reportname =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//tr[contains(@base_ref,'D_pzReportBrowser7')][1]/td[3]//a")));
  //  WebElement	Reportname  =lwebDriver.findElement(By.xpath("    //tr[contains(@base_ref,'D_pzReportBrowser7.pzRBShortcuts(1)')]/td[2]//a"));
    if(Reportname.getText().equals(Tittle)){
    	Assert.assertTrue(true);
    	logger.info("******Report have been created and visible on reports page*******");

    }else {
    	logger.info("******Report have not  created and not visible on reports page*******");
    	Assert.assertTrue(false);
    }

BaseClass.SwitchToDefaultFrame();

}
public void Click_on_Customer_Sync() {

	BaseClass.WaitforVisiblityofElement(Customer_sync);
	Customer_sync.click();
	logger.info("Click on Customer master sync");

}
public void Company_code_and_CustomerNumber_System(String customercode, String Customernumber, String SystemID ) throws InterruptedException {
lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
	BaseClass.WaitforVisiblityofElement(Enter_customercode);
	Enter_customercode.sendKeys(customercode);
	logger.info("Entered customercode for sync");
	BaseClass.WaitforVisiblityofElement(Enter_customernumber);
	Enter_customernumber.sendKeys(Customernumber);
	logger.info("Entered Customer number for sync");
	BaseClass.WaitforVisiblityofElement(Enter_System);
	Enter_System.sendKeys(SystemID);
	logger.info("Entered SystemID for sync");
	lwebDriver.findElement(By.xpath("//button[contains(text(),'Import')]")).click();
	logger.info("Click on Import");
	Thread.sleep(3000);

}
public String DisputeCases_ID() throws InterruptedException, IOException {
	BaseClass.SwitchToDefaultFrame();
	BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
	WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
	 wait.until(ExpectedConditions.visibilityOfAllElements(Icon_Dispute));
    for(WebElement Icon_Disputes:Icon_Dispute) {
   	 Icon_Disputes.click();
    }
	WebDriverWait wait1= new WebDriverWait(driver,Duration.ofSeconds(40));
WebElement CI = 	 wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[contains(text(),'Dispute ID')]/following-sibling::div//a")));
	String CID = CI.getText();
	System.out.println(CID);

	return CID;
}
public void Verify_the_Customer_successfully_queued_for_import_or_not() {

	if(lwebDriver.getPageSource().contains("Customer successfully queued for import.")) {
		Assert.assertTrue(true);
		logger.info("*******Customer successfully queued for import.********");

	}
	else if(lwebDriver.getPageSource().contains("Customer Already Exist with Customer Number") || lwebDriver.getPageSource().contains("Message Label: The Field Value with key value(s) @baseclass/pyMessageLabel/Company Code validation failed for Value: '0100' does not exist")) {

		logger.info("*******Customer Already Exist or invaild  with Customer Number and System and Company Code, Please change the details  ********");
		Assert.assertTrue(true);
	}
	BaseClass.SwitchToDefaultFrame();
}

public void Click_on_Dispute_up_up() throws InterruptedException, IOException {

	WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
	WebElement DT = wait.until(ExpectedConditions.elementToBeClickable(Dispute_Task));
	DT.click();
	Thread.sleep(3000);
	WebDriverWait wait1= new WebDriverWait(driver,Duration.ofSeconds(40));
	WebElement Filter = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Case ID']//following	::span[2]/child::a")));
	Filter.click();
String a = this.DisputeCases_ID();
System.out.println(a);
	Thread.sleep(3000);
	try {
	  lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")).sendKeys(this.DisputeCases_ID());
	  logger.info("Entered customer number in text box");
	}catch(NoSuchFrameException e) {
	       BaseClass.SwitchToDefaultFrame();
	  Thread.sleep(3000);
	  lwebDriver.findElement(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")).click();
	  logger.info("Click on Apply");


	}

}
	}



























