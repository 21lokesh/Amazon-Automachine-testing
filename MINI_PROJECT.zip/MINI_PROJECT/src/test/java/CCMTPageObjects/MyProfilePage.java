 package CCMTPageObjects;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import CCMTTestCases.BaseClass;

public class MyProfilePage extends BaseClass{

	public WebDriver lwebDriver;

	  public MyProfilePage(WebDriver rdriver) {

		  lwebDriver=rdriver;
		  PageFactory.initElements(rdriver, this);
	  }


	  //ClickOnAvailabilityFromMyAccount
	   @FindBy(xpath="//span[text()='Availability']")
	   @CacheLookup
	   WebElement ClickOnAvailabilityFromMyAccount;

	   //Editsign
	   @FindBy(xpath="//a[contains(text(),'Edit sig')]")
	   @CacheLookup
	   WebElement Edit_sign;

	   //Select Edit button
	   @FindBy(xpath="//h2[text()='Skills']//following	::div[3]//child::i")
	   @CacheLookup
	   WebElement Editbutton;

	   @FindBy(xpath="//a[@name='pyPortalHeader_pyDisplayHarness_37']//following	::span[text()='Profile']")
		  @CacheLookup
		   WebElement profile;

	 //ClickOnAvailabilityFromMyAccount
	   @FindBy(xpath="//input[@name='$PCurOperator$ppyUnavailablePeriod$l1$ppyUnavailableFrom']")
	   @CacheLookup
	   WebElement ClickOnFromDateFieldForAvailability;

	 //ClickOnAvailabilityFromMyAccount
	   @FindBy(xpath="//input[@name='$PCurOperator$ppyUnavailablePeriod$l1$ppyUnavailableTo']")
	   @CacheLookup
	   WebElement ClickOnToDateFieldForAvailability;

	 //ClickOnAvailabilityFromMyAccount
	   @FindBy(xpath="//button[text()='  Submit ']")
	   @CacheLookup
	   WebElement ClickOnSubmitForAvailability;

	 //ClickOnAvailabilityFromMyAccount
	   @FindBy(xpath="//input[@name='$PCurOperator$ppySubstituteOperator']")
	   @CacheLookup
	   WebElement AddDefaultToAssign;

	 //ClickOnAvailabilityFromMyAccount
	   @FindBy(xpath="//span[text()='Z004E28U']")
	   @CacheLookup
	   WebElement SelectDefaultToAssign;


	   //clickonBulkActionFromProfile
	   @FindBy(xpath="//span[text()='Bulk actions']")
	   @CacheLookup
	   WebElement clickonBulkActionFromProfile;

	 //clickOnUpdateRadiobuttonInBulkActionPage
	   @FindBy(xpath="//label[text()='Update']")
	   @CacheLookup
	   WebElement clickOnUpdateRadiobuttonInBulkActionPage;

	 //clickOnUpdateRadiobuttonInBulkActionPage
	   @FindBy(xpath="//label[text()='Process']")
	   @CacheLookup
	   WebElement clickOnprocessRadiobuttonInBulkActionPage;

	   //clickOnBalanceCnfirmationCheckBoxForTransfer
	   @FindBy(xpath="//input[@data-test-id='2015012206024000093171']")
	   @CacheLookup
	   WebElement clickOnBalanceCnfirmationCheckBoxForTransfer;

	  //clickOnAnotherBalanceCnfirmationCheckBoxForTransfer
	   @FindBy(xpath="(//input[@data-test-id='2015012206024000093171'])[2]")
	   @CacheLookup
	   WebElement clickOnAnotherBalanceCnfirmationCheckBoxForTransfer;

	   //ClickOnSelectActionInBulkActionPage
	   @FindBy(xpath="//button[text()='Select Action ']")
	   @CacheLookup
	   WebElement ClickOnSelectActionInBulkActionPage;

	   //ClickOnTransferAssignmentFromSelectActionInBulkActionPage
	   @FindBy(xpath="//span[text()='Transfer assignment']")
	   @CacheLookup
	   WebElement ClickOnTransferAssignmentFromSelectActionInBulkActionPage;

	   //ClickOnSelectOperatorTransferAssignmentInBulkActionPage
	   @FindBy(xpath="//select[@name='$PreAssignPage$ppyReassignType']")
	   @CacheLookup
	   WebElement ClickOnSelectOperatorTransferAssignmentInBulkActionPage;

	   //SelectOperatorTransferAssignmentInBulkActionPage
	   @FindBy(xpath="//option[text()='Operator']")
	   @CacheLookup
	   WebElement SelectDropdownToOperatorTransferAssignment;

	   //SelectOperatorTransferAssignmentInBulkActionPage
	   @FindBy(xpath="//input[@name='$PreAssignPage$ppyReassignOperatorName']")
	   @CacheLookup
	   WebElement EnterOperatorToTransferAssignment;

	   //SelectOperatorTransferAssignmentInBulkActionPage
	   @FindBy(xpath="//span[.='Saleem']")
	   @CacheLookup
	   WebElement SelectOperatorToTransferAssignment;

	   //AddNotesInTransferAssignment
	   @FindBy(xpath="//textarea[@name='$PreAssignPage$ppyNote']")
	   @CacheLookup
	   WebElement AddNotesInTransferAssignment;

	   //SelectOperatorTransferAssignmentInBulkActionPage
	   @FindBy(xpath="//div[text()='OK']")
	   @CacheLookup
	   WebElement ClickOnOkButtonToTransferAssignment;

	 //SelectOperatorTransferAssignmentInBulkActionPage
	   @FindBy(xpath="//label[text()='Transferred']")
	   @CacheLookup
	   WebElement VerifyTransfered;



//Ageing

	   //ClickOnGraph
	   @FindBy(xpath="//label[text()='Graph']")
	   @CacheLookup
	   WebElement ClickOnGraph;




       String CustomerFrameId="PegaGadget0Ifr";

	   String ItemFrame="PegaGadget1Ifr";

	   String InsideItem="PegaGadget2Ifr";

	   String UpdateFrame="PegaGadget3Ifr";
	   String Frane4="PegaGadget4Ifr";

	   public void SelectAvailabilityFromMyAccount() throws InterruptedException

		  {
			  JavascriptExecutor je=(JavascriptExecutor)lwebDriver;
			  je.executeScript("arguments[0].click();", ClickOnAvailabilityFromMyAccount);
			//  ClickOnAvailabilityFromMyAccount.click();
			  Thread.sleep(4000);
		  }

	   public void SelectFromDateFieldForAvailability()

		  {
			  ClickOnFromDateFieldForAvailability.sendKeys("01/29/2021");
		  }

	   public void SelectToDateFieldForAvailability()

		  {
			  ClickOnToDateFieldForAvailability.sendKeys("01/31/2021");
		  }

	   public void SubmitForAvailability()

		  {
			  ClickOnSubmitForAvailability.click();
		  }

	   public void AddDefaultToAssignForAvailability()

		  {
			  AddDefaultToAssign.clear();
			  AddDefaultToAssign.sendKeys("Saleem");

			  SelectDefaultToAssign.click();

		  }

	   public void SelectBulkActionFromProfile()

		  {
			  clickonBulkActionFromProfile.click();
		  }

	   public void SelectprocessRadiobuttonInBulkActionPage()

		  {   BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
			  clickOnprocessRadiobuttonInBulkActionPage.click();
		  }

	   public void SelectBalanceCnfirmationCheckBoxForTransfer()

		  {
			  clickOnBalanceCnfirmationCheckBoxForTransfer.click();
			  clickOnAnotherBalanceCnfirmationCheckBoxForTransfer.click();

		  }

	   public void SelectActionInBulkActionPage()

		  {
			  ClickOnSelectActionInBulkActionPage.click();
		  }

	   public void SelectTransferAssignmentFromSelectActionInBulkActionPage()

		  {
			  ClickOnTransferAssignmentFromSelectActionInBulkActionPage.click();
		  }

	   public void ClickSelectOperatorTransferAssignmentInBulkActionPage()

		  {
			  ClickOnSelectOperatorTransferAssignmentInBulkActionPage.click();
			  Select sc=new Select(ClickOnSelectOperatorTransferAssignmentInBulkActionPage);
			  sc.selectByVisibleText("Operator");
		  }

	   public void EnterOperatorToTransferAssignmentInBulkAction()

		  {
			  EnterOperatorToTransferAssignment.sendKeys("Saleem");
			  SelectOperatorToTransferAssignment.click();
			  AddNotesInTransferAssignment.sendKeys("Automation Testing");

		  }

	   public void OkButtonToTransferAssignment()

		  {
			  ClickOnOkButtonToTransferAssignment.click();
		  }


		  public void IsActionTransfered() throws InterruptedException

		  {
			  Thread.sleep(5000);
			  Assert.assertTrue(VerifyTransfered.isDisplayed(),"Transfered");

			  Thread.sleep(2000);
			  BaseClass.SwitchToDefaultFrame();

		  }


	public void US_Profile() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement profile_view = wait.until(ExpectedConditions.elementToBeClickable(profile));

		if (profile_view.isDisplayed()) {
			Assert.assertTrue(true);
			Thread.sleep(3000);
			clickElementWithJS(profile_view);
			logger.info("Selected profile option in dropdown");
		} else {
			logger.info("Did not see the profile option in dropdown");
			Assert.assertTrue(false);
		}
	}

	private void clickElementWithJS(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element);
	}

		  public void Select_Edit_profile() throws InterruptedException {
			  WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(80));
			  WebElement iframeElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.tagName("iframe")));
			  lwebDriver.switchTo().frame(iframeElement);
			 // BaseClass.SwitchtoFrameUsingFrameIdorName(ItemFrame);
			 try {
	    WebElement Editbutton1 =		 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//h2[text()='Skills']//following	::div[3]//child::i")));
			  if(Editbutton1.isEnabled()) {
				 Assert.assertTrue(true);
				 Editbutton1.click();
				 Thread.sleep(3000);
					logger.info("Click on edit button");

			  }
			  else {
				  logger.info("The edit option is not available");
				  Assert.assertTrue(false);
			  }

		  }catch(TimeoutException e) {

			    WebElement Editbutton1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),'Edit')])[2]")));
					  if(Editbutton1.isEnabled()) {
						 Assert.assertTrue(true);
						 Editbutton1.click();
						 Thread.sleep(3000);
							logger.info("Click on edit button");

					  }
					  else {
						  logger.info("The edit option is not available");
						  Assert.assertTrue(false);
					  }

		  }
		  }
public void add_Skills() throws InterruptedException {
	WebElement skilltextbox = lwebDriver.findElement(By.xpath("//div[@id='modalWrapper']//child::table[1]//child::textarea"));
	skilltextbox.clear();
	//System.out.println(skilltextbox.getText());
	Thread.sleep(3000);
	skilltextbox.sendKeys("CashCollection");
	logger.info("Added Skill into textbox");

	WebElement submit =lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]"));
	Thread.sleep(3000);
	try {
		submit.click();
		Thread.sleep(3000);
		logger.info("Click on submit button");
	}catch(StaleElementReferenceException e) {
		submit =lwebDriver.findElement(By.xpath("//button[contains(text(),'Submit')]"));
		submit.click();
	}




	Thread.sleep(3000);

	try {
		Editbutton.click();

	}catch(StaleElementReferenceException e) {
		Editbutton =lwebDriver.findElement(By.xpath("//h2[text()='Skills']//following	::div[3]//child::i"));
		Editbutton.click();
	Thread.sleep(5000);
	}catch(NoSuchElementException e) {
		 WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(40));
		    WebElement Editbutton1 = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[contains(text(),'Edit')])[2]")));
		    Editbutton1.click();
	}
	try {
	System.out.println(skilltextbox.getText());
	}catch(StaleElementReferenceException e) {
		skilltextbox = lwebDriver.findElement(By.xpath("//div[@id='modalWrapper']//child::table[1]//child::textarea"));
		System.out.println(skilltextbox.getText());

	}

	lwebDriver.findElement(By.xpath("//div[@id='modalWrapper']//child::table[1]//child::textarea")).click();
	logger.info("Click on 'Cancel' button");
	try {
String skilltext = 	lwebDriver.findElement(By.xpath("//a[contains(text(),'Edit sig')]//ancestor::div[5]//child::div/child::span")).getText();
//System.out.println(skilltext);
if(skilltextbox.getText().equals(skilltext)) {
	logger.info("***The profile has been updated with skills****");
	Assert.assertTrue(true);
}
else {
	logger.info("***Did not update skills in profile****");
	Assert.assertTrue(false);
}
	}catch(NoSuchElementException e) {

		String skilltext = 	lwebDriver.findElement(By.xpath("(//button[contains(text(),'Edit sig')]//ancestor::div[5]//child::div/child::span)[1]")).getText();
		//System.out.println(skilltext);
		if(skilltextbox.getText().equals(skilltext)) {
			logger.info("***The profile has been updated with skills****");
			Assert.assertTrue(true);
		}
		else {
			logger.info("***Did not update skills in profile****");
			Assert.assertTrue(false);
		}

	}
BaseClass.SwitchToDefaultFrame();
}
public void Edit_signature() throws InterruptedException {
	lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));


	logger.info("Click on Edit signature");
	Thread.sleep(3000);
	Edit_sign.click();
	Thread.sleep(5000);
}

	public void Set_Email_Signature() throws InterruptedException, IOException{
			  Thread.sleep(8000);
//			  try
//			  {
////				 lwebDriver.switchTo().frame(0);
//				  lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
//               //  BaseClass.SwitchtoFrameUsingFrameIdorName(InsideItem);
//			  }
//			  catch(NoSuchFrameException e)
//			  {
//			  System.out.println("frame");
//			  }
			  Thread.sleep(5000);
			  String prent = lwebDriver.getWindowHandle();
				System.out.println(prent);
				//  BaseClass.WaitforElementToBeClickable(By.xpath("//title[text()='This is a rich text editor control.']/ancestor::html"));
			WebElement 	  AddNotesInCustomerCall		=  lwebDriver.findElement(By.xpath("//title[text()='This is a rich text editor control.']/ancestor::html/body"));
		//	WebElement 	  AddNotesInCustomerCall2		=  lwebDriver.findElement(By.className("//body[@class='cke_editable cke_editable_themed cke_contents_ltr cke_show_borders']"));

			System.out.println(AddNotesInCustomerCall.getText());
			AddNotesInCustomerCall.sendKeys("jhbwiuh");

//				 JavascriptExecutor js =(JavascriptExecutor) driver;
//				 js.executeScript("document.body.firstChild.contentEditable = true;");
//				 js.executeScript("arguments[0].value='Giri'",AddNotesInCustomerCall);
			  }
}




