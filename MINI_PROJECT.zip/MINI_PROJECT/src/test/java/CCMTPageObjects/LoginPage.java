package CCMTPageObjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import CCMTTestCases.BaseClass;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {


	  WebDriver lwebDriver;

	  public LoginPage(WebDriver rdriver) {

		  lwebDriver=rdriver;
		  PageFactory.initElements(rdriver, this);
	  }

	   @FindBy(xpath="//div[contains(text(),'Login with Siemens Smartcard (PKI)')]")
	   @CacheLookup
	   WebElement LinkSmartCard;

	@FindBy(xpath="//input[contains(@name,'UserIdentifier')]")
	@CacheLookup
	WebElement username;

	@FindBy(xpath="//input[contains(@id,'txtPassword')]")
	@CacheLookup
	WebElement Passwords;

	   public void ClickOnSamrtCardLink() throws InterruptedException {
		   try {
			   Thread.sleep(3000);
			   LinkSmartCard.click();


		   } catch (StaleElementReferenceException e) {

		   }
	   }
		   public void Enter_Username_Password(String User_name,String Password){
			   WebDriverWait wait= new WebDriverWait(lwebDriver, Duration.ofSeconds(40));
			WebElement enter_UN =   wait.until(ExpectedConditions.visibilityOf(username));
			   enter_UN.sendKeys(User_name);

			   WebElement enter_Password =   wait.until(ExpectedConditions.visibilityOf(Passwords));
			   enter_Password.sendKeys(Password);

		   }
	   }





