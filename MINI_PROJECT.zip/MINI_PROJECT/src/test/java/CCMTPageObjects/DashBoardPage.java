package CCMTPageObjects;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import CCMTTestCases.BaseClass;

public class DashBoardPage extends BaseClass{
	String FalseData;
	String cleanedData;
	String amount;

	double int_amount;

	String ItemFrame = "PegaGadget1Ifr";

	String InsideItem = "PegaGadget2Ifr";

	String UpdateFrame = "PegaGadget3Ifr";
	String Frane4 = "PegaGadget4Ifr";
	String Frane6 = "PegaGadget6Ifr";

	public WebDriver lwebDriver;

	  public DashBoardPage(WebDriver rdriver) {

		  lwebDriver=rdriver;
		  PageFactory.initElements(rdriver, this);
	  }




	//DashBoard

		 //ClickOnEmailOption
		   @FindBy(xpath="//span[text()='Dashboard']")
		   @CacheLookup
		   WebElement ClickOnDashBoardFromBurgerMenu;

	@FindBy(xpath="//input[contains(@name,'$PD_OpenDebtorItemListByCollection_pa') and @type='checkbox']")
	@CacheLookup
	List<WebElement> Item_Checkbox;

	@FindBy(xpath="//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')]//td[@data-attribute-name='Amount']//span[1]/span")
	@CacheLookup
	List<WebElement> Item_Amount;

	@FindBy(xpath = "//span[text()='My Customers']")  ////div[@id='po0']
	@CacheLookup
	WebElement Mycustomer;

	@FindBy(xpath="//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='Company Code']//following::span[2]/child::a")
	@CacheLookup
	WebElement Companycode_fliter;


	@FindBy(xpath="//tr[contains(@id,'$PD_CCCollectionCustomersListByUser_pa')]//td[1]/div[@node_name='OpenCollectionButton']")
	@CacheLookup
	List<WebElement> collection;

	@FindBy(xpath="//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='CC']//following::span[2]/child::a")
	@CacheLookup
	WebElement Companycode_fliter_myworkpage;

	@FindBy(xpath="//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='SAP System Code']//following::span[2]/child::a")
	@CacheLookup
	WebElement SAP_Systemcode;

	@FindBy(xpath="//button[contains(text(),'Dispute')]")
	@CacheLookup
	WebElement Dispute_button;

	@FindBy(xpath="//label[text()='Reason Code']//following-sibling::div/child::input[1]")
	@CacheLookup
	WebElement Element;

	@FindBy(xpath="//tr[contains(@id,'$PpyVirtualRecordEditorREResultPage')][1]//td[@data-attribute-name='Escalation Threshold Amount']/div")
	@CacheLookup
	WebElement Threshold_amount;

	@FindBy(xpath="//div[@id='po0']/descendant::label[text()='Search Text']/following::input")
	@CacheLookup
	WebElement input_text;

	@FindBy(xpath="//div[@id='po0']/descendant::label[text()='Search Text']/following::input")
	@CacheLookup
	WebElement input_text1;

	@FindBy(xpath="//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")
	@CacheLookup
	WebElement Apply;

	@FindBy(xpath="//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")
	@CacheLookup
	WebElement Apply1;

	@FindBy(xpath="//label[contains(text(),'Escalate this dispute')]//parent::span/child::input[2]")
	@CacheLookup
	WebElement Escalate;

	@FindBy(xpath="//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]")
	@CacheLookup
	WebElement ClickOnContactEdit;


	@FindBy(xpath="//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='First Name']//input")
	@CacheLookup
	WebElement First_Name;


	@FindBy(xpath="//tr[contains(@id,'$PtmpContactList')][2]/td[3]//input")
	@CacheLookup
	WebElement Firstname_2ndclomn;

	@FindBy(xpath="//tr[contains(@id,'$PtmpContactList')][2]/td[4]//input")
	@CacheLookup
	WebElement Firstname_3ndclomn;

	@FindBy(xpath="//tr[contains(@id,'$PtmpContactList')][2]/td[9]//input")
	@CacheLookup
	WebElement Firstname_4ndclomn;
	@FindBy(xpath="//tr[contains(@id,'$PtmpContactList')]/td[@data-attribute-name='Last Name']//input")
	@CacheLookup
	WebElement Last_name;

	@FindBy(xpath="//tr[contains(@id,'$PtmpContactList')][1]/td[9]//input")
	@CacheLookup
	WebElement Email;

	@FindBy(xpath="(//div[text()='No items'])[1]")
	@CacheLookup
	WebElement NO_items;

	@FindBy(xpath = "//a[.='Add Contact']")
	@CacheLookup
	WebElement ClickOnAddContact;

	@FindBy(xpath = "/html/body/div[2]/form/div[3]/div[2]/section/div/span[2]/div/span/div/div/div/div/div[1]/div/div/div/div/div/div/div/div/div/div/div[4]/div[2]/div/div[1]/div/div/div/div/div/div/div/div/div[1]/div/div[1]/i")
	@CacheLookup
	WebElement information_tab;

	@FindBy(xpath="//div[@id='grid-DIV']//tr")
	@CacheLookup
	List<WebElement> Table_data;

	@FindBy(xpath = "//span[text()='        Edit contacts       ']/following::button[text()='  Update ']")
	@CacheLookup
	WebElement ClickOnUpdate;

		 //ClickOnEmailOption
		   @FindBy(xpath="//div[text()='Under the Hood']")
		   @CacheLookup
		   WebElement ClickOnUnderTheHood;

	@FindBy(xpath="//span[text()='Configuration']")
	@CacheLookup
	WebElement Click_on_configuration;

	@FindBy(xpath = "//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]")
	@CacheLookup
	WebElement ClickOnContactEdit1;
	@FindBy(xpath="//input[@name='$PpyDisplayHarness$ppySearchText' and @data-changed='false']")
	@CacheLookup
	WebElement Search_bar;

	@FindBy(xpath="//span[text()='Configuration - Escalation per Reason Code']/preceding::button[1]//div[text()='Edit']")
	@CacheLookup
	WebElement Edit_button;

	@FindBy(xpath="//span[text()='Configuration - SAP Reason Codes']/preceding::button[1]//div[text()='Edit']")
	@CacheLookup
	WebElement SAP_Edit_button;

		 //ClickOnEmailOption
		   @FindBy(xpath="//h2[text()='Global Under the Hood']")
		   @CacheLookup
		   WebElement ClickOnGlobalUnderTheHood;

		 //ClickOnEmailOption
		   @FindBy(xpath="//h2[text()='Listener Management']")
		   @CacheLookup
		   WebElement ClickOnListnerManagement;

		   @FindBy(xpath="//div[text()='Under the Hood']/following::div[23]")
		   @CacheLookup
		   WebElement ClickOnunderHoodtalble;
		   @FindBy(xpath="//div[text()='Global Under the Hood']")
		   @CacheLookup
		   WebElement  Under_the_Hood;

		   @FindBy(xpath="//div[text()='Listener Management']")
		   @CacheLookup
		   WebElement  Listener_Management;

		   String CustomerFrameId="PegaGadget0Ifr";



		   public void SelectDashBoardFromBurgerMenu() throws Exception

			  {
				  BaseClass.WaitforElementToBeClickable(ClickOnDashBoardFromBurgerMenu);
				  Thread.sleep(5000);
				  ClickOnDashBoardFromBurgerMenu.click();
				  Thread.sleep(5000);
				  //Giri
				  if(ClickOnDashBoardFromBurgerMenu.isEnabled()) {
					  logger.info("DashBord option is avalible from mainmenu");
				  }
				  else {
					  logger.info("DashBord option is not avalible from mainmenu");
				  }
			  }

	public void Select_Configaration_From_BurgerMenu() throws Exception

	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		 wait.until(ExpectedConditions.elementToBeClickable(Click_on_configuration));
		Click_on_configuration.click();

		//Giri
		if(Click_on_configuration.isEnabled()) {
			logger.info("Configuration option is avalible from mainmenu and cliked on it");
		}
		else {
			logger.info("Configuration option is not avalible from mainmenu");
		}
	}

	public void Enter_text_in_searchbar_and_ClickEdit(String Serach_Escalation) throws Exception

	{
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(Search_bar));
		Search_bar.sendKeys(Serach_Escalation);
		logger.info("Enter the value in input box");
		Search_bar.sendKeys(Keys.ENTER);
		logger.info("The escalation per reason code is displayed below, and I am clicking on the edit button.");
		Thread.sleep(5000);
		wait.until(ExpectedConditions.elementToBeClickable(Edit_button));
		Actions actions = new Actions(driver);
		actions.doubleClick(Edit_button).perform();
		Thread.sleep(5000);
		BaseClass.SwitchToDefaultFrame();

	}

	public void Enter_SAP_Reasoncodes_in_searchbar_and_ClickEdit(String Serach_SAP) throws Exception

	{
		BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(Search_bar));
		Search_bar.sendKeys(Serach_SAP);
		logger.info("Enter the value in input box");
		Search_bar.sendKeys(Keys.ENTER);
		logger.info("The SAP reason codes  are displayed below, and I am clicking on the edit button.");
		Thread.sleep(5000);
		Actions actions = new Actions(driver);
		boolean clicked = false;
		int attempts = 0;
		while (attempts < 3 && !clicked) {
			try {
				// Re-locate the element to avoid StaleElementReferenceException
				SAP_Edit_button = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Configuration - SAP Reason Codes']/preceding::button[1]//div[text()='Edit']")));

				// Perform double click
				actions.doubleClick(SAP_Edit_button).perform();
				clicked = true;
			} catch (StaleElementReferenceException e) {
				System.out.println("Caught StaleElementReferenceException. Retrying...");
				attempts++;
			}
		}

		if (!clicked) {
			System.out.println("Failed to click on the edit button after 3 attempts.");
		}

		// Wait for some time (could be replaced by a more robust wait if necessary)
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		// Assuming BaseClass.SwitchToDefaultFrame() is a method you need to call
		BaseClass.SwitchToDefaultFrame();
	}

	public void EditConfiguration_page() throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget1Ifr");

		Random random = new Random();
		List<String> rowDataList = new ArrayList<>(); // Initialize a list to store row data
		for (WebElement tableData : Table_data) {
			// Get the text of the table data in the current row
			String rowData = tableData.getText();
			// Add the row data to the list
			rowDataList.add(rowData);
		}



		// Shuffle the list to randomize the order
		Collections.shuffle(rowDataList);

		// Iterate through the list to find the first row containing "false" and print it
		for (String rowData : rowDataList) {
			if (rowData.contains("false")) {
				// Print the row data to the console
				 FalseData = rowData;
				 cleanedData = FalseData.replaceAll("\\bfalse\\b", "").trim();
				System.out.println(cleanedData);
				logger.info("Randomly select a false reason code from the table, assign it to a dispute, and check if it works.");
				// Break out of the loop after printing one row
				break;
			}
		}
	}

	public void Getting_Escalation_Threshold_Amount(String Companycode,String SAP_systemcode) throws InterruptedException {
		BaseClass.SwitchtoFrameUsingFrameIdorName("PegaGadget1Ifr");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.elementToBeClickable(Companycode_fliter));
		Companycode_fliter.click();

		wait.until(ExpectedConditions.visibilityOf(input_text));
		input_text.sendKeys(Companycode);
		wait.until(ExpectedConditions.visibilityOf(Apply));
		Apply.click();
		logger.info("Filter the specific company code using the header company filters.");

		boolean clicked = false;
		int attempts = 0;
		while (attempts < 3 && !clicked) {
			try {
				// Re-locate the element to avoid StaleElementReferenceException
				SAP_Systemcode = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@id='gridLayoutTable']//descendant::th//descendant::*[text()='SAP System Code']//following::span[2]/child::a")));

				// Perform the click
				SAP_Systemcode.click();
				clicked = true;
			} catch (StaleElementReferenceException e) {
				System.out.println("Caught StaleElementReferenceException. Retrying...");
				attempts++;
			}
		}
//div[@id='po0']/descendant::label[text()='Search Text']/following::input
logger.info("after");
		WebElement input3 =	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")));
         try{
			 input3.sendKeys(SAP_systemcode);

		 }catch (StaleElementReferenceException e){
		WebElement input2 =	 wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::input")));
			 input2.sendKeys(SAP_systemcode);
		 }

		WebElement Apply1 =	 wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='po0']/descendant::label[text()='Search Text']/following::button[text()='Apply']")));
		Apply1.click();
		logger.info("Filter the specific System code using the header Systemcode filters.");
		Thread.sleep(3000);
		wait.until(ExpectedConditions.visibilityOf(Threshold_amount));

		amount =Threshold_amount.getText();
		 int_amount = Integer.parseInt(amount);
		logger.info("Obtaining the threshold amount for testing in disputes.");
		logger.info("Now, proceeding to dispute to conduct testing with the threshold amount.");



	}

	public void Select_the_collection_on_myworkpage(String CCc) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until(ExpectedConditions.elementToBeClickable(Mycustomer));
		Mycustomer.click();
		logger.info("Click on my customer list ");
		wait.until(ExpectedConditions.visibilityOf(Companycode_fliter_myworkpage));
		Companycode_fliter_myworkpage.click();
		Thread.sleep(3000);
		wait.until(ExpectedConditions.elementToBeClickable(input_text1));
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		jsExecutor.executeScript("arguments[0].value='" + CCc + "';", input_text1);
		Thread.sleep(3000);
	 wait.until(ExpectedConditions.elementToBeClickable(Apply1));
		Apply1.click();
		logger.info("Filtered the same code collection on my work page. ");

		//tr[contains(@id,'$PD_CCCollectionCustomersListByUser_pa')]//td[1]/div[@node_name='OpenCollectionButton']

		boolean clicked = false;
		int attempts = 0;

		while (attempts < 3 && !clicked) {
			try {
				// Re-locate the elements
				List<WebElement> freshCollection = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//tr[contains(@id,'$PD_CCCollectionCustomersListByUser_pa')]//td[1][not(ancestor::td[@data-attribute-name='Email']//table[1]/tbody)]")));

				if (!freshCollection.isEmpty()) {
					// Create an instance of Random
					Random random = new Random();

					// Select a random element from the list
					WebElement randomElement = freshCollection.get(random.nextInt(freshCollection.size()));

					// Create an instance of JavaScriptExecutor
					randomElement.click();
					// Click the randomly selected element using JavaScript
			//		jsExecutor.executeScript("arguments[0].click();", randomElement);

					System.out.println("Clicked on a  collection successfully!");
					clicked = true;
				} else {
					System.out.println("No elements found matching the XPath expression.");
					break;
				}
			} catch (StaleElementReferenceException e) {
				System.out.println("Caught StaleElementReferenceException. Retrying...");
				attempts++;
			}
		}

		if (!clicked) {
			System.out.println("Failed to click on a random element after 3 attempts.");
		}
		Thread.sleep(5000);
	}






	public void ClickOnContactUpdate() throws InterruptedException {

		BaseClass.WaitforElementToBeClickable(ClickOnUpdate);
		Thread.sleep(3000);
		ClickOnUpdate.click();
		Thread.sleep(6000);

		BaseClass.SwitchToDefaultFrame();


	}

	public void SelectCheckBoxanddisputeoption_HC() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(15));
		WebElement iframe = driver.findElement(By.id("PegaGadget0Ifr"));
		driver.switchTo().frame(iframe);
		if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
			wait.until(ExpectedConditions.elementToBeClickable(information_tab));
			BaseClass.WaitforElementToBeClickable(information_tab);
			information_tab.click();

			JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
			js2.executeScript("window.scrollBy(0,300)");


			try {
				BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
				ClickOnContactEdit.click();
			} catch (StaleElementReferenceException e) {
				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				ClickOnContactEdit.click();
			}

			if (!NO_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				wait.until(ExpectedConditions.visibilityOf(First_Name));
				First_Name.sendKeys("B");
				wait.until(ExpectedConditions.visibilityOf(Last_name));
				Last_name.sendKeys("Giri");
				Email.sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();

			} else if (NO_items.getText().isEmpty()) {
				BaseClass.WaitforVisiblityofElement(ClickOnAddContact);
				ClickOnAddContact.click();
				Firstname_2ndclomn.sendKeys("B");
				Firstname_3ndclomn.sendKeys("Giri");
				BaseClass.WaitforVisiblityofElement(Firstname_4ndclomn);
				Firstname_4ndclomn.sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();

			}
		}


		BaseClass.SwitchToDefaultFrame();
		WebElement iframe2 = driver.findElement(By.id("PegaGadget0Ifr"));
		driver.switchTo().frame(iframe2);
		wait.until(ExpectedConditions.visibilityOfAllElements(Item_Checkbox));
		if (!Item_Checkbox.isEmpty()) {
			// Generate a random index
			Random random = new Random();
			int randomIndex = random.nextInt(Item_Checkbox.size());
			WebElement randomElement = Item_Checkbox.get(randomIndex);
			randomElement.click();
			logger.info("selected check box");
		} else {
			System.out.println("No matching elements found.");
		}
		 wait.until(ExpectedConditions.elementToBeClickable(Dispute_button));
		Dispute_button.click();
		logger.info("Click on Dispute");
		BaseClass.SwitchToDefaultFrame();
	}

	public void Selecting_equalamountitem_click_dispute() throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(20));
		WebElement iframe = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe);
		if (lwebDriver.getPageSource().contains("If the collection does not have any contact some actions are disabled")) {
			wait.until(ExpectedConditions.elementToBeClickable(information_tab));
			BaseClass.WaitforElementToBeClickable(information_tab);
			information_tab.click();

			JavascriptExecutor js2 = (JavascriptExecutor) lwebDriver;
			js2.executeScript("window.scrollBy(0,300)");


			try {
				BaseClass.WaitforVisiblityofElement(ClickOnContactEdit);
				ClickOnContactEdit.click();
			} catch (StaleElementReferenceException e) {
				ClickOnContactEdit = lwebDriver.findElement(By.xpath("//h2[text()='Contacts']/following::a[contains(@name,'ContactsSection')]"));
				ClickOnContactEdit.click();
			}

			if (!NO_items.getText().isEmpty()) {
				ClickOnAddContact.click();
				wait.until(ExpectedConditions.visibilityOf(First_Name));
				First_Name.sendKeys("B");
				wait.until(ExpectedConditions.visibilityOf(Last_name));
				Last_name.sendKeys("Giri");
				Email.sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();

			} else if (NO_items.getText().isEmpty()) {
				BaseClass.WaitforVisiblityofElement(ClickOnAddContact);
				ClickOnAddContact.click();
				Firstname_2ndclomn.sendKeys("B");
				Firstname_3ndclomn.sendKeys("Giri");
				BaseClass.WaitforVisiblityofElement(Firstname_4ndclomn);
				Firstname_4ndclomn.sendKeys("giri.b.ext@siemens.com");
				this.ClickOnContactUpdate();

			}
		}


		BaseClass.SwitchToDefaultFrame();
		WebElement iframe2 = driver.findElement(By.id("PegaGadget1Ifr"));
		driver.switchTo().frame(iframe2);
		wait.until(ExpectedConditions.visibilityOfAllElements(Item_Checkbox));
		if (!Item_Checkbox.isEmpty()) {
			// Generate a random index
			Random random = new Random();
			int randomIndex = random.nextInt(Item_Checkbox.size());
			WebElement randomElement = Item_Checkbox.get(randomIndex);
			randomElement.click();
			logger.info("selected check box");
		} else {
			System.out.println("No matching elements found.");
		}
		wait.until(ExpectedConditions.elementToBeClickable(Dispute_button));
		Dispute_button.click();
		logger.info("Click on Dispute");
		BaseClass.SwitchToDefaultFrame();
		Thread.sleep(5000);




		BaseClass.SwitchToDefaultFrame();
	}

	public void Select_Dispute_reason_IT() throws InterruptedException {
		SwitchtoFrameUsingFrameIdorName1("PegaGadget2Ifr");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(Element));
		if (element.isEnabled()) {
			Assert.assertTrue(true);
			element.sendKeys( cleanedData);
			Thread.sleep(3000);
			element.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(2000);
			element.sendKeys(Keys.ENTER);
			logger.info("Reason was selected");
		} else {
			logger.info("Did not select reason for dispute");
			Assert.assertTrue(false);
		}
		 wait.until(ExpectedConditions.elementToBeClickable(Escalate));
		if (!Escalate.isSelected()) {
			Assert.assertTrue(true);
			logger.info("When I assigned the false dispute reason codes in the dispute code , it worked as expected.");
			logger.info("Passed");
		}else{
			logger.info("*******The dispute reason codes are not working as expected.**********");
			logger.info("Testcase failed");

		}
		BaseClass.SwitchToDefaultFrame();
	}

	public void Select_SAP_reason_IT() throws InterruptedException {
		SwitchtoFrameUsingFrameIdorName1("PegaGadget0Ifr");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(Element));
		if (element.isEnabled()) {
			Assert.assertTrue(true);
			element.sendKeys("306");
			Thread.sleep(3000);
			element.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(2000);
			element.sendKeys(Keys.ENTER);
			logger.info("Reason was selected");
		} else {
			logger.info("Did not select reason for dispute");
			Assert.assertTrue(false);
		}
		wait.until(ExpectedConditions.elementToBeClickable(Escalate));
		if (lwebDriver.getPageSource().contains("Total dispute amount lower than threshold, Escalation is disabled.")) {
			Assert.assertTrue(true);
			logger.info("****When attempting to create a dispute for an amount less than the SAP amount, we expect that the Escalation option will be disabled.****");
			logger.info("Passed");
		}else{
			logger.info("*******TWhen attempting to create a dispute for an amount less than the SAP amount, the Escalation option should not be disabled.**********");
			logger.info("Testcase failed");

		}
		BaseClass.SwitchToDefaultFrame();
	}

	public void ExpandUnderTheHood() throws InterruptedException {
			   lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			   //Giri modify
			   // BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
			   BaseClass.WaitforVisiblityofElement(ClickOnunderHoodtalble);
			   List<WebElement> E = lwebDriver.findElements(By.xpath("//div[text()='Under the Hood']/following::div[21]"));
			   logger.info("Checking Buttons are working or not");
			   for (WebElement D : E) {
				   System.out.println(D.getSize());
				   if (D.isEnabled()) {
					   logger.info("Enabled all buttons under Hood");
					   Assert.assertTrue(true);
				   } else {

					   logger.info("Disabled  buttons under Hood");
					   Assert.assertTrue(false);
				   }
			   }
//			   BaseClass.WaitforElementToBeClickable(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Bank Statements']"));
//			   WebElement BankStatement = lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Bank Statements']"));
//			   if (BankStatement.isDisplayed()) {
//
//				   logger.info("Bank Statements is displayed under the Hood");
//				   Assert.assertTrue(true);
//			   } else {
//
//				   logger.info("Bank Statements is not displayed under the Hood");
//				   Assert.assertTrue(false);
//			   }
//
//			   WebElement Last_sync = lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Bank Statements']/following::div[2]"));
//			   if (Last_sync.isDisplayed()) {
//				   logger.info("Last sync of bank statements and date shows under Bank Statements");
//				   Assert.assertTrue(true);
//			   } else {
//				   logger.info("Last sync of bank statements and date are not showing under Bank Statements");
//				   Assert.assertTrue(false);
//			   }
//		WebElement Pending_Emails=lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Pending Emails']"));
//		if(Pending_Emails.isDisplayed()) {
//			logger.info("Pending_Emails shows under Bank Statements");
//			Assert.assertTrue(true);
//		}
//		else {
//			logger.info("Pending_Emails are not showing under Bank Statements");
//			Assert.assertTrue(false);
//		}
//		WebElement ShowButton=lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::a[text()='Show more']"));
//
//		if(ShowButton.isEnabled()& ShowButton.isDisplayed()) {
//			logger.info("ShowButton isEnabled & Displayed  ");
//			Assert.assertTrue(true);
//		}
//		else {
//			logger.info("ShowButton is not dispaly or else disabled");
//			Assert.assertTrue(false);
//		}
//		WebElement Failed_Emails=lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Failed Emails']"));
//
//		if(Failed_Emails.isDisplayed()) {
//			logger.info("Failed_Emails name shows under the Hood");
//			Assert.assertTrue(true);
//		}
//		else {
//			logger.info("Failed_Emails name not avalible  under the Hood");
//			Assert.assertTrue(false);
//		}
//
//		List<WebElement> No_of_Failed_Emails=lwebDriver.findElements(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Failed Emails']/following::div[@class='field-item dataValueRead']/child::span[@class='labelbold']"));
//
//
//		if(No_of_Failed_Emails.isEmpty()) {
//			logger.info("There are no Failed tractions avalible");
//			Assert.assertTrue(true);
//		}
//		else {
//			logger.info(" Failed tractions are  avalible");
//		//	Assert.assertTrue(true);
//		}
//		logger.info("******* Checking functionalities about ExpandGlobalUnderTheHood***********");
		lwebDriver.switchTo().defaultContent();
//			  }

		   }
		   public void ExpandGlobalUnderTheHood() throws InterruptedException

			  {  //Giri
			   lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			   if(Under_the_Hood.isDisplayed() ) {
				   logger.info(" Global Under the Hood is  avalible in Dashbord");
				   Assert.assertTrue(true);
			   }
			   else {
				   logger.info(" Global Under the Hood is not avalible in Dashbord");
				   Assert.assertTrue(false);
			   }
				  WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40));
				  WebElement Strategy =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Global Under the Hood']/following::h2[text()='Strategy Runs']")));
		//	   WebElement Strategy =lwebDriver.findElement(By.xpath("//div[text()='Global Under the Hood']/following::h2[text()='Strategy Runs']"));
			   if(Strategy.isDisplayed() ) {
				   logger.info(" Strategy functionality is  avalible under Global Under the Hood");
				   Assert.assertTrue(true);
			   }
			   else {
				   logger.info(" Strategy functionality is not avalible under Global Under the Hood");
				   Assert.assertTrue(false);
			   }
			  List< WebElement>StrategyDatatable =lwebDriver.findElements(By.xpath("//div[text()='Global Under the Hood']/following::table[1]"));
			  for(WebElement SS:StrategyDatatable) {
				  System.out.println(SS.getText());

			  if(SS.getText().contains("Application") && SS.getText().contains("Company Code")) {
				  logger.info(" Strategy table was displayed");
				  Assert.assertTrue(true);
			  }
			  else {
				  logger.info(" Strategy table was not displayed");
				  Assert.assertTrue(false);

				}

			  }
			  lwebDriver.switchTo().defaultContent();
			  }

		   public void ExpandListnerManagement() throws InterruptedException
			 //Giri
			  {
			   lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			   Listener_Management.click();
			   if(Listener_Management.isDisplayed()) {
				   logger.info(" Listener_Management was displayed");
					  Assert.assertTrue(true);
			   }
			   else {
					  logger.info(" Listener_Management functionality is not avalible under Dashbord");
					  Assert.assertTrue(false);
			  }

			   WebElement EmailListener =lwebDriver.findElement(By.xpath("//div[text()='Global Under the Hood']/following::table[1]"));
			   if(EmailListener.isDisplayed()) {
				   logger.info(" EmailListener was displayed");
					  Assert.assertTrue(true);
			   }
			   else {
					  logger.info(" EmailListener functionality is not avalible under Dashbord");
					  Assert.assertTrue(false);
			  }
			   WebElement EmailListenertable =lwebDriver.findElement(By.xpath("//div[text()='Global Under the Hood']/following::table[1]"));
			   Thread.sleep(5000);
			   EmailListenertable.click();
			   Thread.sleep(5000);
			   List<WebElement> EmailListenerdatatable =lwebDriver.findElements(By.xpath("//div[text()='Listener Management']/following::h2[text()='Email Listeners']/following::div[5]/child::div/descendant::table[@class='gridTable ']"));
			   for(WebElement ELD:EmailListenerdatatable) {
				   System.out.println(ELD.getText());
				   if(ELD.getText().contains("Listener Name") && ELD.getText().contains("Connection")  ) {
					   logger.info(" Office 365 table was displayed");
						  Assert.assertTrue(true);
				   }
				   else{
					   logger.info(" Office 365 table is not displayed");
						  Assert.assertTrue(false);
				   }
			   }

			  }
}