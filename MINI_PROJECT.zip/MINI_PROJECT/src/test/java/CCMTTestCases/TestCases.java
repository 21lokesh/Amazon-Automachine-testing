
package CCMTTestCases;

import net.bytebuddy.build.Plugin;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Random;


public class TestCases extends BaseClass {

	@Test(priority = 1)
	public void Login_page() throws IOException, InterruptedException {
		driver.get("https://www.amazon.in/");
		logger.info("URL is launched");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Hello, sign in']")));
		logger.info("Click the 'Sign In' button on the Amazon page.");
		// Click the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButton);

		WebElement emailid = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='email']")));
		emailid.sendKeys("7760739076");

		WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='a-button-input']")));
		continueButton.click();

		try {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@2225");
		} catch (StaleElementReferenceException e) {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@2225");
		}
		logger.info("Entered the username and password to log in.");

		logger.info("Enter the password");

		WebElement signInButtonFinal = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='signInSubmit']")));

		// Click the final sign-in button using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", signInButtonFinal);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButtonFinal);

		logger.info("click on sign in button");
		Thread.sleep(5000);

		try {
			// Navigate to the Amazon India webpage
			// Get the title of the page
			String pageTitle = driver.getTitle();

			// Expected page title
			String expectedTitle = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";

			// Print the title

			// Validate that the page title matches the expected title
			Assert.assertEquals(pageTitle, expectedTitle, "Page title does not match!");

			// If the assertion passes, print success message
			System.out.println("Page title validation passed.");

		} catch (AssertionError e) {
			// Print error message if the assertion fails
			System.out.println("Page title validation failed: " + e.getMessage());
		}
		logger.info("**Passed**");
	}

	@Test(priority = 2)
	public void login_with_wrong_password() throws InterruptedException {

		driver.get("https://www.amazon.in/");
		logger.info("URL is launched");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Hello, sign in']")));
		logger.info("Click the 'Sign In' button on the Amazon page.");
		// Click the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButton);

		WebElement emailid = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='email']")));
		emailid.sendKeys("7760739076");

		WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='a-button-input']")));
		continueButton.click();

		try {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@25");
		} catch (StaleElementReferenceException e) {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@25");
		}

		logger.info("Entered the username and password to log in.");

		WebElement signInButtonFinal = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='signInSubmit']")));

		// Click the final sign-in button using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", signInButtonFinal);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButtonFinal);
		Thread.sleep(5000);
		logger.info("click on sign in button");

		if (driver.getPageSource().contains("There was a problem")) {
			Assert.assertTrue(true);
			logger.info("***When entered with incorrect login details, the page displays sensible error messages.");
		} else {
			logger.info("When entered with incorrect login details, the page does not display sensible error messages.");
			Assert.assertTrue(false);

		}
		logger.info("**Passed**");
	}

	@Test(priority = 3)
	public void searchproduct_add_to_cart() throws InterruptedException {

		driver.get("https://www.amazon.in/");
		logger.info("URL is launched");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Hello, sign in']")));
		logger.info("Click the 'Sign In' button on the Amazon page.");
		// Click the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButton);

		WebElement emailid = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='email']")));
		emailid.sendKeys("7760739076");

		WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='a-button-input']")));
		continueButton.click();

		try {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@2225");
		} catch (StaleElementReferenceException e) {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@2225");
		}

		logger.info("Entered the username and password to log in.");

		WebElement signInButtonFinal = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='signInSubmit']")));

		// Click the final sign-in button using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", signInButtonFinal);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButtonFinal);

		Thread.sleep(5000);
		logger.info("click on sign in button");

		WebElement search = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@aria-label='Search Amazon.in']")));
		search.sendKeys("iphone");
		WebElement search_icon = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@value='Go']")));
		search_icon.click();
		logger.info("Enter the item name in the search input at the top of the page and click the search icon.");
		Thread.sleep(5000);

		// Wait for the presence of the elements
		List<WebElement> buttons = wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//button[text()='Add to cart']")));

		if (buttons.size() > 0) {
			// Generate a random index
			Random random = new Random();
			int index = random.nextInt(buttons.size());

			// Wait until the random button is clickable
			WebElement randomButton = wait.until(ExpectedConditions.elementToBeClickable(buttons.get(index)));
			Thread.sleep(5000);
			// Click the randomly selected button
			randomButton.click();
			logger.info("click on add cart option");

			System.out.println("Clicked on 'Add to cart' button at index: " + index);
		} else {
			System.out.println("No 'Add to cart' buttons found.");
		}

		Thread.sleep(5000);
		logger.info("***Passed****");
	}

	@Test(priority = 4)
	public void searchProductAndAddToCart() throws InterruptedException {
		driver.get("https://www.amazon.in/");
		logger.info("URL is launched");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Hello, sign in']")));

		// Click the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButton);

		WebElement emailid = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='email']")));
		emailid.sendKeys("7760739076");

		WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='a-button-input']")));
		continueButton.click();

		try {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@2225");
		} catch (StaleElementReferenceException e) {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@2225");
		}

		logger.info("Click the 'Sign In' button on the Amazon page.");
		logger.info("Entered the username and password to log in.");
		logger.info("click on sign in button");

		WebElement signInButtonFinal = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='signInSubmit']")));

		// Click the final sign-in button using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", signInButtonFinal);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButtonFinal);
		logger.info("Accessed the items in the cart.");

		Thread.sleep(5000);
		WebElement cart = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),' Cart')]")));
		cart.click();
		List<WebElement> cartItemsList = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//div[@class='a-section a-spacing-mini sc-list-body sc-java-remote-feature']")));

		// Check if any items are found
		if (cartItemsList.size() > 0) {
			System.out.println("Number of items in the cart: " + cartItemsList.size());

			// Print details of each cart item (example)
			for (WebElement item : cartItemsList) {
				System.out.println("Cart item: " + item.getText());
				if (item.getText().contains("Apple iPhone")) {
					Assert.assertTrue(true);
					logger.info("The selected item has been successfully added to the cart.");
				} else {
					logger.info("The selected item was not successfully added to the cart.");
					Assert.assertTrue(false);
				}
			}
		} else {
			System.out.println("No items found in the cart.");
		}
		logger.info("**Passed**");

	}

	@Test(priority = 5)
	public void selectLanguage() throws InterruptedException {
		driver.get("https://www.amazon.in/");
		logger.info("URL is launched");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement signInButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[text()='Hello, sign in']")));
		logger.info("Click the 'Sign In' button on the Amazon page.");
		// Click the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButton);

		WebElement emailid = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='email']")));
		emailid.sendKeys("7760739076");

		WebElement continueButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@class='a-button-input']")));
		continueButton.click();

		try {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@2225");
		} catch (StaleElementReferenceException e) {
			WebElement password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[@name='password']")));
			password.sendKeys("Giri@2225");
		}

		logger.info("Entered the username and password to log in.");

		WebElement signInButtonFinal = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='signInSubmit']")));

		// Click the final sign-in button using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", signInButtonFinal);
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", signInButtonFinal);
		logger.info("click on sign in button");
		Thread.sleep(5000);
		WebElement elementToHover = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='icp-nav-link-inner']")));

		// Initialize Actions class
		Actions actions = new Actions(driver);

		// Hover over the element
		actions.moveToElement(elementToHover).click().perform();

		System.out.println("Hovered over the element successfully.");

		List<WebElement> radioButtons = wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//i[contains(@class,'a-icon a-icon-radio')]")));

		if (radioButtons.size() > 0) {
			// Generate a random index
			Random random = new Random();
			int index = random.nextInt(radioButtons.size());

			// Click the randomly selected radio button
			WebElement randomRadioButton = radioButtons.get(index);
			randomRadioButton.click();
			logger.info("Clicking on the 'Sign In' button.");
			System.out.println("Selected a random radio button at index: " + index);
		} else {
			System.out.println("No radio buttons found.");
		}
        logger.info("Successfully selected a language from the list.");
		Thread.sleep(5000);
       logger.info("**Passed**");

	}
}







