package CCMTTestCases;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import com.aventstack.extentreports.ExtentTest;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import com.relevantcodes.extentreports.ExtentReports;

import Utilities.ExtentReporterNG;
import Utilities.ReadConfig;

public class BaseClass extends ExtentReporterNG {

	protected static Logger logger = Logger.getLogger(BaseClass.class);

	ReadConfig config = new ReadConfig();

	private static ThreadLocal<String> myThreadLocal = new ThreadLocal<String>();
	public String baseURL = config.getApplicationURL();
	public String excelpath = config.getExcelPath();
	public String excelpath2 = config.getExcelPath2();
	public String pin = config.getPinAuthenticated();
	public String PEGA_username = config.Get_Username();
	public String PEGA_Password = config.Get_Password();

	public String autoITPath = config.getAutoITPath();
	public String autoITDirPath = config.getAutoITDirectoryPath();
	public static WebDriver driver;

	private static BaseClass instance = null;
	public static ExtentTest test;
	public static ExtentReports extent;
	Connection con;
	PreparedStatement preparedStmt;
	Statement statement;
	String DB_URL;
	String DB_UserName;
	String DB_Password;


	public static BaseClass getInstance() {

		if (instance == null) {
			instance = new BaseClass();
		}
		return instance;
	}

	@Parameters("browser")
	@BeforeMethod(alwaysRun = true)
	public void setup(String br) {
		PropertyConfigurator.configure("log4j.properties");

		try {
			if (br.equalsIgnoreCase("chrome")) {
				setupChrome();
			} else {
				throw new IllegalArgumentException("Invalid browser parameter: " + br);
			}
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail("Error setting up WebDriver: " + e.getMessage());
		}
	}

	@AfterMethod(alwaysRun = true)
	public void tearDown() throws InterruptedException {


				driver.quit();
			}





	public void setupChrome() {
		try {
			ChromeOptions options = new ChromeOptions();
			options.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
//			options.addArguments("--incognito");
			options.addArguments("--remote-allow-origins=*");
//		    options.addArguments("--headless");
			options.addArguments("--window-size=1366,768");
			options.addArguments("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3");

			// Set the page load strategy based on your testing requirements
			options.setPageLoadStrategy(PageLoadStrategy.NORMAL);

			// Initialize ChromeDriver with ChromeOptions
			driver = new ChromeDriver(options);

			// Delete cookies
			driver.manage().deleteAllCookies();

			// Set up implicit wait to handle dynamic elements
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			// Maximize the window
			driver.manage().window().maximize();


		} catch (WebDriverException e) {
			logger.error("WebDriverException: " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Unexpected Exception: " + e.getMessage(), e);
		}
	}


	public static void switchToFrame(WebDriver driver, String frameName) {
		try {
			// Wait for the frame to be available
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
			wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameName));
			System.out.println("Switched to frame with name '" + frameName + "' successfully.");
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public void LoginByUsername_Password(String User_name, String Password) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		WebElement enter_UN = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[contains(@name,'UserIdentifier')]")));
		enter_UN.sendKeys(User_name);
		WebElement enter_Password = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//input[contains(@id,'txtPassword')]")));
		enter_Password.sendKeys(Password);
		WebElement Click_on_login_button = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//button[contains(@id,'sub')])[1]")));
		Click_on_login_button.click();

		logger.info("Entered username and Password on login page.");
	}


	public WebDriver getDriver() {


		return driver;
	}

	public void EnterCodeinSecurityWindowsPopUp2(String Pin) throws IOException, InterruptedException {

		// Runtime.getRuntime().exec("D:\\UserData\\z004n9pt\\OneDrive - Siemens AG\\Documents\\Demo\\HandleAuthentication.exe");
		Thread.sleep(10000);
		ProcessBuilder pb = new ProcessBuilder("C:\\Users\\z004sfsh\\IdeaProjects\\ccmtautomationproject1\\src\\Resources\\ConfigFiles\\HandleAuthentication.exe", Pin);
		pb.directory(new File("C:\\Users\\z004sfsh\\IdeaProjects\\ccmtautomationproject1\\src\\Resources\\ConfigFiles"));
		Process p = pb.start();
	}

	public void EnterCodeinSecurityWindowsPopUp(String Pin) throws IOException, InterruptedException {

		// Runtime.getRuntime().exec("D:\\UserData\\z004n9pt\\OneDrive - Siemens AG\\Documents\\Demo\\HandleAuthentication.exe");
		//Thread.sleep(5000);
		ProcessBuilder pb = new ProcessBuilder(config.getAutoITPath(), Pin);
		pb.directory(new File(config.getAutoITDirectoryPath()));
		Process p = pb.start();
	}

	public static void UploadFileFromAutoIt() throws IOException {
		Runtime.getRuntime().exec("C:\\Users\\z004e28u\\Desktop\\AutoIt\\manageAttachment.exe");
		// driver.navigate().refresh();
	}

	public static WebElement WaitforVisiblityofElement(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.visibilityOf(element));
		return element;
	}

	public static void WaitforElementToBeClickable(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}



	public static void SwitchtoFrameUsingFrameIdorName(String IdorName) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // 10 seconds wait time
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(IdorName));

	}

	public void SwitchtoFrameUsingFrameIdorName1(String frameIdOrName) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // 10 seconds wait time
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(frameIdOrName));
	}

	public static void SwitchToDefaultFrame() {
		driver.switchTo().defaultContent();
	}




	public String captureScreenshot(String screenshotName) {
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String destPath = System.getProperty("user.dir") + "/Screenshots/" + screenshotName + ".png";
			File destination = new File(destPath);
			FileUtils.copyFile(source, destination);
			return destPath;
		} catch (IOException e) {
			logger.error("Error while capturing screenshot: " + e.getMessage());
			return null;
		}
	}

}


