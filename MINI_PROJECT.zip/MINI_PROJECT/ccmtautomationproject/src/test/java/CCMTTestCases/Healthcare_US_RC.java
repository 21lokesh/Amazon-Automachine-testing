package CCMTTestCases;

import java.io.IOException;
import java.util.concurrent.TimeUnit;


import CCMTPageObjects.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import Utilities.XLUtils;

public class Healthcare_US_RC extends BaseClass{

//	LoginPage login = new LoginPage(driver);
//	MyWork work = new MyWork(driver);
//	CollectionPage collection = new CollectionPage(driver);
//	Assigncollector AC = new Assigncollector(driver);

	String strategies_Name = "strategy_UK_Test_asd";
	@Test(groups = {"Email"},priority = 1)
		public void HC_TC_014_CollectionItemEMail() throws IOException, InterruptedException {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 1, 3);
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username,PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
			logger.info("Switch to Cash Collection Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOptiondsa();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC();
			logger.info("Click on collection");
			collection.SelectEmailOptionInQUkRC();
			logger.info(" SelectEmailOption");
			collection.ClickOnCorrespondenceTemplateList1("Invoice Copy");
			logger.info("ClickOnCorrespondenceTemplateList");
			collection.Select_contacts();
			collection.Get_Statement();
			collection.ClickOnsendEmailOptionForEmails();
			logger.info("ClickOnsendEmailOption");
			collection.ClickOnAuditForCreateforopenItemEmail();
			logger.info("******Email was sent to customer******");
		//work.logoff();
		}
		@Test(groups = {"Email"},priority = 1,invocationCount = 2)
		public void HC_TC_011_EmailWithItemCopy() throws IOException, InterruptedException {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 2, 3);
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username,PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
			logger.info("Switch to Cash Collection Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOptiondsa();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC();
			logger.info("Click on collection search");
			collection.SelectCheckBoxForSendEmailWithItemInHC();
			collection.ClickOnEmailWithItemAction_HC();
			collection.Selected_Invoice_copy();
			logger.info("ClickOnEmailWithItemAction");
			collection.ClickOnCorrespondenceTemplateList1("General");
			logger.info("ClickOnCorrespondenceTemplateList");
			collection.Select_contacts();
			collection.RefreshContentInEmailWithItemCopy1();
			collection.ClickOnsendEmailOptionForEmails();
			logger.info("ClickOnsendEmailOption");
			collection.ClickOnAuditForEmail_HC_US();
			logger.info("GetRecentTaskID");

		}

		@Test(groups = {"Email"},priority = 1)
		public void HC_TC_011_EmailWithPO() throws IOException, InterruptedException {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",2,3);
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username,PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
			logger.info("Switch to Cash Collection Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOptiondsa();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC();
			logger.info("Click on collection search");
			collection.SelectCheckBoxForSendEmailWithItemInHC();
			collection.ClickOnEmailWithItemAction_HC();
			collection.Selected_PO();
			logger.info("ClickOnEmailWithItemAction");
			collection.ClickOnCorrespondenceTemplateList1("General");
			logger.info("ClickOnCorrespondenceTemplateList");
			collection.Select_contacts();
			collection.RefreshContentInEmailWithItemCopy1();
			//collection.Get_Statement();
			collection.ClickOnsendEmailOptionForEmails();
			logger.info("ClickOnsendEmailOption");
			collection.ClickOnAuditForEmail();
			logger.info("GetRecentTaskID");
			//work.logoff();

		}

		@Test(priority = 2,groups= {"PTP"})

		public void HC_TC_061_PromiseTo_Pay_Update_Promise() throws Exception {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 3, 3);
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username,PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
			logger.info("Switch to Cash Collection Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOptiondsa();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
			logger.info("Click on collection");
			collection.SelectCheckBox_Promisetopay();
			collection.SelectFollowUpCallDateAndTimeforP2P();
			logger.info("SelectDateForPromiseTopay");
			collection.SelectPaymentMethodInQ("Cheque");
			logger.info("Selected payment Method");
			collection.Select_Send_Summary_Email_To_Customer();
			collection.AddNotesInPromiseToPayPage("Test by Giri");
			logger.info("AddNotesInPromiseToPayPage");
			collection.ClickOnSubmitButton();
			logger.info("Click on submit button ");
			collection.ClickOnSubmitButton1();
			logger.info("Email was sent to customer");
			logger.info("Check the note under recent actions as well as the Audit section.");
			collection.Hide_button1();
			collection.ClickOnAuditForCreateforP2P();
			collection.closeallwindows();
			Thread.sleep(5000);
			collection.Verify_Promise_To_Pay_Follow_Up_Call();
			work.Fliter_Action(CustomerNo);
			collection.Click_on_MakeCall();
			collection.SelectReachedCustomerStatus1("B Giri");
			collection.Select_calltype1("Inbound", "Reached Customer");
			collection.AddNotesInCustomerCall();
			logger.info("Send Summary To Customer In PromiseToPayPage");
			collection.Click_on_Update();
			collection.SelectFollowUpCallDateAndTimeforP2P_1();
			collection.Click_on_Update1();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOption1();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC1();
			collection.Hide_button1();
			collection.Recent_Audit_Notes();


		}

		@Test(groups = {"Email"},priority = 2,invocationCount = 2)
		public void HC_TC_013_CallAction() throws Exception {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			String CustomerNo = "0000004663";
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username, PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
			logger.info("Switch to Cash Collection Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOptiondsa();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
			logger.info("Click on collection");
			collection.SelectCustomerCallActionInQUSRC();
			collection.SelectReachedCustomerStatus("B Giri");
			collection.Select_calltype("Inbound", "Reached Customer");
			collection.AddNotesInCustomerCall();
			logger.info("Send Summary To Customer In PromiseToPayPage");
			collection.SendCallSummaryToTheCustomer();
			logger.info("Add Notes In Promise To PayPage");
			collection.CreateFollowUpCall();
			logger.info("Click On CreateFollowUpCall");
			collection.SelectFollowUpCallDateAndTime2();
			logger.info("Selected follow up date for call action");
			collection.CustomerEndCall();
			collection.RefreshContentInEmailWithItemCopy_UK1();
			collection.ClickOnsendEmailOptionForEmails();
			collection.ClickOnAuditForCreateforcallaction();
			collection.closeallwindows();
			collection.Verify_callAction_SI();
			work.Fliter_Action(CustomerNo);
			collection.Verifying_Data_firstrow();

		}

		//@Test(priority = 2,groups= {"PTP"},dependsOnMethods= {"HC_TC_061_PromiseTo_Pay_Update_Promise"},alwaysRun=true)
		@Test(priority = 2,groups= {"PTP"})
		public void HC_TC_62_Promise_To_Pay_Fullfill_Promise() throws Exception {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 5, 3);
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username,PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
			logger.info("Switch to Cash Collection Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOptiondsa();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
			logger.info("Click on collection");
			collection.SelectCheckBox_Promisetopay();
			collection.SelectFollowUpCallDateAndTimeforP2P();
			logger.info("SelectDateForPromiseTopay");
			collection.SelectPaymentMethodInQ("CHEQUE");
			logger.info("Selected payment Method");
			collection.Select_Send_Summary_Email_To_Customer();
			collection.AddNotesInPromiseToPayPage("Test by Giri");
			logger.info("AddNotesInPromiseToPayPage");
			collection.ClickOnSubmitButton();
			logger.info("Click on submit button ");
			logger.info("Email was sent to customer");
			logger.info("Check the note under recent actions as well as the Audit section.");
			collection.ClickOnSubmitButton1();
			collection.Hide_button1();
			collection.ClickOnAuditForCreateforP2P_SI();
			collection.closeallwindows();
			collection.Verify_Promise_To_Pay_Follow_Up_Call();
			work.Fliter_Action(CustomerNo);
			collection.Click_on_MakeCall();
			collection.SelectReachedCustomerStatus1("B Giri");
			collection.Select_calltype1("Inbound", "Reached Customer");
			collection.AddNotesInCustomerCall();
			logger.info("Send Summary To Customer In PromiseToPayPage");
			collection.Click_on_Update();
			collection.SelectFollowUpCallDateAndTimeforP2P_1();
			collection.Click_on_FulFill();
			collection.SelectReachedCustomerStatus1("B Giri");
			collection.Select_calltype1("Inbound", "Reached Customer");
			collection.AddNotesInCustomerCall();
			logger.info("Send Summary To Customer In PromiseToPayPage");
			collection.Click_on_End_the_call();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOption1();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC1();
			collection.ClickOnAuditForCreateforP2P1_HC_US();



		}

		@Test(alwaysRun = true)

		public void HC_TC_019_AddContact() throws Exception {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",6, 3);
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username,PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
			logger.info("Switch to Cash Collection Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();
			work.ClickOnCustomerSearchOptiondsa();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			logger.info("Enter customer number");
			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC();
			//work.SwitchTonewWindowInQ();
			collection.ClickOnItemForeditContactUKRC();
	        collection.ClickOnContactEdit();
	    logger.info("ClickOnContactEdit");
	        logger.info("ClickOnAddContact");
	    //    collection.contacts();
	        collection.EnterFirstNameInContactPage();
	        logger.info("*******Contact details were added successfully*******");
	        collection.contacts1();


		}

		@Test(groups = {"Email"},priority = 1)

		public void HC_TC_041_InvoiceCopy() throws IOException, InterruptedException {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",7, 3);
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username,PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
			logger.info("Switch to Cash Collection Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();

//	      work.VerifyIfApplicationIsSelected("Cash Collection Healthcare US");
			work.ClickOnCustomerSearchOptiondsa();
			logger.info("Click on customer search");
			work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			logger.info("Enter customer number");

			logger.info("Click on customer search");
			work.ClickOnCollectionInQUKRC();
			logger.info("Click on collection search");
			collection.CloseOpenTaskForCollectionOption_HC();

			// collection.ViewItemInQUKRC();
			logger.info("Item Copy displayed in another page");
			work.SwitchTonewWindow();

//	        collection.CloseItem();
//	          collection.CloseCustomerSerach();
//	        work.ClickOnProfileButton_NEW();
//	        collection.LogoutFromApplication();
			//work.logoff();
		}

		@Test(groups = {"Login & Access"},priority = 1)
		public void HC_TC_042_DashBoard() throws Exception {
			driver.get(baseURL);
			logger.info("URL is launched");
			LoginPage login = new LoginPage(driver);
			MyWork work = new MyWork(driver);
			DashBoardPage dp = new DashBoardPage(driver);
			CollectionPage collection = new CollectionPage(driver);
			//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			//login.ClickOnSamrtCardLink();
			logger.info("Clicked on Smart Card link");
			LoginByUsername_Password(PEGA_username,PEGA_Password);
			logger.info("Entered code in pop up");
			work.ClickOnProfileButton_NEW();
			logger.info("Click on profile");
			work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
			logger.info("Switch to Cash Collection Manager Healthcare US ");
			work.SwitchTonewWindowInQ();
			collection.closeallwindows();
			//
			work.BurgerMenu();
			logger.info("BurgerMenu");

			dp.SelectDashBoardFromBurgerMenu();
			logger.info("SelectDashBoardFromBurgerMenu");
			dp.ExpandUnderTheHood();
			logger.info("ExpandUnderTheHood");
			dp.ExpandGlobalUnderTheHood();
			logger.info("ExpandGlobalUnderTheHood");
			dp.ExpandGlobalUnderTheHood();
			logger.info("ExpandGlobalUnderTheHood");
			dp.ExpandListnerManagement();
			logger.info("ExpandListnerManagement");
//	          collection.CloseCustomerSerach();
//	           logger.info("CloseCustomerSerach");
//	          work.ClickOnProfileButton_NEW();
			// logger.info("profile");
			// collection.LogoutFromApplication();
			logger.info("logout");

		}

		 @Test(groups = {"Login & Access"},priority = 1)
			public void HC_TC_001_assign_cashcollector_customer() throws IOException, Exception {

			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",8, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 AC.CCMT_mainmenu();
			 AC.CCMT_cash();
			 AC.CCMT_collectorsearch(CustomerNo);
			 AC.CCMT_search();
			 AC.coll_search();
			 driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

			 logger.info("****** Entering cashcollector name******");
			 AC.CCMT_collectorname(CollectorName);
			 logger.info("****** Entering cashcollector name******");
			 driver.findElement(By.xpath("//span[text()='        Assign Operator       ']/following::td[8]")).click();
			 AC.Radio_Button();

			 AC.Click_submit();
			 logger.info("****** Entering cashcollector name******");
//		WebElement Textvalidation = driver
//				.findElement(By.xpath("//span[contains(text(),'Thank you for the input! Collections are queued fo')]"));
			 Thread.sleep(5000);
			 if (driver.getPageSource().contains("//span[contains(text(),'Thank you for the input! Collections are queued fo')]")) {
				 logger.info("****** Passed******");
				 System.out.println("Message is dispalyed");
			 } else {
				 logger.info("****** failed******");
				 System.out.println("Message is not dispalyed");

			 }
			 driver.findElement(By.xpath("//input[contains(@name,'AuxSearchString')]")).clear();
			 driver.findElement(By.xpath("//input[contains(@name,'AuxSearchString')]")).sendKeys(CustomerNo);
			 driver.findElement(By.xpath("//div[text()='Search']/ancestor::button")).click();
			 collection.Verify_nameCashcollector_(CollectorName);

			 //	//work.logoff();

		 }

		 @Test(groups = {"Email"},priority = 1)
			public void HC_TC_010_SendInformation() throws IOException, InterruptedException {
			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",9, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
				logger.info("Enter customer number");

				logger.info("Click on customer search");
				work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
				logger.info("Click on collection");
				//collection.SelectCheckBoxForSendEmailWithItemInHC();
				collection.Selecting_Checkboxforprintbalance_HC();
				collection.SelectInformationOption();
				logger.info("Select Information Option");
				collection.SelectReasonForInformationInQ("Invoice");
				logger.info("Selected Reason For Information");

				logger.info("sent email to customer");


				collection.ClickOnSubmitButton();
				collection.ClickOnAudit();
				logger.info("ClickOnAudit");
				collection.VerifyAudiTRailCapturedInformationInQ();
				logger.info("VerifyAudiTRailCapturedInformation");
//				         collection.CloseItem();
				// collection.GetRecentTaskID();
				logger.info("GetRecentTaskID");
//				          collection.CloseCustomerSerach();
				logger.info("CloseCustomerSerach");
//				          work.ClickOnProfileButton_NEW();
//				          logger.info("ClickOnProfileButton");
//				          collection.LogoutFromApplication();
				logger.info("LogoutFromApplication");
			}

		   @Test(groups = {"Email"},priority = 1,invocationCount =2)
			public void HC_TC_007_EmailWithItemForClosedItem() throws IOException, InterruptedException {
			    driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",10, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			   work.ClickOnCustomerSearchOptiondsa();
			   logger.info("Click on customer search");
			   work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
			   logger.info("Enter customer number");
			   work.ClickOnCollectionInQUKRC();
			   logger.info("Click on collection search");
			   logger.info("ExpandClosedDebitorItem");
			   collection.SelectEmailWithItemForClosedDebterItem1();
			   logger.info("SelectEmailWClickOnCorrespondenceTemplateListithItemForClosedDebterItem");
			   collection.ClickOnCorrespondenceTemplateList1("Serious Reminder");
			   logger.info("ClickOnCorrespondenceTemplateList");
			   collection.RefreshContentInEmailWithItemCopy();
			   collection.ClickOnsendEmailOptionForEmails();
			   logger.info("ClickOnsendEmailOption");
			   collection.ClickOnAuditForCreateAllMailsItem();
			}

		 @Test(groups = {"Email"},priority = 1,invocationCount = 2)
			public void HC_TC_008_EmailForClosedItem() throws IOException, InterruptedException {

			   driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",10, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
				logger.info("Enter customer number");
				logger.info("Click on customer search");
				work.ClickOnCollectionInQUKRC();
				logger.info("Click on collection search");
				logger.info("ExpandClosedDebitorItem");
				collection.Select_closedIteams_SelectEmailoption();
				logger.info("SelectEmailForClosedDebterItem");
				collection.ClickOnCorrespondenceTemplateList1("Rebill Tax Sales Tax");
				logger.info("ClickOnCorrespondenceTemplateList");
				collection.Select_contacts();
				collection.ClickOnsendEmailOptionForEmails();
				logger.info("Click On send Email Option");
				collection.ClickOnAuditForCreateforopenItemEmail();
				//collection.GetRecentTaskID();
				//logger.info("GetRecentTaskID");

			}
		 @Test(priority = 2,groups= {"Collection"},invocationCount = 2)

		 public void En_US_TC_009_Closed_Items_Action_Download_closed_debtor_item_list() throws Exception
		 {
		       driver.get(baseURL);
			   //  driver.get("https://siemens-q.pegacloud.com/prweb/sso");
		         logger.info("URL is launched");
		         LoginPage login= new LoginPage(driver);
		         MyWork work= new MyWork(driver);
		         CollectionPage collection=new CollectionPage(driver);
		         String CustomerNo=XLUtils.getCellData(excelpath2, "Sheet1",10, 3);

		         //login.ClickOnSamrtCardLink();

		         logger.info("Clicked on Smart Card link");

		       LoginByUsername_Password(PEGA_username,PEGA_Password);
	//


		       work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();

		        work.ClickOnCustomerSearchOptiondsa();
		        logger.info("Click on customer search");
		        work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
		       logger.info("Enter customer number");
		        work.ClickOnCollectionInQUKRC();
		        logger.info("Click on collection search");
		              logger.info("ExpandClosedDebitorItem");
		              collection.closed_items();
	}
		 @Test(groups = {"Email"},priority = 1)
			public void UK_TC_007_EmailWithItemForClosedItem() throws IOException, InterruptedException {
				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",10, 1);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
				logger.info("Enter customer number");
				work.ClickOnCollectionInQUKRC();
				logger.info("Click on collection search");
				logger.info("ExpandClosedDebitorItem");
				collection.SelectEmailWithItemForClosedDebterItem1();
				logger.info("SelectEmailWClickOnCorrespondenceTemplateListithItemForClosedDebterItem");
				collection.ClickOnCorrespondenceTemplateList1("Send to Higher");
				logger.info("ClickOnCorrespondenceTemplateList");
				collection.RefreshContentInEmailWithItemCopy();
				collection.ClickOnsendEmailOptionForEmails();
				logger.info("ClickOnsendEmailOption");
				collection.ClickOnAuditForCreateAllMailsItem();
			}

		 @Test(groups = {"Email"},priority = 1)
			public void HC_TC_40_Item_Details() throws Exception {

			    driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",12, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();

				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
				logger.info("Enter customer number");

				logger.info("Click on customer search");
				work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
				logger.info("Click on collection");

				// collection.Selecting_Checkbox();
				collection.ClickOnItem_DetailsIcon();
				collection.Verify_itemDetails();

			}

		 @Test
			public void HC_TC_054_Customer_search_Item_Search() throws InterruptedException, IOException {
			  driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",12, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 collection.closeallwindows();
				// Customer search box
			 work.ClickOnSearch();
			 work.Verify_with_customernumber(CustomerNo);
			 logger.info("Now I am going to verify with customer name on Search page");
			 work.Verify_with_customername("LOGAN HEALTH - CHESTER");
			 logger.info("Now I am going to verify with postalcode on Search page");
			 work.Verify_with_Postal_code("08403");
			 work.Verify_search_with_Collection_ID_HC("CO-5487600");
			 work.Verify_search_with_Cash_Collector_Name("GIRI B");

			 // Search for Items by Reference number (contains), Invoice number (contains),
			 // Assignment (Contains),
			 //	work.Search_for_Items_by_Reference_number("0103958306");
			 // Search for Amount
		//	 work.Search_for_Amount("500");

			}

		 @Test(groups = {"Email"},priority = 1,invocationCount = 2)
			public void HC_TC_015_SendPreDueReminderWithItemcopy() throws IOException, InterruptedException {
			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",16, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
				logger.info("Enter customer number");
				logger.info("Click on customer search");
				work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
				logger.info("Click on collection");
				// collection.SelectCheckBoxForSendEmailWithItem();
				// //collection.SelectCheckBox();
				// collection.ClickOnOtherActionsInQUSRC();
				// Method written for UKRC also works for USRC
				collection.select_Invoice_HC("000999279");
				// collection.Validating_Invoiceforpredue();
				collection.ClickOnOtherActionsInUSRC();
				// collection.ClickOnOtherActions();
				logger.info("Click on Other Actions");
				collection.SendPreDueReminderWithItemCopy();
				logger.info("Select PreDue Reminder With Item Copy");
				collection.RefreshContentInEmailWithItemCopy_HC();
				collection.ClickOnsendEmailOptionForEmails();
				collection.ClickOnAuditForCreateAllMailsItem();

			}


		 @Test(groups = {"Email"},priority = 1,invocationCount = 2)
			public void HC_TC_015_SendPreDueReminderWithout_Itemcopy() throws IOException, InterruptedException {
			   driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",16, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();

				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
				logger.info("Enter customer number");

				logger.info("Click on customer search");
				work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
				logger.info("Click on collection");
				// collection.SelectCheckBoxForSendEmailWithItem();
				// //collection.SelectCheckBox();

				// collection.ClickOnOtherActionsInQUSRC();
				// Method written for UKRC also works for USRC
				collection.select_Invoice_HC("000999279");
				// collection.Validating_Invoiceforpredue();
				collection.Pre_due();
				// collection.ClickOnOtherActions();
				logger.info("Click on Other Actions");
				// collection.SendPreDueReminderWithItemCopy();
				logger.info("Select PreDue Reminder With Item Copy");
				collection.RefreshContentInEmailWithItemCopy_HC();
				collection.ClickOnsendEmailOptionForEmails();
				collection.ClickOnAuditForCreateforpredue();

			}

	@Test(groups = {"Email"},priority = 1)
			public void HC_TC_012_SendDunnigLetter1() throws IOException, InterruptedException {
			    driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = "0000011770";
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC();
			 logger.info("Click on collection");
			 collection.Selecting_Checkbox();
			 logger.info("SelectCheckBoxForSendEmailWithItem");
			 collection.ClickOnsendEmailOption();
			 logger.info("Click On send Email Option");
			 collection.ClickOnAuditForCreateforDunningLatter();

			}
		@Test(priority = 3,groups= {"Collection"},dependsOnMethods= {"HC_TC_012_SendDunnigLetter1"},alwaysRun=true)
//		 @Test(priority = 3,groups= {"Collection"})
			public void HC_TC_012_SendDunnigLetter2() throws Exception {
			    driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = "0000011770";
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
				logger.info("Enter customer number");
				logger.info("Click on customer search");
				work.ClickOnCollectionInQUKRC();
				logger.info("Click on collection");
			//	collection.Selecting_Checkbox_and_select_Dunning();
				logger.info("SelectCheckBoxForSendEmailWithItem");
				collection.UK_select_DunningLatter2_HC();
				logger.info("Select Add Item  NoteAction");
				collection.ClickOnsendEmailOption();
				logger.info("Click On send Email Option");
				collection.ClickOnAuditForCreateforDunningLatter();
			}

		 @Test(groups = {"My Work"},priority = 2)
			public void HC_47_Filtering_Sorting() throws Exception {

			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",20, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();

				collection.US_47_Filtering_Sorting();
				logger.info("Clicked on my customer list ");
				collection.velidating_sort_icon();
				collection.FilteringonHomePage(CustomerNo);
				collection.Datavalidation();
				logger.info("Checking 'status' fliter functionalities on Header ");
	//			collection.Filtering_for_Status_onHomePage_HC();
				logger.info("Checking 'customer' functionalities on Header ");
				collection.Filtering_on_CUSTOMER_HomePage("BAKERSFIELD MEMORIAL HOSPITAL");
				collection.Datavalidation();
				logger.info("Checking 'Postalcode'fliter functionalities on Header ");
				collection.Filtering_on_Postalcode_HomePage("59923");
				collection.Datavalidation();
				logger.info("Checking 'city' fliter functionalities on Header ");
	//			collection.Filtering_on_city_HomePage("CARSON CITY");
	//			collection.Datavalidation();

			}

		 @Test(groups = {"Login & Access"},priority = 2)
			public void HC_TC_048_Switch_App() throws Exception {
				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 22, 1);

				//login.ClickOnSamrtCardLink();

				logger.info("Clicked on Smart Card link");

				LoginByUsername_Password(PEGA_username,PEGA_Password);

				logger.info("Entered code in pop up");

				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection US RC (Cash Collector Manager US RC)");
				logger.info("Cash Collector Manager US RC ");
				work.SwitchTonewWindowInQ();
				// Giri
				System.out.println("Page Tittle" + driver.getTitle());
//				        if(!driver.getTitle().equals("CCMT - Cash Collector Portal")) {
//				        	driver.navigate().back();
//				        	String Expected="CCMT - Cash Collector Portal";
//				        	String Actual=driver.getTitle();
//				        	Assert.assertEquals(Actual, Expected);
		//
//				        }
//				        else if(driver.getTitle().equals("CCMT - Cash Collector Portal")){
//				        	String Expected="CCMT - Cash Collector Portal";
//				        	String Actual=driver.getTitle();
//				        	Assert.assertEquals(Actual, Expected);
		//
//				        }

			}
		 @Test(groups = {"Login & Access"},priority = 2,invocationCount = 2)
			public void HC_TC_052_LogOff() throws IOException, InterruptedException {
				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				DashBoardPage dp = new DashBoardPage(driver);
				CollectionPage collection = new CollectionPage(driver);
				MyProfilePage myprofile = new MyProfilePage(driver);
				OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				//String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 23, 1);
				//login.ClickOnSamrtCardLink();
				// test.log(LogStatus.INFO, "Entered code in pop up");
				LoginByUsername_Password(PEGA_username,PEGA_Password);

				logger.info("Entered code in pop up");
			 work.ClickOnProfileButton_NEW();
			 logger.info("Click on profile");
			 work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection US RC (Cash Collector Manager US RC)");
			 logger.info("Cash Collector Manager US RC ");
			 work.SwitchTonewWindowInQ();

				Thread.sleep(5000);
				work.ClickOnProfileButton1();
				logger.info("Click on profile");

				Thread.sleep(5000);

				work.ClickOnLogoff();
				if (driver.getPageSource().contains("You successfully logged out from Pega.")) {
					logger.info("You successfully logged out from Pega.");
					Assert.assertTrue(true);
				} else {
					logger.info("Your not logged out from Pega.");
					Assert.assertTrue(false);
				}
				Thread.sleep(5000);

				logger.info("logout");

			}

		 @Test(priority = 2,groups= {"Strategy"})
			public void HC_068_Create_strategy() throws Exception {
			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",23, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				logger.info("Going to select mainmenu ");
				AC.CCMT_mainmenu();
				logger.info("click on strategies ");
				collection.Select_strategies();
				collection.Select_Create_new_strategy();
				logger.info("Selected for create new strategy");
				collection.Select_strategyname(strategies_Name);
				logger.info("Going select on Item creation date based actions");
				collection.Select_additem();
				logger.info("click on additemsoption");
				collection.Select_Action("Bala");
				logger.info("Selected label into Action type");
				collection.Select_schedule("Daily");
				logger.info("Selected Action schedule");
				logger.info("Going to setup Advanced Item filters");
				collection.Select_Advanced_Item_filters("Customer Number", CustomerNo);
				logger.info("Going to setup for Recurring dunning action");
				collection.Select_Recurringaction("Dunning", "99,99,99", "1", "Test1");
				logger.info("Going to selct mainmenu");



				collection.closeallwindows();
				AC.CCMT_mainmenu();
				logger.info("Going to select mywork from mainmenu");

				collection.Select_strategies1();
				logger.info("Selected strategies option from mainmenu");
				logger.info("Going to fliter with strategiesname ");
				collection.Fliter_By_Strategy1(strategies_Name);
				collection.Validating_for_Strategy(strategies_Name);
			}

		 @Test(priority = 3,groups= {"Collection"},dependsOnMethods= {"HC_068_Create_strategy"})
			public void HC_27_Change_strategy_assignment_to_a_collection() throws Exception {

			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",23, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
				logger.info("Enter customer number");

				logger.info("Click on customer search");
				work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
				logger.info("Click on collection");
				logger.info("Going to click on action in collection page");
				collection.Strategy_actions();
				logger.info("Going to click on Assign strategy under Actions section");
				collection.Select_Assign_strategy();
				collection.Search_Strategy_and_submit(strategies_Name);
				collection.Click_Runstrategy();

			}

//		 @Test(priority = 3,groups= {"Collection"},dependsOnMethods= {"HC_27_Change_strategy_assignment_to_a_collection"})
		 @Test(priority = 3,groups= {"Collection"})
			public void HC_34_Strategies_Reassign_strategy_in_bulk_for_multiple_collections() throws Exception {

				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				DashBoardPage dp = new DashBoardPage(driver);
				CollectionPage collection = new CollectionPage(driver);
				MyProfilePage myprofile = new MyProfilePage(driver);
				Assigncollector AC = new Assigncollector(driver);
				OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String customernumber = XLUtils.getCellData(excelpath2, "Sheet1", 26, 1);
				String CollectorName = "GIRI B";
				String New_strategies_Name = "strategy_UK_Test_GPS";
				//login.ClickOnSamrtCardLink();

				logger.info("Clicked on Smart Card link");

				LoginByUsername_Password(PEGA_username,PEGA_Password);
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();

				AC.CCMT_mainmenu();
				logger.info("Going to select mywork from mainmenu");

				collection.Select_strategies1();

				logger.info("Selected strategies option from mainmenu");
				logger.info("Going to fliter with strategiesname ");
				collection.Fliter_By_Strategy1(strategies_Name);
				logger.info("Checking the status of the strategy.");

				collection.Validating_for_reassignStrategy(strategies_Name);
				logger.info("Verify the strategy's collection of counts...");
				collection.Validating_for_numberic_value_Strategies();
				logger.info("Clicking on reassign for strategy...");
				collection.Select_Reassign();
				collection.Select_new_Strategy(New_strategies_Name);

				collection.Fliter_By_Strategy2(New_strategies_Name);
				collection.Validating_for_Strategy2(New_strategies_Name);
				collection.Validating_for_numberic_value_Strategies();

			}
		 @Test(groups = {"Email"},priority = 1,invocationCount = 2)
			public void HC_TC_017_RetrospectiveBalanceConfirmation() throws IOException, InterruptedException {
			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				DashBoardPage dp = new DashBoardPage(driver);
				CollectionPage collection = new CollectionPage(driver);
				MyProfilePage myprofile = new MyProfilePage(driver);
				Assigncollector AC = new Assigncollector(driver);
				OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String customernumber = XLUtils.getCellData(excelpath2, "Sheet1", 26, 3);
				//login.ClickOnSamrtCardLink();

				logger.info("Clicked on Smart Card link");

				LoginByUsername_Password(PEGA_username,PEGA_Password);
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(customernumber);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC(); // work.ClickOnCollectionInDev();
			 logger.info("Click on collection");
			 collection.ClickOnOtherActionsInQUKRC();
			 logger.info("SelectCheckBoxForSendEmailWithItem");
			 collection.RetrospectiveBalanceConfirmationForUSRC();
			 logger.info("Select print Balance Confirmation");
			 collection.SelectDateForReztrospectiveBalanceConfirmation("01/15/2023");
			 logger.info("Select print Balance Confirmation");
			 collection.ClickOnSubmitButton();
			 logger.info("Select print Balance Confirmation");
			 collection.ClickOnsendEmailOption();
			 logger.info("Click On send Email Option");
			 collection.ClickOnAuditForforRetrospective();

			}

		 @Test(priority = 2,groups= {"Strategy"})
			public void HC_037_Strategy_automatic_execution() throws Exception {
			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				String CollectorName = "GIRI B";
				Assigncollector AC = new Assigncollector(driver);
				String strategies_Name = "strategy_UK_Test_GPS";
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",27, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				Thread.sleep(5000);
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC();
			 Thread.sleep(5000);
			 collection.SelectCheckBoxanddisputeoptionforledingInvoice_HC_(strategies_Name,"Balance","Auto");
			 logger.info("click on strategies ");
//		collection.Select_strategies();
//		collection.Select_Create_new_strategy();
//		logger.info("Selected for create new strategy");
//		collection.Select_strategyname(strategies_Name);
//		logger.info("Going select on Item creation date based actions");
//		collection.Select_item_date_additem();
//		logger.info("click on Item due date based actions");
//		collection.Select_Action("Balance Confirmation");
//		logger.info("Selected label into Action type");
//		logger.info("Going select for day from due");
//		collection.select_days_from_due_And_Select_Excutiontype("Auto", "204");
			 collection.Select_scope("Any Invoice");
			 logger.info("Going to setup Advanced Item filters");
			 collection.Select_Advanced_Item_filters("Customer Number", CustomerNo);
			 collection.Select_Recurringaction("Dunning", "12,19,2022", "1", "Test2");
			 collection.closeallwindows();
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC1();
			 // work.ClickOnCollectionInDev();
			 logger.info("Click on collection");
			 logger.info("Going to click on action in collection page");
			 collection.Strategy_actions();
			 logger.info("Going to click on Assign strategy under Actions section");
			 collection.Select_Assign_strategy();
			 collection.Search_Strategy_and_submit(strategies_Name);
			 collection.Click_Runstrategy();


			}

		 @Test(priority = 2,groups= {"Login & Access"})

			public void HC_TC_050_Verify_Profile() throws Exception {
				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				DashBoardPage dp = new DashBoardPage(driver);
				CollectionPage collection = new CollectionPage(driver);
				MyProfilePage myprofile = new MyProfilePage(driver);
				Assigncollector AC = new Assigncollector(driver);
				OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
                Thread.sleep(7000);
			 work.ClickOnProfileButton1();
			 myprofile.US_Profile();
			 myprofile.Select_Edit_profile();
			 logger.info("Going to add skills into profile");
			 myprofile.add_Skills();
			 // logger.info("To check whether signatures are added or not");
			 // myprofile.Edit_signature();
			 //  myprofile.Set_Email_Signature();

			}

		 @Test(priority = 2,groups= {"Email"},invocationCount = 2)
			public void HC_TC_055_BulkAssignEmails() throws IOException, InterruptedException {
				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",29, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 work.ClickOnBurgerMenu();
			 logger.info("ClickOnBurgerMenu");
			 work.SelectBulkAssignFromburgerMenu();
			 logger.info("SelectBulkAssignFromburgerMenu");
			 work.SearchCustomerNoInBulkAssignEmailsPage(CustomerNo);
			 logger.info("SearchCustomerNoInBulkAssignEmailsPage");
			 work.ClickSearchButtonInBulkAssigEmailsPage();
			 logger.info("ClickSearchButtonInBulkAssigEmailsPage");
			 logger.info("SlectRadioButtonInBulkAssignEmailsPage");
			 work.ClickAssignInBulkAssigEmailsPage();


			}

		 @Test(priority = 2, groups = { "Dispute" })
			public void HC_TC_066_CreateDispute() throws Exception {
			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
			 Collectionpage2   collection2 = new Collectionpage2(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",30, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC();
			 logger.info("Click on collection search");
			 collection.SelectCheckBoxanddisputeoption_HC();
			 collection.Select_Dispute_reason_HC("065-Short Payed Serv. Inv.","a");
			 collection.AddNotesInCustomerCall();
			 collection.Select_routeto();
			 collection.Select_Email_click_on_Addreceipt_HC("giri.b.ext@siemens.com");
			 collection.Escalate_this_dispute();
			 collection.Create_Follow_up_action_dispute();
			 collection.SelectFollowUpCallDateAndTime2();
			 collection.submit1();
			 collection.closeallwindows();
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC1();
			 logger.info("Click on collection search");
			 collection.ClickOnAuditForCreateforDispute();
			 collection.closeallwindows();
			 work.Click_on_Dispute_up_up(CustomerNo);
			 collection.Verifying_Data_Dispute();
			}

		// @Test(priority = 2, groups = { "Dispute" },dependsOnMethods= {"HC_TC_066_CreateDispute"},invocationCount = 2)
		 @Test(priority = 2, groups = { "Dispute" },invocationCount = 2)
			public void HC_TC_057_Reslove_Dispute() throws Exception {
			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
			 Collectionpage2 collection2 = new Collectionpage2(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",31, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC();
			 logger.info("Click on collection search");
			 collection.SelectCheckBoxanddisputeoption_HC();
			 collection.Select_Dispute_reason_HC("065-Short Payed Serv. Inv.","a");
			 collection.AddNotesInCustomerCall();
			 collection.Select_routeto();
			 collection.Select_Email_click_on_Addreceipt_HC("giri.b.ext@siemens.com");
			 collection.Escalate_this_dispute();
			 collection.Create_Follow_up_action_dispute();
			 collection.SelectFollowUpCallDateAndTime2();
			 collection.submit1();
			 collection.closeallwindows();
			 work.ClickOnCustomerSearchOption1();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC1();
			 logger.info("Click on collection search");
			 collection.Click_on_DisputeIcon();
			 collection.Verify_Disputepage_SI1();
			 collection.Click_on_HandleDispute();
			 collection.Verify_and_Reslove_Dispute_HC_US();
			 collection.Verify_Reslovepage_for_Dispute_FR();
			 collection.closeallwindows();
			 work.ClickOnCustomerSearchOption1();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC1();
			 collection.Hide_button1();
			 collection.ClickOnAuditForCreateforDispute_Reslove_MX();

			}


	//	 @Test(priority = 2, groups = { "Dispute" },dependsOnMethods= {"HC_TC_066_CreateDispute"})
		 @Test(priority = 2, groups = { "Dispute" },invocationCount = 2)
			public void HC_TC_059_Dispute_withdraw() throws Exception {

				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",32, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC();
			 logger.info("Click on collection search");
			 collection.SelectCheckBoxanddisputeoption_HC();
			 collection.Select_Dispute_reason_HC("065-Short Payed Serv. Inv.","a");
			 collection.AddNotesInCustomerCall();
			 collection.Select_routeto();
			 collection.Select_Email_click_on_Addreceipt_HC("giri.b.ext@siemens.com");
			 collection.Escalate_this_dispute();
			 collection.Create_Follow_up_action_dispute();
			 collection.SelectFollowUpCallDateAndTime3();
			 collection.submit1();
			 collection.closeallwindows();
			 work.ClickOnCustomerSearchOption1();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC1();
			 //	collection.closeallwindows();
			 logger.info("Click on collection search");
			 //	collection.verify_Icon_dispute_HC();
			 // collection.DisputeCases_ID();
			 collection.Click_on_DisputeIcon();
			 collection.Verify_Disputepage_PT();
			 collection.Click_on_Action();
			 collection.Click_withdraw();
		collection.Hide_button1();
			 collection.ClickOnAuditForCreateforDispute_withdrawn_PT();

			}

		// @Test(priority = 2, groups = { "Dispute" },dependsOnMethods= {"HC_TC_066_CreateDispute"})
		 @Test(priority = 2, groups = { "Dispute" },invocationCount = 2)
			public void HC_TC_058_Dispute_Reject() throws Exception {
			 driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",33, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 work.ClickOnCustomerSearchOptiondsa();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC();
			 logger.info("Click on collection search");
			 collection.SelectCheckBoxanddisputeoption_HC();
			 collection.Select_Dispute_reason_HC("065-Short Payed Serv. Inv.","a");
			 collection.AddNotesInCustomerCall();
			 collection.Select_routeto();
			 collection.Select_Email_click_on_Addreceipt_HC("giri.b.ext@siemens.com");
			 collection.Escalate_this_dispute();
			 collection.Create_Follow_up_action_dispute();
			 collection.SelectFollowUpCallDateAndTime3();
			 collection.submit1();
			 collection.closeallwindows();
			 work.ClickOnCustomerSearchOption2();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			 logger.info("Enter customer number");
			 logger.info("Click on customer search");
			 work.ClickOnCollectionInQUKRC1();
			 logger.info("Click on collection search");
			 collection.Click_on_DisputeIcon();
			 collection.Verify_Disputepage_GP_PL();
			 collection.Click_on_HandleDispute();
			 collection.Verify_and_Reject_Dispute_GP_PT();
			 collection.Verify_Reslovepage_for_Dispute_AU();
			 collection.closeallwindows();
			 work.ClickOnCustomerSearchOption2();
			 logger.info("Click on customer search");
			 work.EnterCustomerNumberInSearchAndClickOnSearchButton1(CustomerNo);
			 logger.info("Enter customer number");
			 work.ClickOnCollectionInQUKRC1();
			 logger.info("Click on customer search");
			 collection.Hide_button1();
			 collection.ClickOnAuditForCreateforDispute_Reject_AU_GP();

			}

			@Test(priority = 2,groups= {"Login & Access"})
			public void HC_TC_044_Other_User_Work() throws Exception {
				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",32, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();

				work.BurgerMenu();
				logger.info("Click on BurgerMenu");
				work.Click_on_Other_work();
				Thread.sleep(5000);
				collection.Select_User("Saleem Pasha");
				logger.info("Entered the User name in search box");
				collection.Verify_page();

			}

			@Test(priority = 2,groups= {"Collection"})
			public void HC_TC_006_Manual_data_Sync() throws Exception {
				driver.get(baseURL);
				logger.info("URL is launched");
				LoginPage login = new LoginPage(driver);
				MyWork work = new MyWork(driver);
				CollectionPage collection = new CollectionPage(driver);
				//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
				String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",36, 3);
				//login.ClickOnSamrtCardLink();
				logger.info("Clicked on Smart Card link");
				LoginByUsername_Password(PEGA_username,PEGA_Password);
				logger.info("Entered code in pop up");
				work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
				logger.info("Switch to Cash Collection Manager Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				work.ClickOnCustomerSearchOptiondsa();
				logger.info("Click on customer search");
				work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
				logger.info("Enter customer number");
				logger.info("Click on customer search");
				work.ClickOnCollectionInQUKRC();
				logger.info("Click on collection");
				collection.Select_Actions();
				logger.info("Click on Actions");
				collection.Click_on_Synchronize_Data();
				logger.info("Click on Synchronize Data under Actions");
				collection.Verify_Debtor_TimeStamp();
				collection.Clik_on_Start_button_and_Verify_the_successful_messege();
				//work.logoff();
			}

			 @Test(priority = 2,groups= {"Collection"},invocationCount = 3)

				public void HC_TC_060_ItemNote() throws Exception {
				 driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",37, 3);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					work.ClickOnCustomerSearchOptiondsa();
					logger.info("Click on customer search");
					work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
					logger.info("Enter customer number");
					logger.info("Click on customer search");
					work.ClickOnCollectionInQUKRC();
					logger.info("Click on collection");
					collection.SelectCheckBoxes_HC();
					work.Click_on_Add_itemNote();
					work.Add_Note_To_Selected_Debtor_Items("Test by Giri");
					work.Click_on_submit();
					work.Click_on_Add_itemNote1();
					logger.info("Click on Add item note button");
					work.verify_previous_Note_HC2();
					collection.Hide_button1();
					collection.ClickOnAuditForCreateforItem_Note();

				}

			 @Test(priority = 2,groups= {"My Work"})
				public void HC_TC_045_Drill_down_within_ageing_buckets() throws InterruptedException, Exception {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					work.Click_Graph();
				    logger.info("Click on Graph label on Home page");
					logger.info("The table data of No.invoice will be analyzed");
					work.Select_Aging_table();
					work.verify_Aging_second_row();
					work.verify_Aging_Thrid_row();
					work.verify_Aging_4_row();
					work.verify_Aging_5_row();
				}

			 @Test(priority = 2,groups= {"Collection"})
				public void UK_TC_06_Manual_synchronization_of_collection_data() throws InterruptedException, IOException {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 38, 1);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					logger.info("Click on Search");
					work.ClickOnSearch();
					work.Verify_with_customernumber("0008275820");
					logger.info("Now I am going to verify with customer name on Search page");
					work.Verify_with_customername("AFFIDEA DIAGNOSTICS IRELAND LTD");
					logger.info("Now I am going to verify with postalcode on Search page");
					work.Verify_with_Postal_code("BS37 5NN");
					// Collection & Contact
					// Search for Customers by Collection ID, Contact Name, Contact E-mail
					// (contains).
					work.Verify_search_with_Collection_ID("CO-5441123");
					work.Verify_search_with_Cash_Collector_Name("GIRI B");
					// Search for Items by Reference number (contains), Invoice number (contains),
					// Assignment (Contains),
					work.Search_for_Items_by_Reference_number("414S1051120173");
					// Search for Amount
					work.Search_for_Amount("1,200.00");
				}

			 @Test(priority = 2,groups= {"Dispute"},invocationCount = 2)
				public void HC_TC_053_Closed_Open_Disputes_To_verify_user_is_able_to_overview_Open_Closed_Disputes()
						throws Exception {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					Assigncollector AC = new Assigncollector(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					Thread.sleep(8000);
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (CashColHCUS BusinessUser RC)");
					logger.info("Switch to Cash Collection Healthcare US RC (CashColHCUS BusinessUser RC) ");
					work.SwitchTonewWindowInQ();
					AC.CCMT_mainmenu();
					work.Click_open_Dispute();
					work.verify_openDispute_In_BU();
					logger.info("Check the BU portal for closed dispute items");
					AC.CCMT_mainmenu();
					work.Click_Close_Dispute();
					work.verify_ClosedDispute_In_BU();

				}

			 @Test(priority = 3,groups= {"Email"})
				public void HC_TC_022_Setting_reminder_for_collection() throws Exception {
				    driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 38, 3);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					logger.info("Click on Search");
					logger.info("Switching to my work window");
				 work.ClickOnCustomerSearchOptiondsa();
				 logger.info("Click on customer search");
				 work.EnterCustomerNumberInSearchAndClickOnSearchButton_puase(CustomerNo);
				 logger.info("Enter customer number");
				 logger.info("Click on customer search");
				 work.ClickOnCollectionInQUKRC();
				 logger.info("Click on collectoion");
				 collection.Select_Infromation_for_Verify_CashcollectorName();
				 collection.Hide_button1();
				 collection.ClickOnReminder();

//		collection.SelectFollowUpCallDateAndTimeforReminder();
//		collection.Select_type_drop_down();
//		collection.Select_note_for_reminder_and_submit();
//		collection.verify_AuditNote();
				 collection.closeallwindows();
				 collection.Verify_Reminder_Follow_Up_Call();
				 work.getReminderSize(CustomerNo);
				}

			 @Test(priority = 3,groups= {"Collection"},invocationCount = 2)
				public void HC_TC_023_Collection_Pause_and_Resume_a_collection() throws Exception {
				    driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1", 40, 3);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
				 work.ClickOnCustomerSearchOptiondsa();
				 logger.info("Click on customer search");
				 work.EnterCustomerNumberInSearchAndClickOnSearchButton1_pause(CustomerNo);
				 logger.info("Enter customer number");
				 logger.info("Click on customer search");
				 work.ClickOnCollectionInQUKRC1();
				 collection.ClickOnPause();
				 collection.add_Note("Pause by Giri");
				 collection.Select_Reason_for_Pause();
				 collection.SelectFollowUpCallDateAndTimeforReminder();
				 collection.Click_on_Submit();
				 collection.closeallwindows();
				 collection.Click_on_Customer();
				 work.Fliter_Action2(CustomerNo);
				 collection.Verify_the_Collection_for_Paused();
				 work.ClickOnCustomerSearchOption1();
				 logger.info("Click on customer search");
				 work.EnterCustomerNumberInSearchAndClickOnSearchButton1_pause(CustomerNo);
				 logger.info("Enter customer number");
				 logger.info("Click on customer search");
				 work.ClickOnCollectionInQUKRC1();
				 collection.ClickOnResumecollection();
				 collection.ClickOnSubmitforResume();
				 collection.Select_Infromation();
				}
			 @Test(priority = 3,groups= {"Collection"},invocationCount = 2)
				public void HC_TC_029_Add_Audit_Note() throws Exception {
				 driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",40, 3);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					logger.info("Click on Search");
					logger.info("Switching to my work window");
				 work.ClickOnCustomerSearchOptiondsa();
				 logger.info("Click on customer search");
				 work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
				 logger.info("Enter customer number");
				 logger.info("Click on customer search");
				 work.ClickOnCollectionInQUKRC();
				 collection.Select_Add_Audit_Note();
				 collection.Note_Title_for_Audit_Note();
				 collection.Hide_button1();
				 collection.ClickOnAuditForCreateforAdd_AuditNote_HC();
				 collection.Checking_Audit_section();
				}

			 @Test(priority = 3,groups= {"Email"})
				public void HC_038_Campaign() throws Exception {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					DashBoardPage dp = new DashBoardPage(driver);
					CollectionPage collection = new CollectionPage(driver);
					MyProfilePage myprofile = new MyProfilePage(driver);
					Assigncollector AC = new Assigncollector(driver);
					OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String customernumber = XLUtils.getCellData(excelpath2, "Sheet1",41, 1);
					String CollectorName = "GIRI B";
					String Campaign_Name = "Campaign_UK_2225";
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
				 AC.CCMT_mainmenu();
				 logger.info("click on Campaign ");
				 collection.Select_Campaign();
				 collection.Select_Create_new_Campaign();
				 logger.info("Selected for create new strategy");
				 collection.Select_Campaign(Campaign_Name);
				 collection.Select_additem2();
				 collection.Select_Action_Campagins("Invoice Copy");
				 collection.Add_Label_for_Action();
				 collection.Select_Advanced_Item_filters("Customer Number", customernumber);
				 collection.Click_on_Sunmit();
				 collection.Click_on_Schedule_Campaign();
				 work.ClickOnProfileButton1();
				 collection.closeallwindows();
				 AC.CCMT_mainmenu();
				 logger.info("click on Campaign ");
				 collection.Select_Campaign1();
				 collection.Fliter_the_CampaignName(Campaign_Name);
				 collection.Validating_for_Campaign(Campaign_Name);

				}

			 @Test(priority = 2,groups= {"Dispute"},invocationCount = 2)
				public void UK_TC_001_To_raise_dispute_on_same_line_item_which_is_already_under_dispute()
						throws IOException, Exception {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					DashBoardPage dp = new DashBoardPage(driver);
					CollectionPage collection = new CollectionPage(driver);
					MyProfilePage myprofile = new MyProfilePage(driver);
					Assigncollector AC = new Assigncollector(driver);
					OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String customernumber = "0000328163";
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					work.ClickOnCustomerSearchOptiondsa();
					logger.info("Click on customer search");
					work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(customernumber);
					logger.info("Enter customer number");
					logger.info("Click on customer search");
					work.ClickOnCollectionInQUKRC();
					logger.info("Click on collection search");
					//collection.SelectCheckBoxes_HC();
					collection.SelectCheckBoxanddisputeoption1_HC();
				}

			 @Test(groups = {"Email"},priority = 1)
				public void HC_TC_065_SendPreDueReminderAlreadyDue() throws IOException, InterruptedException {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",43, 3);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection Manager Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					work.ClickOnCustomerSearchOptiondsa();
					logger.info("Click on customer search"); // sometimes it works till here only
					work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
					logger.info("Enter customer number"); // sometimes it works till here only
					logger.info("Click on customer search");
					work.ClickOnCollectionInQUKRC();
					logger.info("Click on collection");
					collection.ClickOnOtherActions_HC();
					logger.info("Click on Other Actions");
					collection.SendPreDueReminderWithItemCopy_HC();
					logger.info("Select PreDue Reminder With Item Copy");
					collection.IsOneOfTheSelectedDebtorItemIsAlreadyDue();
					logger.info(" One of the selected debtor item(s) is already due.");
				}

			 @Test(groups = {"My work"},priority = 3,invocationCount = 3)
				public void HC_TC_03_User_Menu_Manage_Work_Queues() throws Exception {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",45, 3);
					String Name_for_Business_Basket = "AutossctiosnTer";
					Assigncollector AC = new Assigncollector(driver);
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection  Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					logger.info("Going to select mainmenu ");
				 AC.CCMT_mainmenu();
				 logger.info("click on Manage work_queues ");
				 work.Click_on_work_queues();
				 work.Select_Business_workbaskets();
				 work.Select_New_workbaskets();
				 work.Select_Name_of_Basket_and_CC_Work_group(Name_for_Business_Basket, "0200", "Dispute");
				 work.Verify_Name_of_Organization_and_Unit_Division();
				 work.Fliter_the_workBasket(Name_for_Business_Basket);
				 work.verify_the_crossIcon();
				 work.Click_on_ChangeAvailability();
				 work.Fliter_the_workBasket(Name_for_Business_Basket);
				 work.verify_the_crossIcon1();
				 work.Click_on_ClickOnfirstrow("giri.b.ext@siemens.com");
				 work.Add_Additional_Email("bgiri112233@gmail.com");
				 logger.info("Now it's going to create Dispute and assign the work basket");
				 collection.closeallwindows();
				 work.ClickOnCustomerSearchOption2();
				 logger.info("Click on customer search");
				 work.EnterCustomerNumberInSearchAndClickOnSearchButton12(CustomerNo);
				 logger.info("Enter customer number");
				 work.ClickOnCollectionInQUKRC1();
				 collection.SelectCheckBoxanddisputeoption_HC();
				 collection.Select_Dispute_reason_HC("065-Short Payed Serv. Inv.","a");
				 collection.Select_routetogroup1();
				 collection.AddNotesInCustomerCall();
				 work.Select_Email_click_on_Group_FBS(Name_for_Business_Basket);
				 collection.Escalate_this_dispute();
				 collection.Create_Follow_up_action_dispute();
				 collection.SelectFollowUpCallDateAndTime2();
				 collection.submit1();
				 collection.Click_on_DisputeIcon_US_Enery();
				 work.Verify_the_BU_Name(Name_for_Business_Basket);
				 logger.info("**********Now it's time to verify the Total Assignments for WorkBasket*******");
				 collection.closeallwindows();
				 logger.info("Going to select mainmenu ");
				 AC.CCMT_mainmenu1();
				 logger.info("click on Manage work_queues ");
				 work.Click_on_work_queues();
				 work.Select_Business_workbaskets1();
				 work.Fliter_the_workBasket(Name_for_Business_Basket);
				 work.verify_the_totalAssignments();
				 logger.info("**********Go to check workBasket in work queue from profile*******");
				 collection.closeallwindows();
				 logger.info("Click on profile");
				 work.Click_on_WorkQueues_from_profile_HC(Name_for_Business_Basket);

				}

//			 @Test(groups = {"My Work"},priority = 3,dependsOnMethods = {"HC_TC_03_User_Menu_Manage_Work_Queues"})
			 @Test(groups = {"My Work"},priority = 3)
				public void HC_TC_031_User_Personal_Menu_work_queues() throws Exception {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",46, 1);
					String Name_for_Business_Basket = "workest_24ds";
					Assigncollector AC = new Assigncollector(driver);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection  Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					Thread.sleep(5000);
					work.ClickOnProfileButton1();
					logger.info("Click on profile");
					collection.Click_on_WorkQueues_from_profile(Name_for_Business_Basket);
				}

			 @Test(priority = 3,groups= {"Collection"},invocationCount = 2)
				public void HC_TC_030_Edit_the_account_notes_in_a_collection_and_show_then_history() throws Exception {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo =XLUtils.getCellData(excelpath2, "Sheet1", 46, 3);
					Assigncollector AC = new Assigncollector(driver);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					String Note = "Test01";
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection  Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
				 work.ClickOnCustomerSearchOptiondsa();
				 logger.info("Click on customer search");
				 work.EnterCustomerNumberInSearchAndClickOnSearchButton01(CustomerNo);
				 logger.info("Enter customer number");
				 logger.info("Click on customer search");
				 work.ClickOnCollectionInQUKRC();
				 logger.info("Click on collection");
				 collection.expand_the_customer_section();
				 collection.AddNotesforDispute(Note);
				 //work.Add_Account_Note(Note);
				 work.Click_on_Update_HC1(Note);
				 logger.info("**********Going to verify the show History*********");
				 work.Click_on_Show_History_HC_US(Note);
				 logger.info("**********Check the Cash Collector's name and time and date under \"Show History\"*********");
				 work.Verify_Cash_collector_Name_and_Timestamp();
				 logger.info("Log off");
				}

			 @Test(priority = 3,groups= {"Collection"})
				public void HC_TC_021_Leading_invoice() throws InterruptedException, Exception {
				 driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo =XLUtils.getCellData(excelpath2, "Sheet1", 48, 3);
					Assigncollector AC = new Assigncollector(driver);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection  Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					work.ClickOnCustomerSearchOptiondsa();
					logger.info("Click on customer search");
					work.EnterCustomerNumberInSearchAndClickOnSearchButton01(CustomerNo);
					logger.info("Enter customer number");
					logger.info("Click on customer search");
					work.ClickOnCollectionInQUKRC();
					logger.info("Click on collection");
					logger.info("****Changing the leading item***");
					collection.SelectCheckBoxanddisputeoptionforledingInvoice_HC();
					collection.otheraction_LeadingInvoice_change();
					collection.Verify_Flagicon();
					logger.info("****Set up the items that are not leading***");
					collection.SelectCheckBoxanddisputeoptionforledingInvoice1_HC();
					collection.OtherActions();
					logger.info("Click on otheractions");
					collection.Mark_Not_Leading_Item();
					collection.Verify_Not_Leading_Icon();
					logger.info("****The Not_Leading_Icon will be removed***");
					collection.SelectCheckBoxanddisputeoptionforledingInvoice2_HC();
					collection.OtherActions();
					logger.info("Click on otheractions");
					collection.Remove_not_LeadingItem();
					collection.Verify_remove_Not_Leading_Icon();
				}

			 @Test(priority = 3,groups= {"My Work"})
				public void HC_TC_043_To_verify_the_behaviour_of_Worklist_Tiles() throws Exception {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					Assigncollector AC = new Assigncollector(driver);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart ]Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection  Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
				 work.clickOnMyCustomer1();
				 logger.info("Going to check for Overdue Tasks on HomePage");
				 work.Click_ON_Overdue();
				 logger.info("Going to check for My Tasks list on HomePage");
				 work.Click_ON_MYTask();
				 logger.info("Going to check for MyTasks emails list on HomePage");
				 work.Click_ON_Unassignemails();
				 logger.info("Going to check for 'Promised to Pay' list on HomePage");
				 work.Click_ON_Promised_to_Pay();
				 logger.info("Going to check for 'My Open Disputes' list on HomePage");
				 work.Click_ON_My_open_Disputes();
				}

			 @Test(priority = 3,groups= {"Collection"})
				public void HC_TC_049_Bulk_Actions() throws IOException, InterruptedException {
					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					DashBoardPage dp = new DashBoardPage(driver);
					CollectionPage collection = new CollectionPage(driver);
					MyProfilePage myprofile = new MyProfilePage(driver);
					Assigncollector AC = new Assigncollector(driver);
					OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection  Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					Thread.sleep(5000);
				 work.ClickOnProfileButton1();
				 logger.info("Clicked on profile");
				 work.Click_On_Bulkactions();
				 work.select_for_type_of_bulk_action();
				 work.Verify_assign_to_operatorname();
				 work.Select_lineitem_for_transfor();
				 work.CaseID();
				 work.Select_Transfer_from_SelectActions();
				 work.Transfer_assignment("Z004KWYD");
//				 work.verify_the_lineitem_for_Transferred();

				}

			 @Test(priority = 3,groups= {"Login & Access"},invocationCount = 2)
			 public void HC_TC_051_Availability() throws Exception {

			 	driver.get(baseURL);
			 	logger.info("URL is launched");
			 	LoginPage login = new LoginPage(driver);
			 	MyWork work = new MyWork(driver);
			 	DashBoardPage dp = new DashBoardPage(driver);
			 	CollectionPage collection = new CollectionPage(driver);
			 	MyProfilePage myprofile = new MyProfilePage(driver);
			 	Assigncollector AC = new Assigncollector(driver);
				 String CustomerNo =XLUtils.getCellData(excelpath2, "Sheet1",48, 3);
			 	OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
			 	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			 	//login.ClickOnSamrtCardLink();
			 	logger.info("Clicked on Smart Card link");
			 	LoginByUsername_Password(PEGA_username,PEGA_Password);
			 	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				 collection.closeallwindows();
				 Thread.sleep(5000);
				 work.ClickOnProfileButton1();
				 logger.info("Clicked on profile");
				 work.Click_On_Availability();
//	work.Select_Send_automatic_reply();
				 work.Select_From_Date();
				 work.Select_To_Date();
				 work.Set_Default_to_assignee_2("Z004N4XR",CustomerNo);
				 work.ClickOnProfileButton1();
				 work.Click_On_Availability();
				 collection.Delect_Availability_dates();
				 work.Verify_the_page_tittle();


			 }
			 @Test(priority = 3,groups= {"Collection"})
			 public void HC_TC_056_Calendar() throws Exception {

			 	driver.get(baseURL);
			 	logger.info("URL is launched");
			 	LoginPage login = new LoginPage(driver);
			 	MyWork work = new MyWork(driver);
			 	DashBoardPage dp = new DashBoardPage(driver);
			 	CollectionPage collection = new CollectionPage(driver);
			 	MyProfilePage myprofile = new MyProfilePage(driver);
			 	Assigncollector AC = new Assigncollector(driver);
			 	OtherUsersWorkPage otheruser = new OtherUsersWorkPage(driver);
			 	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			 	//login.ClickOnSamrtCardLink();
			 	logger.info("Clicked on Smart Card link");
			 	LoginByUsername_Password(PEGA_username,PEGA_Password);
			 	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 	AC.CCMT_mainmenu();
			 	logger.info("click on strategies ");
			 	collection.Select_Calendar();
			 	collection.verify_the_calendarview();
			 	collection.Checking_for_Options();
			 	//work.logoff();
			 	logger.info("Log off");
			 }

			 @Test(priority = 3,groups= {"Collection"})
			 public void HC_TC_028_Bulk_selection_of_debtor_items() throws Exception {
			 	driver.get(baseURL);
			 	logger.info("URL is launched");
			 	LoginPage login = new LoginPage(driver);
			 	MyWork work = new MyWork(driver);
			 	CollectionPage collection = new CollectionPage(driver);
			 	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			 	String CustomerNo =XLUtils.getCellData(excelpath2, "Sheet1",48, 3);
			 	String Addnote = "Test by Giri";
			  	String Addnote2 = "Giri By 2";
			 	//login.ClickOnSamrtCardLink();
			 	logger.info("Clicked on Smart Card link");
			 	LoginByUsername_Password(PEGA_username,PEGA_Password);
			 	logger.info("Entered code in pop up");
			 	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			  	work.ClickOnCustomerSearchOptiondsa();
			  	logger.info("Click on customer search");
			  	work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
			  	logger.info("Enter customer number");
			  	logger.info("Click on customer search");
			  	work.ClickOnCollectionInQUKRC();
			  	logger.info("Click on collection");
			  	work.Enteredinvoice__number_HC();
			  	logger.info("Go to add note for selected Line iteam");
			  	work.Click_on_Add_itemNote();
			  	work.Add_Note_To_Selected_Debtor_Items(Addnote);
			  	work.Click_on_submit();
			  	work.Verify_LineIteamNote_HC(Addnote);
			  	work.Verify_Second_LineIteamNote_HC(Addnote);
			  	logger.info("********Notes were added successfully to both line items.*******");

			  	logger.info("********Going to check with Delimiter(;)*******");
			  	work.Enteredinvoice__number_US1();
	         	work.Enter_Text_HC();
	         	work.Delimiter();
	         	work.submit();

	         	work.Click_on_Add_itemNote1();
	         	work.Add_Note_To_Selected_Debtor_Items1(Addnote2);
	         	work.Click_on_submit1();
	         	work.Verify_LineIteamNote_HC1(Addnote2);
	         	work.Verify_Second_LineIteamNote_HC1(Addnote2);
	         	logger.info("********Notes were added successfully to both line items.*******");
			 }

			 @Test(priority = 3,groups= {"Collection"})
			 public void UK_TC_020_Manage_attachments_in_a_collection() throws Exception {
			 	driver.get(baseURL);
			 	logger.info("URL is launched");
			 	LoginPage login = new LoginPage(driver);
			 	MyWork work = new MyWork(driver);
			 	CollectionPage collection = new CollectionPage(driver);
			 	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			 	String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",49, 3);
			 	String Addnote = "Test by Giri";
			  	String Addnote2 = "Giri By 2";
			 	//login.ClickOnSamrtCardLink();
			 	logger.info("Clicked on Smart Card link");
			 	LoginByUsername_Password(PEGA_username,PEGA_Password);
			 	logger.info("Entered code in pop up");
			 	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
//			 	work.ClickOnCustomerSearchOptiondsa();
//			   	logger.info("Click on customer search");
//			   	work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
//			   	logger.info("Enter customer number");
//			   	logger.info("Click on customer search");
//			   	work.ClickOnCollectionInQUKRC();
//			   	logger.info("Click on collection");
//			   	work.Click_on_Attachment();
//			  	work.Select_file_from_desktop();
//			  	work.Click_on_Attach();
//			  	work.verify_the_attachment_on_collection();
//			  	work.Verify_Dot_Icon();
//			  	work.Download_the_Attachment();
//			  	work.Delete_the_Attachment();
			 }
			 
			 @Test(groups = {"Email"},priority = 1)
				public void UK_TC_008_EmailForClosedItem() throws IOException, InterruptedException {

					driver.get(baseURL);
					logger.info("URL is launched");
					LoginPage login = new LoginPage(driver);
					MyWork work = new MyWork(driver);
					CollectionPage collection = new CollectionPage(driver);
					//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
					String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",10, 1);
					//login.ClickOnSamrtCardLink();
					logger.info("Clicked on Smart Card link");
					LoginByUsername_Password(PEGA_username,PEGA_Password);
					logger.info("Entered code in pop up");
					work.ClickOnProfileButton_NEW();
					logger.info("Click on profile");
					work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
					logger.info("Switch to Cash Collection  Healthcare US ");
					work.SwitchTonewWindowInQ();
					collection.closeallwindows();
					work.ClickOnCustomerSearchOptiondsa();
					logger.info("Click on customer search");
					work.EnterCustomerNumberInSearchAndClickOnSearchButton(CustomerNo);
					logger.info("Enter customer number");
					logger.info("Click on customer search");
					work.ClickOnCollectionInQUKRC();
					logger.info("Click on collection search");
					logger.info("ExpandClosedDebitorItem");
					collection.Select_closedIteams_SelectEmailoption();
					logger.info("SelectEmailForClosedDebterItem");
					collection.ClickOnCorrespondenceTemplateList1("Rebill Tax Sales Tax");
					logger.info("ClickOnCorrespondenceTemplateList");
					collection.ClickOnsendEmailOptionForEmails();
					logger.info("Click On send Email Option");
					collection.ClickOnAuditForCreateforopenItemEmail();
					//collection.GetRecentTaskID();
					logger.info("GetRecentTaskID");

				}

			 @Test(priority = 3,groups= {"Collection"})
			 public void HC_TC_026_Customer_Management_in_a_collection_add_customers() throws Exception {
			 	driver.get(baseURL);
			 	logger.info("URL is launched");
			 	LoginPage login = new LoginPage(driver);
			 	MyWork work = new MyWork(driver);
			 	CollectionPage collection = new CollectionPage(driver);
			 	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			 	String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",51, 3);
			 	String Addnote = "Test by Giri";
			  	String Addnote2 = "Giri By 2";
			 	//login.ClickOnSamrtCardLink();
			 	logger.info("Clicked on Smart Card link");
			 	LoginByUsername_Password(PEGA_username,PEGA_Password);
			 	logger.info("Entered code in pop up");
			 	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 	work.ClickOnCustomerSearchOptiondsa();
			  	logger.info("Click on customer search");
			  	work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
			  	logger.info("Enter customer number");
			  	logger.info("Click on customer search");
			  	work.ClickOnCollectionInQUKRC();
			  	work.Customername();
			  	work.Verify_under_infromation();
			  	work.Actions();
			  	work.Select_Customermanagement();
			  	work.get_Company_code();
			  	work.Search_with_cc();
			  	work.Click_add();
			  	work.Verify_mainBranch_Selected_or_not();
			//  	driver.navigate().refresh();
			 	Thread.sleep(5000);
			 	collection.closeallwindows();
			  	work.ClickOnCustomerSearchOptiondsa();
			  	logger.info("Click on customer search");
			  	work.EnterCustomerNumberInSearchAndClickOnSearchButton12(CustomerNo);
			  	logger.info("Enter customer number");
			  	logger.info("Click on customer search");
			  	work.ClickOnCollectionInQUKRC1();
			  	work.Verify_the_Branchcount_under_information_HC();
			  	work.Verify_under_infromation_for_branchcount();

			  	work.Validating_customernames_HC();

			 }

			 @Test(priority = 2, groups = { "Dispute" },dependsOnMethods= {"US_TC_024_Customer_Management_change_main_customer_in_branch"})
		//	 @Test(priority = 2, groups = { "Dispute" })
	         public void HC_TC_026_Customer_Management_in_a_collection_remove_customers() throws Exception {
	         	driver.get(baseURL);
	         	logger.info("URL is launched");
	         	LoginPage login = new LoginPage(driver);
	         	MyWork work = new MyWork(driver);
	         	CollectionPage collection = new CollectionPage(driver);
	         	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
	         	String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",51, 3);
	         	String Addnote = "Test by Giri";
	          	String Addnote2 = "Giri By 2";
	         	//login.ClickOnSamrtCardLink();
	         	logger.info("Clicked on Smart Card link");
	         	LoginByUsername_Password(PEGA_username,PEGA_Password);
	         	logger.info("Entered code in pop up");
	         	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
	    		work.ClickOnCustomerSearchOptiondsa();
	    	 	logger.info("Click on customer search");
	    	 	work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
	    	 	logger.info("Enter customer number");
	    	 	logger.info("Click on customer search");
	    	 	work.ClickOnCollectionInQUKRC();
	    	 	work.Verify_the_Branchcount_under_information();
	    	 	work.Verify_under_infromation_for_branchcount();
	    	 	work.Actions();
	    	 	work.Select_Customermanagement();
	    	 	work.Verify_mainBranch_Selected_or_not_for_remove();
//	    	 	driver.navigate().refresh();
	    	 	Thread.sleep(4000);
	    		collection.closeallwindows();
	    		logger.info("I'm trying to check under information to see if Branch was removed or not");
	    	 	work.ClickOnCustomerSearchOptiondsa();
	    	 	logger.info("Click on customer search");
	    	 	work.EnterCustomerNumberInSearchAndClickOnSearchButton12(CustomerNo);
	    	 	logger.info("Enter customer number");
	    	 	logger.info("Click on customer search");
	    	 	work.ClickOnCollectionInQUKRC1();
	    	 	work.Verify_the_Branchcount_under_information_HC();
	    	 	work.Verify_under_infromation_for_branchcount_for_remove();

	         }

			 @Test(priority = 2, groups = { "Dispute" },dependsOnMethods= {"HC_TC_026_Customer_Management_in_a_collection_add_customers"})
	         public void US_TC_024_Customer_Management_change_main_customer_in_branch() throws Exception {
	        	 driver.get(baseURL);
	          	logger.info("URL is launched");
	          	LoginPage login = new LoginPage(driver);
	          	MyWork work = new MyWork(driver);
	          	CollectionPage collection = new CollectionPage(driver);
	          	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
	          	String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",51, 3);
	          	String Addnote = "Test by Giri";
	           	String Addnote2 = "Giri By 2";
	          	//login.ClickOnSamrtCardLink();
	          	logger.info("Clicked on Smart Card link");
	          	LoginByUsername_Password(PEGA_username,PEGA_Password);
	          	logger.info("Entered code in pop up");
	          	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
	     		work.ClickOnCustomerSearchOptiondsa();
	     	 	logger.info("Click on customer search");
	     	 	work.EnterCustomerNumberInSearchAndClickOnSearchButton_Email_closed(CustomerNo);
	     	 	logger.info("Enter customer number");
	     	 	logger.info("Click on customer search");
	     	 	work.ClickOnCollectionInQUKRC();
	     	 	work.Customername();
	     	 	work.Verify_the_Branchcount_under_information();
	     	 	work.Verify_under_infromation_for_branchcount();
	     	 	work.Actions();
	     	 	work.Select_Customermanagement();
	     	 	work.Verify_mainBranch_Selected_or_not_for_change_branch();
	     	 	//driver.navigate().refresh();
	    		Thread.sleep(5000);
	    		logger.info("I'm trying to check under information to see if Branch will change or not");
	    	 	work.ClickOnCustomerSearchOptiondsa();
	    	 	logger.info("Click on customer search");
	    	 	work.EnterCustomerNumberInSearchAndClickOnSearchButton_HC(CustomerNo);
	    	 	logger.info("Enter customer number");
	    	 	logger.info("Click on customer search");
	    	 	work.ClickOnCollectionInQUKRC_HC();
	    	 	work.Verify_the_customername();
	         }

			 @Test(priority = 3,groups= {"Reports"},invocationCount = 3)
			 public void HC_TC_04_Create_Report_Category_and_duplicate_move_and_copy_a_report() throws Exception {
			 	driver.get(baseURL);
			   	logger.info("URL is launched");
			   	LoginPage login = new LoginPage(driver);
			   	MyWork work = new MyWork(driver);
			   	CollectionPage collection = new CollectionPage(driver);
			   	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			   	String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",53, 2);
			   	Assigncollector AC = new Assigncollector(driver);
			   	String CategoryName = "Report_01";
			    	String Category_type = "Public";
			   	//login.ClickOnSamrtCardLink();
			   	logger.info("Clicked on Smart Card link");
			   	LoginByUsername_Password(PEGA_username,PEGA_Password);
			   	logger.info("Entered code in pop up");
			   	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
				 AC.CCMT_mainmenu();
				 work.Click_on_reports_from_mainmenu();
				 work.Click_on_addcategory();
				 work.Enter_CategoryName_SI(CategoryName,Category_type);
				 // work.Click_on_public_report();
				 work.copy_reportName();

			 }
			          @Test(priority = 3,groups= {"Reports"})
			 public void HC_TC_05_Report_Schedule_a_Report() throws Exception {
			 	driver.get(baseURL);
			   	logger.info("URL is launched");
			   	LoginPage login = new LoginPage(driver);
			   	MyWork work = new MyWork(driver);
			   	CollectionPage collection = new CollectionPage(driver);
			   	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			   	String CustomerNo = "0030333018";
			   	Assigncollector AC = new Assigncollector(driver);
			   	String CategoryName = "Report_01";
			    	String Category_type = "Public";
			   	//login.ClickOnSamrtCardLink();
			   	logger.info("Clicked on Smart Card link");
			   	LoginByUsername_Password(PEGA_username,PEGA_Password);
			   	logger.info("Entered code in pop up");
			   	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
						  AC.CCMT_mainmenu();
						  logger.info("Cliked on mainmenu");
						  work.Click_on_reports_from_mainmenu();
						  logger.info("Selected reports from mainmenu");
						  work.Click_on_addcategory();
						  work.Enter_CategoryName(CategoryName,Category_type);
						  logger.info("Go to Schedule for public report");
						  work.Click_Scheduled();
						  work.Set_Task_Output_Processing("Excel Workbook");
						  work.Send_Notifications_to_the_following_users_HC_US();
						  logger.info("Going to select mywork from mainmenu");
						  work.Verify_Report_Scheduled_or_not();
						  logger.info("Go to Unsubscribe for public report");
						  work.Unsubscribe();
						  work.Verify_Report_UnScheduled_or_not();
						  logger.info("Going to Delete the report");
						  work.Delete_for_report();

			 }


			          @Test(priority = 3,groups= {"Reports"},invocationCount = 3)
			 public void HC_TC_063_To_verify_user_is_able_to_edit_save_and_Fetch_report() throws Exception {

			 	driver.get(baseURL);
			   	logger.info("URL is launched");
			   	LoginPage login = new LoginPage(driver);
			   	MyWork work = new MyWork(driver);
			   	CollectionPage collection = new CollectionPage(driver);
			   	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			   	String CustomerNo = "0030333018";
			   	Assigncollector AC = new Assigncollector(driver);
			   	String Tittle_of_the_report = "Report01";
			   	//login.ClickOnSamrtCardLink();
			   	logger.info("Clicked on Smart Card link");
			   	LoginByUsername_Password(PEGA_username,PEGA_Password);
			   	logger.info("Entered code in pop up");
			   	work.ClickOnProfileButton_NEW();
				logger.info("Click on profile");
				work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector for CC HC US app RC)");
				logger.info("Switch to Cash Collection  Healthcare US ");
				work.SwitchTonewWindowInQ();
				collection.closeallwindows();
			 		logger.info("Closed all previous windows ");
						  logger.info("Cliked on mainmenu");
						  AC.CCMT_mainmenu();
						  logger.info("Cliked on mainmenu");
						  work.Click_on_reports_from_mainmenu();
						  logger.info("Selected reports from mainmenu");
						  work.Click_on_Addreport();
						  work.Select_Casetype_and_reporttype_submit();
						  logger.info("Validating can able to edit the report, drag and drop ect.");
						  work.Search_in_DataExplorer();
						  //work.value_for_inputbox();
						  work.Drag_and_drop();
						  work.Click_on_DoneEDIT();
						  work.setup_Tittle(Tittle_of_the_report);
						  work.Value_Tittle();
						  work.Set_Description();
						  work.Click_on_Actions_and_Select_Report_details();
						  work.Click_on_Actions_and_Select_Summarize_details();
						  work.Click_on_Actions_and_Select_Export_Pdf();
						  logger.info("Checking whether the created report appears in the reports section");
						  work.verify_newreport_Created_or_not(Tittle_of_the_report);


					  }
			          @Test(priority = 3,groups= {"Collection"})
			          public void HC_TC_Manager_Menu_Customer_Master_Sync() throws Exception {

			          	driver.get(baseURL);
			            	logger.info("URL is launched");
			            	LoginPage login = new LoginPage(driver);
			            	MyWork work = new MyWork(driver);
			            	CollectionPage collection = new CollectionPage(driver);
			            	//String pin = XLUtils.getCellData(excelpath, "Sheet1", 1, 0);
			            	String CustomerNo = XLUtils.getCellData(excelpath2, "Sheet1",54, 2);
			            	Assigncollector AC = new Assigncollector(driver);
			            	String Tittle_of_the_report = "Report01";
			            	//login.ClickOnSamrtCardLink();
			            	logger.info("Clicked on Smart Card link");
			            	LoginByUsername_Password(PEGA_username,PEGA_Password);
			            	logger.info("Entered code in pop up");
			            	work.ClickOnProfileButton_NEW();
							logger.info("Click on profile");
							work.ClickOnApplicationInSwitchAppsUsingApplicationName("Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app)");
							logger.info("Switch to Cash Collection Healthcare US RC (Cash Collector Manager for CC HC US RC app) ");
							work.SwitchTonewWindowInQ();
							collection.closeallwindows();
			          	logger.info("Closed all previous windows ");
			          	AC.CCMT_mainmenu();
			          	work.Click_on_Customer_Sync();
			          	work.Company_code_and_CustomerNumber_System("0100	","0000000863","P4001");
			          	work.Verify_the_Customer_successfully_queued_for_import_or_not();
			          }

			          	}

