package CCMTTestCases;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.apache.log4j.spi.LoggingEvent;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExtentReportListener extends BaseClass implements ITestListener {

    private static ExtentReports extent;
    private static List<LoggingEvent> logEvents = new ArrayList<>();

    @Override
    public void onStart(ITestContext context) {
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("UI_Report.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
    }

    @Override
    public void onFinish(ITestContext context) {
        extent.flush();
    }

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = extent.createTest(result.getMethod().getMethodName());
        setTest(test);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        getTest().log(Status.PASS, "Test Passed");
        addLogEventsToReport();

        // Include screenshot in the report
        String screenshotPath = captureScreenshot("Test_Passed");
        try {
            getTest().pass("Test Passed", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onTestFailure(ITestResult result) {
        getTest().log(Status.FAIL, "Test Failed");
        addLogEventsToReport();

        // Include screenshot in the report
        String screenshotPath = captureScreenshot("Test_Failed");
        try {
            getTest().fail("Test Failed", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        getTest().log(Status.SKIP, "Test Skipped");
        addLogEventsToReport();

        // Include screenshot in the report
        String screenshotPath = captureScreenshot("Test_Skipped");
        try {
            getTest().skip("Test Skipped", MediaEntityBuilder.createScreenCaptureFromPath(screenshotPath).build());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // Method to add log events from ExtentLogAppender to the report
    private void addLogEventsToReport() {
        for (LoggingEvent event : logEvents) {
            getTest().log(Status.INFO, event.getMessage().toString());
        }
        // Clear log events after adding them to the report
        logEvents.clear();
    }

    // Method to set the current test
    private static void setTest(ExtentTest test) {
        ExtentReportListener.test = test;
    }

    // Method to get the current test
    public static ExtentTest getTest() {
        return test;
    }

    // Method to add log event from ExtentLogAppender
    public static void addLogEvent(LoggingEvent event) {
        logEvents.add(event);
    }
}
