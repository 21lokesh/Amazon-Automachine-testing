package CCMTTestCases;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.spi.LoggingEvent;

public class ExtentLogAppender extends AppenderSkeleton {

    @Override
    protected void append(LoggingEvent event) {
        // Pass log event to ExtentReportListener
        ExtentReportListener.addLogEvent(event);
    }

    @Override
    public void close() {
        // Clean up resources if needed
    }

    @Override
    public boolean requiresLayout() {
        return false;
    }
}
