package CCMTPageObjects;

import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.StaleElementReferenceException;
import CCMTTestCases.BaseClass;
import org.openqa.selenium.WebDriverException;
import java.time.Duration;

public class Collectionpage2 extends BaseClass {
	public WebDriver lwebDriver;

	public Collectionpage2(WebDriver rdriver) {

		lwebDriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

//day from due

	@FindBy(xpath = "//a[@name='pyPortalHeader_pyDisplayHarness_79']//following	::span[text()='Profile']")
	@CacheLookup
	public WebElement profile;


	public void US_Profile() {

		if (profile.isDisplayed()) {
			Assert.assertTrue(true);
			logger.info("Selected profile option in dropdown");
		} else {

			logger.info("Did not see the profile option in dropdown");
			Assert.assertTrue(false);
		}
	}

	public void SelectCheckBoxanddisputeoption_HC() throws InterruptedException {
		Thread.sleep(5000);


		WebDriverWait wait = new WebDriverWait(lwebDriver, Duration.ofSeconds(60));
		logger.info("before");

		// Explicit Wait for Frame Switching
		WebDriverWait frameWait = new WebDriverWait(lwebDriver, Duration.ofSeconds(10));

		try {
			frameWait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt("PegaGadget1Ifr"));
			logger.info("after");

			// Continue with your code inside the frame
			// Updated XPath for better readability
			String xpath = "(//input[contains(@name,'$PD_OpenDebtorItemListByCollection_pa')])[2]";
			logger.info("Trying to find element with XPath: " + xpath);

			WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));

			if (element != null) {
				logger.info("Element found. Trying to click.");

				// Handle StaleElementReferenceException
				try {
					element.click();
				} catch (StaleElementReferenceException e) {
					// Element is stale, refresh and try again
					element = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(xpath)));
					element.click();
				}

				if (element.isSelected()) {
					logger.info("Line item was selected");
				} else {
					logger.info("Line item was not selected");
				}
			} else {
				logger.error("Element not found!");
			}

			lwebDriver.findElement(By.xpath("//button[contains(text(),'Dispute')]")).click();
			logger.info("Click on Dispute");

			// Verify Frame Presence
			Thread.sleep(4000);
			if (lwebDriver.getPageSource().contains("You can not start a dispute on a debtor item already in dispute") || lwebDriver.getPageSource().contains("One or more Debtor Items can't be locked.")) {
				lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')]//input[contains(@name,'$PD_OpenDebtorItemListByCollection_p')])[2]")).click();
				WebElement checkbox2 = lwebDriver.findElement(By.xpath("(//tr[contains(@id,'$PD_OpenDebtorItemListByCollection_pa')][2]//input[contains(@name,'$PD_OpenDebtorItemListByCollection_p')])[2]"));
				checkbox2.click();
				if (checkbox2.isSelected()) {
					logger.info("second Line item was selected");
				} else {
					logger.info("secondLine item also was not selected");
				}
				lwebDriver.findElement(By.xpath("//button[contains(text(),'Dispute')]")).click();
				Thread.sleep(3000);
				logger.info("Click on Dispute");
			}
		} catch (WebDriverException e) {
			logger.error("Frame not found or other WebDriver issue!");
		} finally {
			BaseClass.SwitchToDefaultFrame();
		}
	}



}


