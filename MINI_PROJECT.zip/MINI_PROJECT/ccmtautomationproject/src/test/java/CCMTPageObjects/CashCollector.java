package CCMTPageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CashCollector {
	
	  WebDriver lwebDriver;
		 
	  public CashCollector(WebDriver rdriver) {
		  
		  lwebDriver=rdriver;
		  PageFactory.initElements(rdriver, this);
	  }
	  
	  @FindBy(xpath="///a[@class='Horizontal_menu_items']")
	   @CacheLookup
	   WebElement ClickOnAssign;
	  
	   @FindBy(xpath="//input[@id='b7bbd9cd']")
	   @CacheLookup
	   WebElement SearchCashCollector;
	     
	   @FindBy(xpath="//button[text()='  Submit '] ")
	   @CacheLookup
	   WebElement ClickOnSubmit;
	   
	   @FindBy(id="id")
	   @CacheLookup
	   WebElement SelectCashCollector;
	   
	   
	   
	   
	

}
