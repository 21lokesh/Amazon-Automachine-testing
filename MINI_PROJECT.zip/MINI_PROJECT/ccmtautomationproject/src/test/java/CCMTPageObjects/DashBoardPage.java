package CCMTPageObjects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import CCMTTestCases.BaseClass;

public class DashBoardPage extends BaseClass{



	public WebDriver lwebDriver;

	  public DashBoardPage(WebDriver rdriver) {

		  lwebDriver=rdriver;
		  PageFactory.initElements(rdriver, this);
	  }




	//DashBoard

		 //ClickOnEmailOption
		   @FindBy(xpath="//span[text()='Dashboard']")
		   @CacheLookup
		   WebElement ClickOnDashBoardFromBurgerMenu;

		 //ClickOnEmailOption
		   @FindBy(xpath="//div[text()='Under the Hood']")
		   @CacheLookup
		   WebElement ClickOnUnderTheHood;

		 //ClickOnEmailOption
		   @FindBy(xpath="//h2[text()='Global Under the Hood']")
		   @CacheLookup
		   WebElement ClickOnGlobalUnderTheHood;

		 //ClickOnEmailOption
		   @FindBy(xpath="//h2[text()='Listener Management']")
		   @CacheLookup
		   WebElement ClickOnListnerManagement;

		   @FindBy(xpath="//div[text()='Under the Hood']/following::div[23]")
		   @CacheLookup
		   WebElement ClickOnunderHoodtalble;
		   @FindBy(xpath="//div[text()='Global Under the Hood']")
		   @CacheLookup
		   WebElement  Under_the_Hood;

		   @FindBy(xpath="//div[text()='Listener Management']")
		   @CacheLookup
		   WebElement  Listener_Management;

		   String CustomerFrameId="PegaGadget0Ifr";



		   public void SelectDashBoardFromBurgerMenu() throws Exception

			  {
				  BaseClass.WaitforElementToBeClickable(By.xpath("//span[text()='Dashboard']"));
				  Thread.sleep(5000);
				  ClickOnDashBoardFromBurgerMenu.click();
				  Thread.sleep(5000);
				  //Giri
				  if(ClickOnDashBoardFromBurgerMenu.isEnabled()) {
					  logger.info("DashBord option is avalible from mainmenu");
				  }
				  else {
					  logger.info("DashBord option is not avalible from mainmenu");
				  }
			  }


		   public void ExpandUnderTheHood() throws InterruptedException {
			   lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			   //Giri modify
			   // BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
			   BaseClass.WaitforVisiblityofElement(ClickOnunderHoodtalble);
			   List<WebElement> E = lwebDriver.findElements(By.xpath("//div[text()='Under the Hood']/following::div[21]"));
			   logger.info("Checking Buttons are working or not");
			   for (WebElement D : E) {
				   System.out.println(D.getSize());
				   if (D.isEnabled()) {
					   logger.info("Enabled all buttons under Hood");
					   Assert.assertTrue(true);
				   } else {

					   logger.info("Disabled  buttons under Hood");
					   Assert.assertTrue(false);
				   }
			   }
//			   BaseClass.WaitforElementToBeClickable(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Bank Statements']"));
//			   WebElement BankStatement = lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Bank Statements']"));
//			   if (BankStatement.isDisplayed()) {
//
//				   logger.info("Bank Statements is displayed under the Hood");
//				   Assert.assertTrue(true);
//			   } else {
//
//				   logger.info("Bank Statements is not displayed under the Hood");
//				   Assert.assertTrue(false);
//			   }
//
//			   WebElement Last_sync = lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Bank Statements']/following::div[2]"));
//			   if (Last_sync.isDisplayed()) {
//				   logger.info("Last sync of bank statements and date shows under Bank Statements");
//				   Assert.assertTrue(true);
//			   } else {
//				   logger.info("Last sync of bank statements and date are not showing under Bank Statements");
//				   Assert.assertTrue(false);
//			   }
//		WebElement Pending_Emails=lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Pending Emails']"));
//		if(Pending_Emails.isDisplayed()) {
//			logger.info("Pending_Emails shows under Bank Statements");
//			Assert.assertTrue(true);
//		}
//		else {
//			logger.info("Pending_Emails are not showing under Bank Statements");
//			Assert.assertTrue(false);
//		}
//		WebElement ShowButton=lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::a[text()='Show more']"));
//
//		if(ShowButton.isEnabled()& ShowButton.isDisplayed()) {
//			logger.info("ShowButton isEnabled & Displayed  ");
//			Assert.assertTrue(true);
//		}
//		else {
//			logger.info("ShowButton is not dispaly or else disabled");
//			Assert.assertTrue(false);
//		}
//		WebElement Failed_Emails=lwebDriver.findElement(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Failed Emails']"));
//
//		if(Failed_Emails.isDisplayed()) {
//			logger.info("Failed_Emails name shows under the Hood");
//			Assert.assertTrue(true);
//		}
//		else {
//			logger.info("Failed_Emails name not avalible  under the Hood");
//			Assert.assertTrue(false);
//		}
//
//		List<WebElement> No_of_Failed_Emails=lwebDriver.findElements(By.xpath("//div[text()='Under the Hood']/following::h2[text()='Failed Emails']/following::div[@class='field-item dataValueRead']/child::span[@class='labelbold']"));
//
//
//		if(No_of_Failed_Emails.isEmpty()) {
//			logger.info("There are no Failed tractions avalible");
//			Assert.assertTrue(true);
//		}
//		else {
//			logger.info(" Failed tractions are  avalible");
//		//	Assert.assertTrue(true);
//		}
//		logger.info("******* Checking functionalities about ExpandGlobalUnderTheHood***********");
		lwebDriver.switchTo().defaultContent();
//			  }

		   }
		   public void ExpandGlobalUnderTheHood() throws InterruptedException

			  {  //Giri
			   lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			   if(Under_the_Hood.isDisplayed() ) {
				   logger.info(" Global Under the Hood is  avalible in Dashbord");
				   Assert.assertTrue(true);
			   }
			   else {
				   logger.info(" Global Under the Hood is not avalible in Dashbord");
				   Assert.assertTrue(false);
			   }
				  WebDriverWait wait= new WebDriverWait(driver, Duration.ofSeconds(40));
				  WebElement Strategy =   wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Global Under the Hood']/following::h2[text()='Strategy Runs']")));
		//	   WebElement Strategy =lwebDriver.findElement(By.xpath("//div[text()='Global Under the Hood']/following::h2[text()='Strategy Runs']"));
			   if(Strategy.isDisplayed() ) {
				   logger.info(" Strategy functionality is  avalible under Global Under the Hood");
				   Assert.assertTrue(true);
			   }
			   else {
				   logger.info(" Strategy functionality is not avalible under Global Under the Hood");
				   Assert.assertTrue(false);
			   }
			  List< WebElement>StrategyDatatable =lwebDriver.findElements(By.xpath("//div[text()='Global Under the Hood']/following::table[1]"));
			  for(WebElement SS:StrategyDatatable) {
				  System.out.println(SS.getText());

			  if(SS.getText().contains("Application") && SS.getText().contains("Company Code")) {
				  logger.info(" Strategy table was displayed");
				  Assert.assertTrue(true);
			  }
			  else {
				  logger.info(" Strategy table was not displayed");
				  Assert.assertTrue(false);

				}

			  }
			  lwebDriver.switchTo().defaultContent();
			  }

		   public void ExpandListnerManagement() throws InterruptedException
			 //Giri
			  {
			   lwebDriver.switchTo().frame(lwebDriver.findElement(By.tagName("iframe")));
			   Listener_Management.click();
			   if(Listener_Management.isDisplayed()) {
				   logger.info(" Listener_Management was displayed");
					  Assert.assertTrue(true);
			   }
			   else {
					  logger.info(" Listener_Management functionality is not avalible under Dashbord");
					  Assert.assertTrue(false);
			  }

			   WebElement EmailListener =lwebDriver.findElement(By.xpath("//div[text()='Global Under the Hood']/following::table[1]"));
			   if(EmailListener.isDisplayed()) {
				   logger.info(" EmailListener was displayed");
					  Assert.assertTrue(true);
			   }
			   else {
					  logger.info(" EmailListener functionality is not avalible under Dashbord");
					  Assert.assertTrue(false);
			  }
			   WebElement EmailListenertable =lwebDriver.findElement(By.xpath("//div[text()='Global Under the Hood']/following::table[1]"));
			   Thread.sleep(5000);
			   EmailListenertable.click();
			   Thread.sleep(5000);
			   List<WebElement> EmailListenerdatatable =lwebDriver.findElements(By.xpath("//div[text()='Listener Management']/following::h2[text()='Email Listeners']/following::div[5]/child::div/descendant::table[@class='gridTable ']"));
			   for(WebElement ELD:EmailListenerdatatable) {
				   System.out.println(ELD.getText());
				   if(ELD.getText().contains("Listener Name") && ELD.getText().contains("Connection")  ) {
					   logger.info(" Office 365 table was displayed");
						  Assert.assertTrue(true);
				   }
				   else{
					   logger.info(" Office 365 table is not displayed");
						  Assert.assertTrue(false);
				   }
			   }

			  }
}