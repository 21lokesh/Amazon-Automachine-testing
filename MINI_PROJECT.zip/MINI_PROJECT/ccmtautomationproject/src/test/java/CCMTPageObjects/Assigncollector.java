package CCMTPageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import CCMTTestCases.BaseClass;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import static CCMTPageObjects.CollectionPage.calculateDays;

public class Assigncollector {
	WebDriver ldriver;

	public Assigncollector(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(xpath = "//a[@id='appview-nav-toggle-one']")
	WebElement mainmenu;
	@FindBy(xpath = "//span[contains(text(),'Cash collectors')]")
	WebElement cash_button;
	@FindBy(xpath = "//input[contains(@name,'AuxSearchString')]")
	WebElement collector_search;
	@FindBy(xpath = "//div[text()='Search']/ancestor::button")
	WebElement search;
	@FindBy(xpath="//tr[@class='oddRow cellCont']//child::a")
	WebElement sp;

	@FindBy(xpath="(//tr[@class='oddRow cellCont']//child::a)[1]")
	WebElement sp2;
	@FindBy(xpath="//div[@id='pyFlowActionHTML']/descendant::input[1]")
	WebElement collectorname;
	@FindBy(xpath="//span[text()='        Assign Operator       ']/following::td[8]")
	WebElement radio_button;
    @FindBy(xpath="//button[contains(text(),'  Submit ')]")
    WebElement sumbit;
	public static long calculateDayss(String inputDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yy");
		LocalDate providedDate = LocalDate.parse(inputDate, formatter);
		LocalDate currentDate = LocalDate.now();
		return ChronoUnit.DAYS.between(providedDate, currentDate);
	}
	public void CCMT_mainmenu() throws InterruptedException {

		Thread.sleep(3000);

		BaseClass.SwitchToDefaultFrame();
		BaseClass.WaitforElementToBeClickable(By.xpath("//a[@id='appview-nav-toggle-one']"));
		mainmenu.click();


	}

	public void CCMT_mainmenu1() throws InterruptedException {
		BaseClass.SwitchToDefaultFrame();
		BaseClass.WaitforElementToBeClickable(By.xpath("//a[@id='appview-nav-toggle-one']"));
WebElement Main =		ldriver.findElement(By.xpath("//a[@id='appview-nav-toggle-one']"));
		try {
			Main.click();
		}catch(StaleElementReferenceException e) {
			Main =		ldriver.findElement(By.xpath("//a[@id='appview-nav-toggle-one']"));
			Main.click();
			Thread.sleep(3000);
		}

		Thread.sleep(3000);
	}

	public void CCMT_cash() throws InterruptedException {


		cash_button.click();

	}

	public void CCMT_collectorsearch(String name) throws InterruptedException {



		ldriver.switchTo().frame(ldriver.findElement(By.tagName("iframe")));

		Thread.sleep(10000);
		collector_search.sendKeys(name);



	}

	public void CCMT_search() throws InterruptedException {
		Thread.sleep(5000);
		search.click();



	}
	public void coll_search() throws Exception {

		Thread.sleep(5000);
		WebDriverWait wait= new WebDriverWait(ldriver, Duration.ofSeconds(40));
		WebElement SP =   wait.until(ExpectedConditions.visibilityOf(sp2));

		SP.click();


	}

	public void coll_search2() throws Exception {

		Thread.sleep(5000);
		WebDriverWait wait= new WebDriverWait(ldriver, Duration.ofSeconds(40));
		WebElement SP =   wait.until(ExpectedConditions.visibilityOf(sp2));

		SP.click();


	}
	public void CCMT_collectorname(String name) throws InterruptedException {

		Thread.sleep(5000);

		collectorname.sendKeys(name);


		//ldriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	public void Radio_Button() throws InterruptedException {
		Thread.sleep(6000);

		radio_button.click();


	}
public void Click_submit() throws InterruptedException {
	Thread.sleep(5000);
	sumbit.click();
	Thread.sleep(5000);
}



	}



