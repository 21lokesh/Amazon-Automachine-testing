package CCMTPageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import CCMTTestCases.BaseClass;

public class OtherUsersWorkPage {
	
	public WebDriver lwebDriver;
	 
	  public OtherUsersWorkPage(WebDriver rdriver) {
		  
		  lwebDriver=rdriver;
		  PageFactory.initElements(rdriver, this);
	  }
	  
	  
	//OtherUsersWork		   
	   
		 //ClickOnEmailOption
		   @FindBy(xpath="(//span[@class='menu-item-title-wrap'])[3]")
		   @CacheLookup
		   WebElement ClickOntherUsersWorkFromBurgerMenu;
		   
		   
		   //ClickOnEmailOption
		   @FindBy(xpath="//div[@class='field-item dataValueWrite']/input[@name='$PpyDisplayHarness$ppyTempText']")
		   @CacheLookup
		   WebElement ClickOnSerachInOtherUsersWork;
		   
		 //ClickOnEmailOption
		   @FindBy(xpath="//span[.='Saleem P']")
		   @CacheLookup
		   WebElement ClickOnSelectUser;
		   
		   String CustomerFrameId="PegaGadget0Ifr";
		   
		   
		   
		   public void SelectOtherUsersWorkFromBurgerMenu()
			 
			  {    
				  BaseClass.WaitforElementToBeClickable(By.xpath("//span[text()='Dashboard']"));
				  ClickOntherUsersWorkFromBurgerMenu.click();  
			  }
		   
		   
		   public void SearchAndSelectUserInOtherUsersWork() throws InterruptedException
			 
			  {   
			      BaseClass.SwitchtoFrameUsingFrameIdorName(CustomerFrameId);
				  BaseClass.WaitforElementToBeClickable(By.xpath("//div[@class='field-item dataValueWrite']/input[@name='$PpyDisplayHarness$ppyTempText']"));
				  ClickOnSerachInOtherUsersWork.sendKeys("Saleem pas");
				  
				  
				  BaseClass.WaitforElementToBeClickable(By.xpath("//span[.='Saleem Pas']"));
				  JavascriptExecutor je=(JavascriptExecutor)lwebDriver;
				  je.executeScript("arguments[0].click();", ClickOnSelectUser);
				  Thread.sleep(4000);
				  
				  
		     	//  ClickOnSelectUser.click();
		//     	  try {
		//     	 ClickOnSerachInOtherUsersWork.clear();
		     	 
		 //    	ClickOnSerachInOtherUsersWork.sendKeys("Salee");
		//     	BaseClass.WaitforElementToBeClickable(By.xpath("//div[@class='pz-po-c autocompleteAG lookupPO popover_ac_']"));
		 //    	ClickOnSelectUser.submit();
		 //    	
		  //   	  }
		  //   	  catch(StaleElementReferenceException e) {
		     	  
		   //  	  }
				  BaseClass.SwitchToDefaultFrame();
				  
				  
			  }

}
