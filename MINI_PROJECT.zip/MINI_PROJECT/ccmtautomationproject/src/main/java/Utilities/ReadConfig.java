package Utilities;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

	public class ReadConfig {

		Properties pro;

		public ReadConfig()
		{
			File src = new File("./src/Resources/ConfigFiles/config.properties");

			try {
				FileInputStream fis = new FileInputStream(src);
				pro = new Properties();
				pro.load(fis);
			} catch (Exception e) {
				System.out.println("Exception is " + e.getMessage());
			}
		}

		public String getApplicationURL()
		{
			String url=pro.getProperty("baseURL");
			return url;
		}

		public String getChromePath() {
			String chromePath=pro.getProperty("chromePath");
			return chromePath;
		}

		public String getExcelPath() {
			String excelPath=pro.getProperty("excelpath");
			return excelPath;
		}
		public String getExcelPath2() {
			String excelPath=pro.getProperty("excelpath2");
			return excelPath;
		}

		public String getPinAuthenticated(){
			String pin=pro.getProperty("Pin");
			return pin;
		}
		
		public String getdbURL() {
			String excelPath=pro.getProperty("DB_URL");
			return excelPath;
		}
		
		public String getdbUserName() {
			String excelPath=pro.getProperty("DB_UserName");
			return excelPath;
		}
		
		public String getdbPassword() {
			String excelPath=pro.getProperty("DB_Password");
			return excelPath;
		}

		public String Get_Username() {
			String Username=pro.getProperty("Pega_Username");
			return Username;
		}

		public String Get_Password() {
			String User_Password=pro.getProperty("Pega_Password");
			return User_Password;
		}
		
		public String getBuildVersion() {
			String excelPath=pro.getProperty("buildVersion");
			return excelPath;
		}

		public String getFirefoxPath() {
			String excelPath=pro.getProperty("Firefoxpath");
			return excelPath;
		}

		public String getAutoITPath() {
			String dirPath=pro.getProperty("AutoITPath");
			return dirPath;
		}

		public String getAutoITDirectoryPath() {
			String dirPath1=pro.getProperty("DirPath");
			return dirPath1;
		}
}
