package Utilities;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.Parameters;

public class ExtentReporterNG implements ITestListener {

  private Workbook workbook;
  private Sheet sheet;
  private int rowNum;

  @Override
  public void onStart(ITestContext context) {
    // Create Excel workbook and sheet
    workbook = new XSSFWorkbook();
    sheet = workbook.createSheet("Report");
    rowNum = 0;
  }

  @Override
  public void onFinish(ITestContext context) {
    // Write Excel file
    try {
      FileOutputStream outputStream = new FileOutputStream(new File("C:\\Users\\z004n9pt\\eclipse-workspace\\CCMTAutomation\\CCMTAutomation\\Screenshots\\Book1.xlsx"));
      workbook.write(outputStream);
      ((FileOutputStream) workbook).close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @Override
  public void onTestStart(ITestResult result) {
    // Create row for start time
    Row rowStartTime = sheet.createRow(rowNum++);
    Cell cellStartTimeTitle = rowStartTime.createCell(0);
    cellStartTimeTitle.setCellValue("Start Time:");
    CellStyle cellStyle = workbook.createCellStyle();
    CreationHelper creationHelper = workbook.getCreationHelper();
    cellStyle.setDataFormat(creationHelper.createDataFormat().getFormat("m/d/yyyy h:mm:ss"));
    Cell cellStartTimeValue = rowStartTime.createCell(1);
    cellStartTimeValue.setCellValue(new Date());
    cellStartTimeValue.setCellStyle(cellStyle);
  }

  @Override
  public void onTestSuccess(ITestResult result) {
    // Create row for end time
    Row rowEndTime = sheet.createRow(rowNum++);
    Cell cellEndTimeTitle = rowEndTime.createCell(0);
    cellEndTimeTitle.setCellValue("End Time:");
    CellStyle cellStyle = workbook.createCellStyle();
    CreationHelper creationHelper = workbook.getCreationHelper();
    cellStyle.setDataFormat(creationHelper.createDataFormat().getFormat("m/d/yyyy h:mm:ss"));
    Cell cellEndTimeValue = rowEndTime.createCell(1);
    cellEndTimeValue.setCellValue(new Date());
    cellEndTimeValue.setCellStyle(cellStyle);

    // Get console info data
    String consoleInfo = result.getMethod().getTestClass().getName() + "." + result.getMethod().getMethodName() + ": " + result.getMethod().getDescription() + "\n" + result.getTestContext().getFailedTests().getResults(result.getMethod()).stream().map(r -> r.getThrowable().toString()).collect(Collectors.joining("\n"));

    // Create row for console info data
    Row rowConsoleInfo = sheet.createRow(rowNum++);
    Cell cellConsoleInfoTitle = rowConsoleInfo.createCell(0);
    cellConsoleInfoTitle.setCellValue("Console Info:");
    Cell cellConsoleInfoValue = rowConsoleInfo.createCell(1);
    cellConsoleInfoValue.setCellValue(consoleInfo);
  }
  // Implement other ITestListener methods as needed

}
