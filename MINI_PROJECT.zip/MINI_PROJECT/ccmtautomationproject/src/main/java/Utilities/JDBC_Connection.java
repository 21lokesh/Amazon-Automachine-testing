package Utilities;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class JDBC_Connection implements ITestListener {



    String DB_URL;
    String DB_UserName = "CCMT_USER";
    String DB_Password = "Siemens$@#1234";
    Connection con;
    PreparedStatement preparedStmt;
    Statement statement;
    String Release;
    String Application_Name;
    String[] groups;
    String Test_Cases;
    String Start_Time;
    String End_Time;
    String Testing_type;
    int GetPriority;
    int Test_Result;
    int Priority;
    String Groupss;
    Throwable exception;
    String Failure_Reason;
    ReadConfig config = new ReadConfig();
    String Results_status;

    @Override
    public void onStart(ITestContext context) {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            //jdbc:sqlserver://<YourServerName>:1433;database=<YourDatabaseName>;encrypt=true;trustServerCertificate=true;
            //String DB_URL ="jdbc:sqlserver://INRGA10229WSPR:1433;databaseName=CCMT_Test_Automation;encrypt=true;trustServerCertificate=true";
            DB_URL=config.getdbURL();
            DB_UserName=config.getdbUserName();
            DB_Password=config.getdbPassword();
            //DB_URL ="jdbc:sqlserver://192.168.0.10:3324\\<instance_name>;databaseName=sample";

            con = DriverManager.getConnection(DB_URL, DB_UserName, DB_Password);
//    	-----------------
            System.out.println("MS SQL Server connection has established");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }


//    public void onFinish(ITestContext context) {
//        try {
//            String fileName = "TestReport_" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".xlsx";
//            FileOutputStream outputStream = new FileOutputStream(new File(fileName));
//            workbook.write(outputStream);
//            workbook.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }

    @Override
    public void onTestStart(ITestResult result) {
        // Do nothing
        //captureScreen(driver, );
    }
  //  List<TestResult> testResults = new ArrayList<>();
    @Override
    public void onTestSuccess(ITestResult result) {
        addTestResult(result, "Passed");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        addTestResult(result, "Failed");
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        addTestResult(result, "Skipped");
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        // Do nothing
    }

    private void addTestResult(ITestResult result, String status) {
        Application_Name = result.getTestContext().getCurrentXmlTest().getParameter("Applicationname");
        groups = result.getMethod().getGroups();
        Test_Cases = result.getName();
        GetPriority = result.getMethod().getPriority();

        if (groups.length > 0) {
            Groupss = groups[0];
        } else {
            Groupss = "";
        }

        Start_Time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(result.getStartMillis()));
        End_Time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(result.getEndMillis()));
        Results_status = status;
        Release = config.getBuildVersion();
        Testing_type = result.getTestContext().getCurrentXmlTest().getParameter("Testingtype");
        Priority = result.getMethod().getPriority();
        Throwable throwable = result.getThrowable();
        String exception = (throwable != null) ? throwable.toString() : "No Exception";

        if (exception.contains("NoSuchWindowException")) {
            Results_status = "Failed";
            Failure_Reason = exception;
        } else if (result.getStatus() == ITestResult.SKIP) {
            Results_status = "Skipped";
            Failure_Reason = "Test Skipped";
        } else {
            Failure_Reason = "No Exception";
        }
            insertTestResult(Release, Application_Name, Groupss, Test_Cases, Results_status, Start_Time, End_Time, GetPriority, exception, Testing_type);
        }





    @Override
    public void onFinish(ITestContext context) {
        // Do nothing
    }

    public void insertTestResult(String Release, String Application_Name, String Groupss, String Test_Cases, String Results_status, String Start_Time, String End_Time, int GetPriority, String exception, String Testingtype) {
        try {
            String insertQuery = "INSERT INTO dbo.CCMT_Automation_Result (Release, Application, Groups, Test_Cases, Status, Start_Time, End_Time, Priority, Failure_Reason, Testingtype) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStmt = con.prepareStatement(insertQuery);
            preparedStmt.setString(1, truncateString(Release, 50)); // Adjust the maximum length as per your table schema
            preparedStmt.setString(2, truncateString(Application_Name, 100)); // Adjust the maximum length as per your table schema
            preparedStmt.setString(3, truncateString(Groupss, 50)); // Adjust the maximum length as per your table schema
            preparedStmt.setString(4, truncateString(Test_Cases, 100)); // Adjust the maximum length as per your table schema
            preparedStmt.setString(5, truncateString(Results_status, 50)); // Adjust the maximum length as per your table schema
            preparedStmt.setString(6, Start_Time);
            preparedStmt.setString(7, End_Time);
            preparedStmt.setInt(8, GetPriority);
            preparedStmt.setString(9, truncateString(exception, 100)); // Adjust the maximum length as per your table schema
            preparedStmt.setString(10, truncateString(Testingtype, 50)); // Adjust the maximum length as per your table schema

            preparedStmt.executeUpdate();
            preparedStmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            System.out.println("Automation result entered in the database.");
        }
    }

    private String truncateString(String value, int maxLength) {
        if (value != null && value.length() > maxLength) {
            return value.substring(0, maxLength);
        }
        return value;
    }

}